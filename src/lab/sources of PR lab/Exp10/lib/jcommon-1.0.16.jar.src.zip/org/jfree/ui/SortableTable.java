/*     */ package org.jfree.ui;
/*     */ 
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.table.JTableHeader;
/*     */ import javax.swing.table.TableColumn;
/*     */ import javax.swing.table.TableColumnModel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SortableTable
/*     */   extends JTable
/*     */ {
/*     */   private SortableTableHeaderListener headerListener;
/*     */   
/*     */   public SortableTable(SortableTableModel model)
/*     */   {
/*  67 */     super(model);
/*     */     
/*  69 */     SortButtonRenderer renderer = new SortButtonRenderer();
/*  70 */     TableColumnModel cm = getColumnModel();
/*  71 */     for (int i = 0; i < cm.getColumnCount(); i++) {
/*  72 */       cm.getColumn(i).setHeaderRenderer(renderer);
/*     */     }
/*     */     
/*  75 */     JTableHeader header = getTableHeader();
/*  76 */     this.headerListener = new SortableTableHeaderListener(model, renderer);
/*  77 */     header.addMouseListener(this.headerListener);
/*  78 */     header.addMouseMotionListener(this.headerListener);
/*     */     
/*  80 */     model.sortByColumn(0, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSortableModel(SortableTableModel model)
/*     */   {
/*  93 */     super.setModel(model);
/*  94 */     this.headerListener.setTableModel(model);
/*  95 */     SortButtonRenderer renderer = new SortButtonRenderer();
/*  96 */     TableColumnModel cm = getColumnModel();
/*  97 */     for (int i = 0; i < cm.getColumnCount(); i++) {
/*  98 */       cm.getColumn(i).setHeaderRenderer(renderer);
/*     */     }
/* 100 */     model.sortByColumn(0, true);
/*     */   }
/*     */ }


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp10\Exp10.zip!\Exp10\lib\jcommon-1.0.16.jar!\org\jfree\ui\SortableTable.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */