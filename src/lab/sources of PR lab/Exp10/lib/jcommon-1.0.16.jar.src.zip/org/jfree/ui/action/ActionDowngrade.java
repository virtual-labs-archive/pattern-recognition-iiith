package org.jfree.ui.action;

import javax.swing.Action;

public abstract interface ActionDowngrade
  extends Action
{
  public static final String ACCELERATOR_KEY = "AcceleratorKey";
  public static final String MNEMONIC_KEY = "MnemonicKey";
}


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp10\Exp10.zip!\Exp10\lib\jcommon-1.0.16.jar!\org\jfree\ui\action\ActionDowngrade.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */