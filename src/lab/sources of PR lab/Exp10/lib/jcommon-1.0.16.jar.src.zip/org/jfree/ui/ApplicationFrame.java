/*    */ package org.jfree.ui;
/*    */ 
/*    */ import java.awt.event.WindowEvent;
/*    */ import java.awt.event.WindowListener;
/*    */ import javax.swing.JFrame;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ApplicationFrame
/*    */   extends JFrame
/*    */   implements WindowListener
/*    */ {
/*    */   public ApplicationFrame(String title)
/*    */   {
/* 65 */     super(title);
/* 66 */     addWindowListener(this);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void windowClosing(WindowEvent event)
/*    */   {
/* 75 */     if (event.getWindow() == this) {
/* 76 */       dispose();
/* 77 */       System.exit(0);
/*    */     }
/*    */   }
/*    */   
/*    */   public void windowClosed(WindowEvent event) {}
/*    */   
/*    */   public void windowActivated(WindowEvent event) {}
/*    */   
/*    */   public void windowDeactivated(WindowEvent event) {}
/*    */   
/*    */   public void windowDeiconified(WindowEvent event) {}
/*    */   
/*    */   public void windowIconified(WindowEvent event) {}
/*    */   
/*    */   public void windowOpened(WindowEvent event) {}
/*    */ }


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp10\Exp10.zip!\Exp10\lib\jcommon-1.0.16.jar!\org\jfree\ui\ApplicationFrame.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */