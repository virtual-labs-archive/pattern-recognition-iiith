package org.jfree.base.modules;

public abstract interface ModuleInfo
{
  public abstract String getModuleClass();
  
  public abstract String getMajorVersion();
  
  public abstract String getMinorVersion();
  
  public abstract String getPatchLevel();
}


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp10\Exp10.zip!\Exp10\lib\jcommon-1.0.16.jar!\org\jfree\base\modules\ModuleInfo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */