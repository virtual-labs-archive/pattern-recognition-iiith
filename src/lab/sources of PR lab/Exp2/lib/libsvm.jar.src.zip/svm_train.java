/*     */ import java.io.PrintStream;
/*     */ import libsvm.svm_parameter;
/*     */ import libsvm.svm_problem;
/*     */ 
/*     */ class svm_train
/*     */ {
/*     */   private svm_parameter param;
/*     */   private svm_problem prob;
/*     */   private libsvm.svm_model model;
/*     */   private String input_file_name;
/*     */   private String model_file_name;
/*     */   private String error_msg;
/*     */   private int cross_validation;
/*     */   private int nr_fold;
/*  15 */   private static libsvm.svm_print_interface svm_print_null = new libsvm.svm_print_interface()
/*     */   {
/*     */     public void print(String paramAnonymousString) {}
/*     */   };
/*     */   
/*     */   private static void exit_with_help()
/*     */   {
/*  22 */     System.out.print("Usage: svm_train [options] training_set_file [model_file]\noptions:\n-s svm_type : set type of SVM (default 0)\n\t0 -- C-SVC\t\t(multi-class classification)\n\t1 -- nu-SVC\t\t(multi-class classification)\n\t2 -- one-class SVM\n\t3 -- epsilon-SVR\t(regression)\n\t4 -- nu-SVR\t\t(regression)\n-t kernel_type : set type of kernel function (default 2)\n\t0 -- linear: u'*v\n\t1 -- polynomial: (gamma*u'*v + coef0)^degree\n\t2 -- radial basis function: exp(-gamma*|u-v|^2)\n\t3 -- sigmoid: tanh(gamma*u'*v + coef0)\n\t4 -- precomputed kernel (kernel values in training_set_file)\n-d degree : set degree in kernel function (default 3)\n-g gamma : set gamma in kernel function (default 1/num_features)\n-r coef0 : set coef0 in kernel function (default 0)\n-c cost : set the parameter C of C-SVC, epsilon-SVR, and nu-SVR (default 1)\n-n nu : set the parameter nu of nu-SVC, one-class SVM, and nu-SVR (default 0.5)\n-p epsilon : set the epsilon in loss function of epsilon-SVR (default 0.1)\n-m cachesize : set cache memory size in MB (default 100)\n-e epsilon : set tolerance of termination criterion (default 0.001)\n-h shrinking : whether to use the shrinking heuristics, 0 or 1 (default 1)\n-b probability_estimates : whether to train a SVC or SVR model for probability estimates, 0 or 1 (default 0)\n-wi weight : set the parameter C of class i to weight*C, for C-SVC (default 1)\n-v n : n-fold cross validation mode\n-q : quiet mode (no outputs)\n");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  51 */     System.exit(1);
/*     */   }
/*     */   
/*     */ 
/*     */   private void do_cross_validation()
/*     */   {
/*  57 */     int j = 0;
/*  58 */     double d1 = 0.0D;
/*  59 */     double d2 = 0.0D;double d3 = 0.0D;double d4 = 0.0D;double d5 = 0.0D;double d6 = 0.0D;
/*  60 */     double[] arrayOfDouble = new double[this.prob.l];
/*     */     
/*  62 */     libsvm.svm.svm_cross_validation(this.prob, this.param, this.nr_fold, arrayOfDouble);
/*  63 */     int i; if ((this.param.svm_type == 3) || (this.param.svm_type == 4))
/*     */     {
/*     */ 
/*  66 */       for (i = 0; i < this.prob.l; i++)
/*     */       {
/*  68 */         double d7 = this.prob.y[i];
/*  69 */         double d8 = arrayOfDouble[i];
/*  70 */         d1 += (d8 - d7) * (d8 - d7);
/*  71 */         d2 += d8;
/*  72 */         d3 += d7;
/*  73 */         d4 += d8 * d8;
/*  74 */         d5 += d7 * d7;
/*  75 */         d6 += d8 * d7;
/*     */       }
/*  77 */       System.out.print("Cross Validation Mean squared error = " + d1 / this.prob.l + "\n");
/*  78 */       System.out.print("Cross Validation Squared correlation coefficient = " + (this.prob.l * d6 - d2 * d3) * (this.prob.l * d6 - d2 * d3) / ((this.prob.l * d4 - d2 * d2) * (this.prob.l * d5 - d3 * d3)) + "\n");
/*     */ 
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/*  85 */       for (i = 0; i < this.prob.l; i++)
/*  86 */         if (arrayOfDouble[i] == this.prob.y[i])
/*  87 */           j++;
/*  88 */       System.out.print("Cross Validation Accuracy = " + 100.0D * j / this.prob.l + "%\n");
/*     */     }
/*     */   }
/*     */   
/*     */   private void run(String[] paramArrayOfString) throws java.io.IOException
/*     */   {
/*  94 */     parse_command_line(paramArrayOfString);
/*  95 */     read_problem();
/*  96 */     this.error_msg = libsvm.svm.svm_check_parameter(this.prob, this.param);
/*     */     
/*  98 */     if (this.error_msg != null)
/*     */     {
/* 100 */       System.err.print("ERROR: " + this.error_msg + "\n");
/* 101 */       System.exit(1);
/*     */     }
/*     */     
/* 104 */     if (this.cross_validation != 0)
/*     */     {
/* 106 */       do_cross_validation();
/*     */     }
/*     */     else
/*     */     {
/* 110 */       this.model = libsvm.svm.svm_train(this.prob, this.param);
/* 111 */       libsvm.svm.svm_save_model(this.model_file_name, this.model);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void main(String[] paramArrayOfString) throws java.io.IOException
/*     */   {
/* 117 */     svm_train localsvm_train = new svm_train();
/* 118 */     localsvm_train.run(paramArrayOfString);
/*     */   }
/*     */   
/*     */   private static double atof(String paramString)
/*     */   {
/* 123 */     double d = Double.valueOf(paramString).doubleValue();
/* 124 */     if ((Double.isNaN(d)) || (Double.isInfinite(d)))
/*     */     {
/* 126 */       System.err.print("NaN or Infinity in input\n");
/* 127 */       System.exit(1);
/*     */     }
/* 129 */     return d;
/*     */   }
/*     */   
/*     */   private static int atoi(String paramString)
/*     */   {
/* 134 */     return Integer.parseInt(paramString);
/*     */   }
/*     */   
/*     */ 
/*     */   private void parse_command_line(String[] paramArrayOfString)
/*     */   {
/* 140 */     libsvm.svm_print_interface localsvm_print_interface = null;
/*     */     
/* 142 */     this.param = new svm_parameter();
/*     */     
/* 144 */     this.param.svm_type = 0;
/* 145 */     this.param.kernel_type = 2;
/* 146 */     this.param.degree = 3;
/* 147 */     this.param.gamma = 0.0D;
/* 148 */     this.param.coef0 = 0.0D;
/* 149 */     this.param.nu = 0.5D;
/* 150 */     this.param.cache_size = 100.0D;
/* 151 */     this.param.C = 1.0D;
/* 152 */     this.param.eps = 0.001D;
/* 153 */     this.param.p = 0.1D;
/* 154 */     this.param.shrinking = 1;
/* 155 */     this.param.probability = 0;
/* 156 */     this.param.nr_weight = 0;
/* 157 */     this.param.weight_label = new int[0];
/* 158 */     this.param.weight = new double[0];
/* 159 */     this.cross_validation = 0;
/*     */     
/*     */ 
/* 162 */     for (int i = 0; i < paramArrayOfString.length; i++)
/*     */     {
/* 164 */       if (paramArrayOfString[i].charAt(0) != '-') break;
/* 165 */       i++; if (i >= paramArrayOfString.length)
/* 166 */         exit_with_help();
/* 167 */       switch (paramArrayOfString[(i - 1)].charAt(1))
/*     */       {
/*     */       case 's': 
/* 170 */         this.param.svm_type = atoi(paramArrayOfString[i]);
/* 171 */         break;
/*     */       case 't': 
/* 173 */         this.param.kernel_type = atoi(paramArrayOfString[i]);
/* 174 */         break;
/*     */       case 'd': 
/* 176 */         this.param.degree = atoi(paramArrayOfString[i]);
/* 177 */         break;
/*     */       case 'g': 
/* 179 */         this.param.gamma = atof(paramArrayOfString[i]);
/* 180 */         break;
/*     */       case 'r': 
/* 182 */         this.param.coef0 = atof(paramArrayOfString[i]);
/* 183 */         break;
/*     */       case 'n': 
/* 185 */         this.param.nu = atof(paramArrayOfString[i]);
/* 186 */         break;
/*     */       case 'm': 
/* 188 */         this.param.cache_size = atof(paramArrayOfString[i]);
/* 189 */         break;
/*     */       case 'c': 
/* 191 */         this.param.C = atof(paramArrayOfString[i]);
/* 192 */         break;
/*     */       case 'e': 
/* 194 */         this.param.eps = atof(paramArrayOfString[i]);
/* 195 */         break;
/*     */       case 'p': 
/* 197 */         this.param.p = atof(paramArrayOfString[i]);
/* 198 */         break;
/*     */       case 'h': 
/* 200 */         this.param.shrinking = atoi(paramArrayOfString[i]);
/* 201 */         break;
/*     */       case 'b': 
/* 203 */         this.param.probability = atoi(paramArrayOfString[i]);
/* 204 */         break;
/*     */       case 'q': 
/* 206 */         localsvm_print_interface = svm_print_null;
/* 207 */         i--;
/* 208 */         break;
/*     */       case 'v': 
/* 210 */         this.cross_validation = 1;
/* 211 */         this.nr_fold = atoi(paramArrayOfString[i]);
/* 212 */         if (this.nr_fold < 2)
/*     */         {
/* 214 */           System.err.print("n-fold cross validation: n must >= 2\n");
/* 215 */           exit_with_help();
/*     */         }
/*     */         break;
/*     */       case 'w': 
/* 219 */         this.param.nr_weight += 1;
/*     */         
/* 221 */         Object localObject = this.param.weight_label;
/* 222 */         this.param.weight_label = new int[this.param.nr_weight];
/* 223 */         System.arraycopy(localObject, 0, this.param.weight_label, 0, this.param.nr_weight - 1);
/*     */         
/*     */ 
/*     */ 
/* 227 */         localObject = this.param.weight;
/* 228 */         this.param.weight = new double[this.param.nr_weight];
/* 229 */         System.arraycopy(localObject, 0, this.param.weight, 0, this.param.nr_weight - 1);
/*     */         
/*     */ 
/* 232 */         this.param.weight_label[(this.param.nr_weight - 1)] = atoi(paramArrayOfString[(i - 1)].substring(2));
/* 233 */         this.param.weight[(this.param.nr_weight - 1)] = atof(paramArrayOfString[i]);
/* 234 */         break;
/*     */       case 'f': case 'i': case 'j': case 'k': case 'l': case 'o': case 'u': default: 
/* 236 */         System.err.print("Unknown option: " + paramArrayOfString[(i - 1)] + "\n");
/* 237 */         exit_with_help();
/*     */       }
/*     */       
/*     */     }
/* 241 */     libsvm.svm.svm_set_print_string_function(localsvm_print_interface);
/*     */     
/*     */ 
/*     */ 
/* 245 */     if (i >= paramArrayOfString.length) {
/* 246 */       exit_with_help();
/*     */     }
/* 248 */     this.input_file_name = paramArrayOfString[i];
/*     */     
/* 250 */     if (i < paramArrayOfString.length - 1) {
/* 251 */       this.model_file_name = paramArrayOfString[(i + 1)];
/*     */     }
/*     */     else {
/* 254 */       int j = paramArrayOfString[i].lastIndexOf('/');
/* 255 */       j++;
/* 256 */       this.model_file_name = (paramArrayOfString[i].substring(j) + ".model");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void read_problem()
/*     */     throws java.io.IOException
/*     */   {
/* 264 */     java.io.BufferedReader localBufferedReader = new java.io.BufferedReader(new java.io.FileReader(this.input_file_name));
/* 265 */     java.util.Vector localVector1 = new java.util.Vector();
/* 266 */     java.util.Vector localVector2 = new java.util.Vector();
/* 267 */     int i = 0;
/*     */     
/*     */     for (;;)
/*     */     {
/* 271 */       String str = localBufferedReader.readLine();
/* 272 */       if (str == null)
/*     */         break;
/* 274 */       java.util.StringTokenizer localStringTokenizer = new java.util.StringTokenizer(str, " \t\n\r\f:");
/*     */       
/* 276 */       localVector1.addElement(Double.valueOf(atof(localStringTokenizer.nextToken())));
/* 277 */       int k = localStringTokenizer.countTokens() / 2;
/* 278 */       libsvm.svm_node[] arrayOfsvm_node = new libsvm.svm_node[k];
/* 279 */       for (int m = 0; m < k; m++)
/*     */       {
/* 281 */         arrayOfsvm_node[m] = new libsvm.svm_node();
/* 282 */         arrayOfsvm_node[m].index = atoi(localStringTokenizer.nextToken());
/* 283 */         arrayOfsvm_node[m].value = atof(localStringTokenizer.nextToken());
/*     */       }
/* 285 */       if (k > 0) i = Math.max(i, arrayOfsvm_node[(k - 1)].index);
/* 286 */       localVector2.addElement(arrayOfsvm_node);
/*     */     }
/*     */     
/* 289 */     this.prob = new svm_problem();
/* 290 */     this.prob.l = localVector1.size();
/* 291 */     this.prob.x = new libsvm.svm_node[this.prob.l][];
/* 292 */     for (int j = 0; j < this.prob.l; j++)
/* 293 */       this.prob.x[j] = ((libsvm.svm_node[])localVector2.elementAt(j));
/* 294 */     this.prob.y = new double[this.prob.l];
/* 295 */     for (j = 0; j < this.prob.l; j++) {
/* 296 */       this.prob.y[j] = ((Double)localVector1.elementAt(j)).doubleValue();
/*     */     }
/* 298 */     if ((this.param.gamma == 0.0D) && (i > 0)) {
/* 299 */       this.param.gamma = (1.0D / i);
/*     */     }
/* 301 */     if (this.param.kernel_type == 4) {
/* 302 */       for (j = 0; j < this.prob.l; j++)
/*     */       {
/* 304 */         if (this.prob.x[j][0].index != 0)
/*     */         {
/* 306 */           System.err.print("Wrong kernel matrix: first column must be 0:sample_serial_number\n");
/* 307 */           System.exit(1);
/*     */         }
/* 309 */         if (((int)this.prob.x[j][0].value <= 0) || ((int)this.prob.x[j][0].value > i))
/*     */         {
/* 311 */           System.err.print("Wrong input format: sample_serial_number out of range\n");
/* 312 */           System.exit(1);
/*     */         }
/*     */       }
/*     */     }
/* 316 */     localBufferedReader.close();
/*     */   }
/*     */ }


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp2\Exp2.zip!\Exp2\lib\libsvm.jar!\svm_train.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */