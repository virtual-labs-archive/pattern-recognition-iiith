/*     */ import java.awt.Button;
/*     */ import java.awt.Color;
/*     */ import java.awt.FileDialog;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.Panel;
/*     */ import java.awt.TextField;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.Vector;
/*     */ import libsvm.svm_node;
/*     */ import libsvm.svm_parameter;
/*     */ 
/*     */ public class svm_toy extends java.applet.Applet
/*     */ {
/*     */   static final String DEFAULT_PARAM = "-t 2 -c 100";
/*     */   int XLEN;
/*     */   int YLEN;
/*     */   java.awt.Image buffer;
/*     */   Graphics buffer_gc;
/*  21 */   static final Color[] colors = { new Color(0, 0, 0), new Color(0, 120, 120), new Color(120, 120, 0), new Color(120, 0, 120), new Color(0, 200, 200), new Color(200, 200, 0), new Color(200, 0, 200) };
/*     */   
/*     */ 
/*     */   class point
/*     */   {
/*     */     double x;
/*     */     
/*     */     double y;
/*     */     
/*     */     byte value;
/*     */     
/*     */ 
/*     */     point(double paramDouble1, double paramDouble2, byte paramByte)
/*     */     {
/*  35 */       this.x = paramDouble1;
/*  36 */       this.y = paramDouble2;
/*  37 */       this.value = paramByte;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*  43 */   Vector<svm_toy.point> point_list = new Vector();
/*  44 */   byte current_value = 1;
/*     */   
/*     */   public void init()
/*     */   {
/*  48 */     setSize(getSize());
/*     */     
/*  50 */     final Button localButton1 = new Button("Change");
/*  51 */     Button localButton2 = new Button("Run");
/*  52 */     Button localButton3 = new Button("Clear");
/*  53 */     Button localButton4 = new Button("Save");
/*  54 */     Button localButton5 = new Button("Load");
/*  55 */     final TextField localTextField = new TextField("-t 2 -c 100");
/*     */     
/*  57 */     java.awt.BorderLayout localBorderLayout = new java.awt.BorderLayout();
/*  58 */     setLayout(localBorderLayout);
/*     */     
/*  60 */     Panel localPanel = new Panel();
/*  61 */     GridBagLayout localGridBagLayout = new GridBagLayout();
/*  62 */     localPanel.setLayout(localGridBagLayout);
/*     */     
/*  64 */     java.awt.GridBagConstraints localGridBagConstraints = new java.awt.GridBagConstraints();
/*  65 */     localGridBagConstraints.fill = 2;
/*  66 */     localGridBagConstraints.weightx = 1.0D;
/*  67 */     localGridBagConstraints.gridwidth = 1;
/*  68 */     localGridBagLayout.setConstraints(localButton1, localGridBagConstraints);
/*  69 */     localGridBagLayout.setConstraints(localButton2, localGridBagConstraints);
/*  70 */     localGridBagLayout.setConstraints(localButton3, localGridBagConstraints);
/*  71 */     localGridBagLayout.setConstraints(localButton4, localGridBagConstraints);
/*  72 */     localGridBagLayout.setConstraints(localButton5, localGridBagConstraints);
/*  73 */     localGridBagConstraints.weightx = 5.0D;
/*  74 */     localGridBagConstraints.gridwidth = 5;
/*  75 */     localGridBagLayout.setConstraints(localTextField, localGridBagConstraints);
/*     */     
/*  77 */     localButton1.setBackground(colors[this.current_value]);
/*     */     
/*  79 */     localPanel.add(localButton1);
/*  80 */     localPanel.add(localButton2);
/*  81 */     localPanel.add(localButton3);
/*  82 */     localPanel.add(localButton4);
/*  83 */     localPanel.add(localButton5);
/*  84 */     localPanel.add(localTextField);
/*  85 */     add(localPanel, "South");
/*     */     
/*  87 */     localButton1.addActionListener(new java.awt.event.ActionListener() {
/*     */       public void actionPerformed(ActionEvent paramAnonymousActionEvent) {
/*  89 */         svm_toy.this.button_change_clicked();localButton1.setBackground(svm_toy.colors[svm_toy.this.current_value]);
/*  90 */       } });
/*  91 */     localButton2.addActionListener(new java.awt.event.ActionListener()
/*     */     {
/*  93 */       public void actionPerformed(ActionEvent paramAnonymousActionEvent) { svm_toy.this.button_run_clicked(localTextField.getText()); }
/*  94 */     });
/*  95 */     localButton3.addActionListener(new java.awt.event.ActionListener()
/*     */     {
/*  97 */       public void actionPerformed(ActionEvent paramAnonymousActionEvent) { svm_toy.this.button_clear_clicked(); }
/*  98 */     });
/*  99 */     localButton4.addActionListener(new java.awt.event.ActionListener()
/*     */     {
/* 101 */       public void actionPerformed(ActionEvent paramAnonymousActionEvent) { svm_toy.this.button_save_clicked(localTextField.getText()); }
/* 102 */     });
/* 103 */     localButton5.addActionListener(new java.awt.event.ActionListener()
/*     */     {
/* 105 */       public void actionPerformed(ActionEvent paramAnonymousActionEvent) { svm_toy.this.button_load_clicked(); }
/* 106 */     });
/* 107 */     localTextField.addActionListener(new java.awt.event.ActionListener()
/*     */     {
/* 109 */       public void actionPerformed(ActionEvent paramAnonymousActionEvent) { svm_toy.this.button_run_clicked(localTextField.getText()); }
/* 110 */     });
/* 111 */     enableEvents(16L);
/*     */   }
/*     */   
/*     */   void draw_point(svm_toy.point parampoint)
/*     */   {
/* 116 */     Color localColor = colors[(parampoint.value + 3)];
/*     */     
/* 118 */     Graphics localGraphics = getGraphics();
/* 119 */     this.buffer_gc.setColor(localColor);
/* 120 */     this.buffer_gc.fillRect((int)(parampoint.x * this.XLEN), (int)(parampoint.y * this.YLEN), 4, 4);
/* 121 */     localGraphics.setColor(localColor);
/* 122 */     localGraphics.fillRect((int)(parampoint.x * this.XLEN), (int)(parampoint.y * this.YLEN), 4, 4);
/*     */   }
/*     */   
/*     */   void clear_all()
/*     */   {
/* 127 */     this.point_list.removeAllElements();
/* 128 */     if (this.buffer != null)
/*     */     {
/* 130 */       this.buffer_gc.setColor(colors[0]);
/* 131 */       this.buffer_gc.fillRect(0, 0, this.XLEN, this.YLEN);
/*     */     }
/* 133 */     repaint();
/*     */   }
/*     */   
/*     */   void draw_all_points()
/*     */   {
/* 138 */     int i = this.point_list.size();
/* 139 */     for (int j = 0; j < i; j++) {
/* 140 */       draw_point((svm_toy.point)this.point_list.elementAt(j));
/*     */     }
/*     */   }
/*     */   
/*     */   void button_change_clicked() {
/* 145 */     this.current_value = ((byte)(this.current_value + 1));
/* 146 */     if (this.current_value > 3) this.current_value = 1;
/*     */   }
/*     */   
/*     */   private static double atof(String paramString)
/*     */   {
/* 151 */     return Double.valueOf(paramString).doubleValue();
/*     */   }
/*     */   
/*     */   private static int atoi(String paramString)
/*     */   {
/* 156 */     return Integer.parseInt(paramString);
/*     */   }
/*     */   
/*     */ 
/*     */   void button_run_clicked(String paramString)
/*     */   {
/* 162 */     if (this.point_list.isEmpty()) { return;
/*     */     }
/* 164 */     svm_parameter localsvm_parameter = new svm_parameter();
/*     */     
/*     */ 
/* 167 */     localsvm_parameter.svm_type = 0;
/* 168 */     localsvm_parameter.kernel_type = 2;
/* 169 */     localsvm_parameter.degree = 3;
/* 170 */     localsvm_parameter.gamma = 0.0D;
/* 171 */     localsvm_parameter.coef0 = 0.0D;
/* 172 */     localsvm_parameter.nu = 0.5D;
/* 173 */     localsvm_parameter.cache_size = 40.0D;
/* 174 */     localsvm_parameter.C = 1.0D;
/* 175 */     localsvm_parameter.eps = 0.001D;
/* 176 */     localsvm_parameter.p = 0.1D;
/* 177 */     localsvm_parameter.shrinking = 1;
/* 178 */     localsvm_parameter.probability = 0;
/* 179 */     localsvm_parameter.nr_weight = 0;
/* 180 */     localsvm_parameter.weight_label = new int[0];
/* 181 */     localsvm_parameter.weight = new double[0];
/*     */     
/*     */ 
/* 184 */     StringTokenizer localStringTokenizer = new StringTokenizer(paramString);
/* 185 */     String[] arrayOfString = new String[localStringTokenizer.countTokens()];
/* 186 */     for (int i = 0; i < arrayOfString.length; i++) {
/* 187 */       arrayOfString[i] = localStringTokenizer.nextToken();
/*     */     }
/* 189 */     for (i = 0; i < arrayOfString.length; i++)
/*     */     {
/* 191 */       if (arrayOfString[i].charAt(0) != '-') break;
/* 192 */       i++; if (i >= arrayOfString.length)
/*     */       {
/* 194 */         System.err.print("unknown option\n");
/* 195 */         break;
/*     */       }
/* 197 */       switch (arrayOfString[(i - 1)].charAt(1))
/*     */       {
/*     */       case 's': 
/* 200 */         localsvm_parameter.svm_type = atoi(arrayOfString[i]);
/* 201 */         break;
/*     */       case 't': 
/* 203 */         localsvm_parameter.kernel_type = atoi(arrayOfString[i]);
/* 204 */         break;
/*     */       case 'd': 
/* 206 */         localsvm_parameter.degree = atoi(arrayOfString[i]);
/* 207 */         break;
/*     */       case 'g': 
/* 209 */         localsvm_parameter.gamma = atof(arrayOfString[i]);
/* 210 */         break;
/*     */       case 'r': 
/* 212 */         localsvm_parameter.coef0 = atof(arrayOfString[i]);
/* 213 */         break;
/*     */       case 'n': 
/* 215 */         localsvm_parameter.nu = atof(arrayOfString[i]);
/* 216 */         break;
/*     */       case 'm': 
/* 218 */         localsvm_parameter.cache_size = atof(arrayOfString[i]);
/* 219 */         break;
/*     */       case 'c': 
/* 221 */         localsvm_parameter.C = atof(arrayOfString[i]);
/* 222 */         break;
/*     */       case 'e': 
/* 224 */         localsvm_parameter.eps = atof(arrayOfString[i]);
/* 225 */         break;
/*     */       case 'p': 
/* 227 */         localsvm_parameter.p = atof(arrayOfString[i]);
/* 228 */         break;
/*     */       case 'h': 
/* 230 */         localsvm_parameter.shrinking = atoi(arrayOfString[i]);
/* 231 */         break;
/*     */       case 'b': 
/* 233 */         localsvm_parameter.probability = atoi(arrayOfString[i]);
/* 234 */         break;
/*     */       case 'w': 
/* 236 */         localsvm_parameter.nr_weight += 1;
/*     */         
/* 238 */         Object localObject1 = localsvm_parameter.weight_label;
/* 239 */         localsvm_parameter.weight_label = new int[localsvm_parameter.nr_weight];
/* 240 */         System.arraycopy(localObject1, 0, localsvm_parameter.weight_label, 0, localsvm_parameter.nr_weight - 1);
/*     */         
/*     */ 
/*     */ 
/* 244 */         localObject1 = localsvm_parameter.weight;
/* 245 */         localsvm_parameter.weight = new double[localsvm_parameter.nr_weight];
/* 246 */         System.arraycopy(localObject1, 0, localsvm_parameter.weight, 0, localsvm_parameter.nr_weight - 1);
/*     */         
/*     */ 
/* 249 */         localsvm_parameter.weight_label[(localsvm_parameter.nr_weight - 1)] = atoi(arrayOfString[(i - 1)].substring(2));
/* 250 */         localsvm_parameter.weight[(localsvm_parameter.nr_weight - 1)] = atof(arrayOfString[i]);
/* 251 */         break;
/*     */       case 'f': case 'i': case 'j': case 'k': case 'l': case 'o': case 'q': case 'u': case 'v': default: 
/* 253 */         System.err.print("unknown option\n");
/*     */       }
/*     */       
/*     */     }
/*     */     
/* 258 */     libsvm.svm_problem localsvm_problem = new libsvm.svm_problem();
/* 259 */     localsvm_problem.l = this.point_list.size();
/* 260 */     localsvm_problem.y = new double[localsvm_problem.l];
/*     */     
/* 262 */     if (localsvm_parameter.kernel_type != 4) { Object localObject2;
/*     */       Object localObject3;
/*     */       int n;
/* 265 */       if ((localsvm_parameter.svm_type == 3) || (localsvm_parameter.svm_type == 4))
/*     */       {
/*     */ 
/* 268 */         if (localsvm_parameter.gamma == 0.0D) localsvm_parameter.gamma = 1.0D;
/* 269 */         localsvm_problem.x = new svm_node[localsvm_problem.l][1];
/* 270 */         for (int j = 0; j < localsvm_problem.l; j++)
/*     */         {
/* 272 */           localObject2 = (svm_toy.point)this.point_list.elementAt(j);
/* 273 */           localsvm_problem.x[j][0] = new svm_node();
/* 274 */           localsvm_problem.x[j][0].index = 1;
/* 275 */           localsvm_problem.x[j][0].value = ((svm_toy.point)localObject2).x;
/* 276 */           localsvm_problem.y[j] = ((svm_toy.point)localObject2).y;
/*     */         }
/*     */         
/*     */ 
/* 280 */         libsvm.svm_model localsvm_model1 = libsvm.svm.svm_train(localsvm_problem, localsvm_parameter);
/* 281 */         localObject2 = new svm_node[1];
/* 282 */         localObject2[0] = new svm_node();
/* 283 */         localObject2[0].index = 1;
/* 284 */         localObject3 = new int[this.XLEN];
/*     */         
/* 286 */         Graphics localGraphics = getGraphics();
/* 287 */         for (n = 0; n < this.XLEN; n++)
/*     */         {
/* 289 */           localObject2[0].value = (n / this.XLEN);
/* 290 */           localObject3[n] = ((int)(this.YLEN * libsvm.svm.svm_predict(localsvm_model1, (svm_node[])localObject2)));
/*     */         }
/*     */         
/* 293 */         this.buffer_gc.setColor(colors[0]);
/* 294 */         this.buffer_gc.drawLine(0, 0, 0, this.YLEN - 1);
/* 295 */         localGraphics.setColor(colors[0]);
/* 296 */         localGraphics.drawLine(0, 0, 0, this.YLEN - 1);
/*     */         
/* 298 */         n = (int)(localsvm_parameter.p * this.YLEN);
/* 299 */         for (int i1 = 1; i1 < this.XLEN; i1++)
/*     */         {
/* 301 */           this.buffer_gc.setColor(colors[0]);
/* 302 */           this.buffer_gc.drawLine(i1, 0, i1, this.YLEN - 1);
/* 303 */           localGraphics.setColor(colors[0]);
/* 304 */           localGraphics.drawLine(i1, 0, i1, this.YLEN - 1);
/*     */           
/* 306 */           this.buffer_gc.setColor(colors[5]);
/* 307 */           localGraphics.setColor(colors[5]);
/* 308 */           this.buffer_gc.drawLine(i1 - 1, localObject3[(i1 - 1)], i1, localObject3[i1]);
/* 309 */           localGraphics.drawLine(i1 - 1, localObject3[(i1 - 1)], i1, localObject3[i1]);
/*     */           
/* 311 */           if (localsvm_parameter.svm_type == 3)
/*     */           {
/* 313 */             this.buffer_gc.setColor(colors[2]);
/* 314 */             localGraphics.setColor(colors[2]);
/* 315 */             this.buffer_gc.drawLine(i1 - 1, localObject3[(i1 - 1)] + n, i1, localObject3[i1] + n);
/* 316 */             localGraphics.drawLine(i1 - 1, localObject3[(i1 - 1)] + n, i1, localObject3[i1] + n);
/*     */             
/* 318 */             this.buffer_gc.setColor(colors[2]);
/* 319 */             localGraphics.setColor(colors[2]);
/* 320 */             this.buffer_gc.drawLine(i1 - 1, localObject3[(i1 - 1)] - n, i1, localObject3[i1] - n);
/* 321 */             localGraphics.drawLine(i1 - 1, localObject3[(i1 - 1)] - n, i1, localObject3[i1] - n);
/*     */           }
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 327 */         if (localsvm_parameter.gamma == 0.0D) localsvm_parameter.gamma = 0.5D;
/* 328 */         localsvm_problem.x = new svm_node[localsvm_problem.l][2];
/* 329 */         for (int k = 0; k < localsvm_problem.l; k++)
/*     */         {
/* 331 */           localObject2 = (svm_toy.point)this.point_list.elementAt(k);
/* 332 */           localsvm_problem.x[k][0] = new svm_node();
/* 333 */           localsvm_problem.x[k][0].index = 1;
/* 334 */           localsvm_problem.x[k][0].value = ((svm_toy.point)localObject2).x;
/* 335 */           localsvm_problem.x[k][1] = new svm_node();
/* 336 */           localsvm_problem.x[k][1].index = 2;
/* 337 */           localsvm_problem.x[k][1].value = ((svm_toy.point)localObject2).y;
/* 338 */           localsvm_problem.y[k] = ((svm_toy.point)localObject2).value;
/*     */         }
/*     */         
/*     */ 
/* 342 */         libsvm.svm_model localsvm_model2 = libsvm.svm.svm_train(localsvm_problem, localsvm_parameter);
/* 343 */         localObject2 = new svm_node[2];
/* 344 */         localObject2[0] = new svm_node();
/* 345 */         localObject2[1] = new svm_node();
/* 346 */         localObject2[0].index = 1;
/* 347 */         localObject2[1].index = 2;
/*     */         
/* 349 */         localObject3 = getGraphics();
/* 350 */         for (int m = 0; m < this.XLEN; m++)
/* 351 */           for (n = 0; n < this.YLEN; n++) {
/* 352 */             localObject2[0].value = (m / this.XLEN);
/* 353 */             localObject2[1].value = (n / this.YLEN);
/* 354 */             double d = libsvm.svm.svm_predict(localsvm_model2, (svm_node[])localObject2);
/* 355 */             if ((localsvm_parameter.svm_type == 2) && (d < 0.0D)) d = 2.0D;
/* 356 */             this.buffer_gc.setColor(colors[((int)d)]);
/* 357 */             ((Graphics)localObject3).setColor(colors[((int)d)]);
/* 358 */             this.buffer_gc.drawLine(m, n, m, n);
/* 359 */             ((Graphics)localObject3).drawLine(m, n, m, n);
/*     */           }
/*     */       }
/*     */     }
/* 363 */     draw_all_points();
/*     */   }
/*     */   
/*     */   void button_clear_clicked()
/*     */   {
/* 368 */     clear_all();
/*     */   }
/*     */   
/*     */   void button_save_clicked(String paramString)
/*     */   {
/* 373 */     FileDialog localFileDialog = new FileDialog(new java.awt.Frame(), "Save", 1);
/* 374 */     localFileDialog.setVisible(true);
/* 375 */     String str = localFileDialog.getDirectory() + localFileDialog.getFile();
/* 376 */     if (str == null) return;
/*     */     try {
/* 378 */       java.io.DataOutputStream localDataOutputStream = new java.io.DataOutputStream(new java.io.BufferedOutputStream(new java.io.FileOutputStream(str)));
/*     */       
/* 380 */       int i = 0;
/* 381 */       int j = paramString.indexOf("-s ");
/* 382 */       if (j != -1)
/*     */       {
/* 384 */         StringTokenizer localStringTokenizer = new StringTokenizer(paramString.substring(j + 2).trim());
/* 385 */         i = atoi(localStringTokenizer.nextToken());
/*     */       }
/*     */       
/* 388 */       int k = this.point_list.size();
/* 389 */       int m; svm_toy.point localpoint; if ((i == 3) || (i == 4))
/*     */       {
/* 391 */         for (m = 0; m < k; m++)
/*     */         {
/* 393 */           localpoint = (svm_toy.point)this.point_list.elementAt(m);
/* 394 */           localDataOutputStream.writeBytes(localpoint.y + " 1:" + localpoint.x + "\n");
/*     */         }
/*     */         
/*     */       }
/*     */       else {
/* 399 */         for (m = 0; m < k; m++)
/*     */         {
/* 401 */           localpoint = (svm_toy.point)this.point_list.elementAt(m);
/* 402 */           localDataOutputStream.writeBytes(localpoint.value + " 1:" + localpoint.x + " 2:" + localpoint.y + "\n");
/*     */         }
/*     */       }
/* 405 */       localDataOutputStream.close();
/* 406 */     } catch (java.io.IOException localIOException) { System.err.print(localIOException);
/*     */     }
/*     */   }
/*     */   
/*     */   void button_load_clicked() {
/* 411 */     FileDialog localFileDialog = new FileDialog(new java.awt.Frame(), "Load", 0);
/* 412 */     localFileDialog.setVisible(true);
/* 413 */     String str1 = localFileDialog.getDirectory() + localFileDialog.getFile();
/* 414 */     if (str1 == null) return;
/* 415 */     clear_all();
/*     */     try {
/* 417 */       java.io.BufferedReader localBufferedReader = new java.io.BufferedReader(new java.io.FileReader(str1));
/*     */       String str2;
/* 419 */       while ((str2 = localBufferedReader.readLine()) != null)
/*     */       {
/* 421 */         StringTokenizer localStringTokenizer = new StringTokenizer(str2, " \t\n\r\f:");
/* 422 */         if (localStringTokenizer.countTokens() == 5)
/*     */         {
/* 424 */           byte b = (byte)atoi(localStringTokenizer.nextToken());
/* 425 */           localStringTokenizer.nextToken();
/* 426 */           double d2 = atof(localStringTokenizer.nextToken());
/* 427 */           localStringTokenizer.nextToken();
/* 428 */           double d4 = atof(localStringTokenizer.nextToken());
/* 429 */           this.point_list.addElement(new svm_toy.point(d2, d4, b));
/*     */         } else {
/* 431 */           if (localStringTokenizer.countTokens() != 3)
/*     */             break;
/* 433 */           double d1 = atof(localStringTokenizer.nextToken());
/* 434 */           localStringTokenizer.nextToken();
/* 435 */           double d3 = atof(localStringTokenizer.nextToken());
/* 436 */           this.point_list.addElement(new svm_toy.point(d3, d1, this.current_value));
/*     */         }
/*     */       }
/*     */       
/* 440 */       localBufferedReader.close();
/* 441 */     } catch (java.io.IOException localIOException) { System.err.print(localIOException); }
/* 442 */     draw_all_points();
/*     */   }
/*     */   
/*     */   protected void processMouseEvent(java.awt.event.MouseEvent paramMouseEvent)
/*     */   {
/* 447 */     if (paramMouseEvent.getID() == 501)
/*     */     {
/* 449 */       if ((paramMouseEvent.getX() >= this.XLEN) || (paramMouseEvent.getY() >= this.YLEN)) return;
/* 450 */       svm_toy.point localpoint = new svm_toy.point(paramMouseEvent.getX() / this.XLEN, paramMouseEvent.getY() / this.YLEN, this.current_value);
/*     */       
/*     */ 
/* 453 */       this.point_list.addElement(localpoint);
/* 454 */       draw_point(localpoint);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void paint(Graphics paramGraphics)
/*     */   {
/* 461 */     if (this.buffer == null) {
/* 462 */       this.buffer = createImage(this.XLEN, this.YLEN);
/* 463 */       this.buffer_gc = this.buffer.getGraphics();
/* 464 */       this.buffer_gc.setColor(colors[0]);
/* 465 */       this.buffer_gc.fillRect(0, 0, this.XLEN, this.YLEN);
/*     */     }
/* 467 */     paramGraphics.drawImage(this.buffer, 0, 0, this);
/*     */   }
/*     */   
/* 470 */   public java.awt.Dimension getPreferredSize() { return new java.awt.Dimension(this.XLEN, this.YLEN + 50); }
/*     */   
/* 472 */   public void setSize(java.awt.Dimension paramDimension) { setSize(paramDimension.width, paramDimension.height); }
/*     */   
/* 474 */   public void setSize(int paramInt1, int paramInt2) { super.setSize(paramInt1, paramInt2);
/* 475 */     this.XLEN = paramInt1;
/* 476 */     this.YLEN = (paramInt2 - 50);
/* 477 */     clear_all();
/*     */   }
/*     */   
/*     */   public static void main(String[] paramArrayOfString)
/*     */   {
/* 482 */     new AppletFrame("svm_toy", new svm_toy(), 500, 550);
/*     */   }
/*     */ }


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp2\Exp2.zip!\Exp2\lib\libsvm.jar!\svm_toy.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */