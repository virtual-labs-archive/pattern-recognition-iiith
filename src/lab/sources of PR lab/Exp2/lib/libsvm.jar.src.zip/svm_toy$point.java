/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class svm_toy$point
/*    */ {
/*    */   double x;
/*    */   double y;
/*    */   byte value;
/*    */   
/*    */   svm_toy$point(svm_toy paramsvm_toy, double paramDouble1, double paramDouble2, byte paramByte)
/*    */   {
/* 35 */     this.x = paramDouble1;
/* 36 */     this.y = paramDouble2;
/* 37 */     this.value = paramByte;
/*    */   }
/*    */ }


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp2\Exp2.zip!\Exp2\lib\libsvm.jar!\svm_toy$point.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */