package libsvm;

import java.io.Serializable;

public class svm_node
  implements Serializable
{
  public int index;
  public double value;
}


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp2\Exp2.zip!\Exp2\lib\libsvm.jar!\libsvm\svm_node.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */