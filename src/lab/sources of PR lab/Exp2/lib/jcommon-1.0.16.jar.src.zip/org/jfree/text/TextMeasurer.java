package org.jfree.text;

public abstract interface TextMeasurer
{
  public abstract float getStringWidth(String paramString, int paramInt1, int paramInt2);
}


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp2\Exp2.zip!\Exp2\lib\jcommon-1.0.16.jar!\org\jfree\text\TextMeasurer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */