package org.jfree.ui;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

public abstract interface Drawable
{
  public abstract void draw(Graphics2D paramGraphics2D, Rectangle2D paramRectangle2D);
}


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp2\Exp2.zip!\Exp2\lib\jcommon-1.0.16.jar!\org\jfree\ui\Drawable.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */