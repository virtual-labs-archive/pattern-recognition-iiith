package org.jfree.base.modules;

public abstract interface Module
  extends ModuleInfo
{
  public abstract ModuleInfo[] getRequiredModules();
  
  public abstract ModuleInfo[] getOptionalModules();
  
  public abstract void initialize(SubSystem paramSubSystem)
    throws ModuleInitializeException;
  
  public abstract void configure(SubSystem paramSubSystem);
  
  public abstract String getDescription();
  
  public abstract String getProducer();
  
  public abstract String getName();
  
  public abstract String getSubSystem();
}


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp2\Exp2.zip!\Exp2\lib\jcommon-1.0.16.jar!\org\jfree\base\modules\Module.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */