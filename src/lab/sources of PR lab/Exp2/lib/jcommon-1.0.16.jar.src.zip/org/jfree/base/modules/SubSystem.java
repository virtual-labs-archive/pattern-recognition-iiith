package org.jfree.base.modules;

import org.jfree.util.Configuration;
import org.jfree.util.ExtendedConfiguration;

public abstract interface SubSystem
{
  public abstract Configuration getGlobalConfig();
  
  public abstract ExtendedConfiguration getExtendedConfig();
  
  public abstract PackageManager getPackageManager();
}


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp2\Exp2.zip!\Exp2\lib\jcommon-1.0.16.jar!\org\jfree\base\modules\SubSystem.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */