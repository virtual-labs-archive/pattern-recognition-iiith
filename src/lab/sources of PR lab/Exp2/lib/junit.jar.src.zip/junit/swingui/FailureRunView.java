/*     */ package junit.swingui;
/*     */ 
/*     */ import javax.swing.DefaultListCellRenderer;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JList;
/*     */ import javax.swing.JTabbedPane;
/*     */ import javax.swing.ListModel;
/*     */ import javax.swing.event.ListSelectionEvent;
/*     */ import junit.framework.Test;
/*     */ import junit.framework.TestFailure;
/*     */ import junit.framework.TestResult;
/*     */ 
/*     */ public class FailureRunView implements TestRunView
/*     */ {
/*     */   JList fFailureList;
/*     */   TestRunContext fRunContext;
/*     */   
/*     */   static class FailureListCellRenderer extends DefaultListCellRenderer
/*     */   {
/*     */     private Icon fFailureIcon;
/*     */     private Icon fErrorIcon;
/*     */     
/*     */     FailureListCellRenderer()
/*     */     {
/*  27 */       loadIcons();
/*     */     }
/*     */     
/*     */     void loadIcons() {
/*  31 */       this.fFailureIcon = TestRunner.getIconResource(getClass(), "icons/failure.gif");
/*  32 */       this.fErrorIcon = TestRunner.getIconResource(getClass(), "icons/error.gif");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public java.awt.Component getListCellRendererComponent(JList list, Object value, int modelIndex, boolean isSelected, boolean cellHasFocus)
/*     */     {
/*  39 */       java.awt.Component c = super.getListCellRendererComponent(list, value, modelIndex, isSelected, cellHasFocus);
/*  40 */       TestFailure failure = (TestFailure)value;
/*  41 */       String text = failure.failedTest().toString();
/*  42 */       String msg = failure.exceptionMessage();
/*  43 */       if (msg != null) {
/*  44 */         text = text + ":" + junit.runner.BaseTestRunner.truncate(msg);
/*     */       }
/*  46 */       if (failure.isFailure()) {
/*  47 */         if (this.fFailureIcon != null) {
/*  48 */           setIcon(this.fFailureIcon);
/*     */         }
/*  50 */       } else if (this.fErrorIcon != null) {
/*  51 */         setIcon(this.fErrorIcon);
/*     */       }
/*  53 */       setText(text);
/*  54 */       setToolTipText(text);
/*  55 */       return c;
/*     */     }
/*     */   }
/*     */   
/*     */   public FailureRunView(TestRunContext context) {
/*  60 */     this.fRunContext = context;
/*  61 */     this.fFailureList = new JList(this.fRunContext.getFailures());
/*  62 */     this.fFailureList.setFont(new java.awt.Font("Dialog", 0, 12));
/*     */     
/*  64 */     this.fFailureList.setSelectionMode(0);
/*  65 */     this.fFailureList.setCellRenderer(new FailureListCellRenderer());
/*  66 */     this.fFailureList.setVisibleRowCount(5);
/*     */     
/*  68 */     this.fFailureList.addListSelectionListener(
/*  69 */       new javax.swing.event.ListSelectionListener() {
/*     */         public void valueChanged(ListSelectionEvent e) {
/*  71 */           FailureRunView.this.testSelected();
/*     */         }
/*     */       });
/*     */   }
/*     */   
/*     */   public Test getSelectedTest()
/*     */   {
/*  78 */     int index = this.fFailureList.getSelectedIndex();
/*  79 */     if (index == -1) {
/*  80 */       return null;
/*     */     }
/*  82 */     ListModel model = this.fFailureList.getModel();
/*  83 */     TestFailure failure = (TestFailure)model.getElementAt(index);
/*  84 */     return failure.failedTest();
/*     */   }
/*     */   
/*     */   public void activate() {
/*  88 */     testSelected();
/*     */   }
/*     */   
/*     */   public void addTab(JTabbedPane pane) {
/*  92 */     javax.swing.JScrollPane scrollPane = new javax.swing.JScrollPane(this.fFailureList, 22, 32);
/*  93 */     Icon errorIcon = TestRunner.getIconResource(getClass(), "icons/error.gif");
/*  94 */     pane.addTab("Failures", errorIcon, scrollPane, "The list of failed tests");
/*     */   }
/*     */   
/*     */   public void revealFailure(Test failure) {
/*  98 */     this.fFailureList.setSelectedIndex(0);
/*     */   }
/*     */   
/*     */ 
/*     */   public void aboutToStart(Test suite, TestResult result) {}
/*     */   
/*     */   public void runFinished(Test suite, TestResult result) {}
/*     */   
/*     */   protected void testSelected()
/*     */   {
/* 108 */     this.fRunContext.handleTestSelected(getSelectedTest());
/*     */   }
/*     */ }


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp2\Exp2.zip!\Exp2\lib\junit.jar!\junit\swingui\FailureRunView.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */