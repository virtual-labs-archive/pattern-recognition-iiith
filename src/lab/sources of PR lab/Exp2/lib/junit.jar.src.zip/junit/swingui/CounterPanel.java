/*     */ package junit.swingui;
/*     */ 
/*     */ import java.awt.Insets;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.text.JTextComponent;
/*     */ 
/*     */ public class CounterPanel extends javax.swing.JPanel
/*     */ {
/*     */   private JTextField fNumberOfErrors;
/*     */   private JTextField fNumberOfFailures;
/*     */   private JTextField fNumberOfRuns;
/*  14 */   private javax.swing.Icon fFailureIcon = TestRunner.getIconResource(getClass(), "icons/failure.gif");
/*  15 */   private javax.swing.Icon fErrorIcon = TestRunner.getIconResource(getClass(), "icons/error.gif");
/*     */   private int fTotal;
/*     */   
/*     */   public CounterPanel()
/*     */   {
/*  20 */     super(new java.awt.GridBagLayout());
/*  21 */     this.fNumberOfErrors = createOutputField(5);
/*  22 */     this.fNumberOfFailures = createOutputField(5);
/*  23 */     this.fNumberOfRuns = createOutputField(9);
/*     */     
/*  25 */     addToGrid(new JLabel("Runs:", 0), 
/*  26 */       0, 0, 1, 1, 0.0D, 0.0D, 
/*  27 */       10, 0, 
/*  28 */       new Insets(0, 0, 0, 0));
/*  29 */     addToGrid(this.fNumberOfRuns, 
/*  30 */       1, 0, 1, 1, 0.33D, 0.0D, 
/*  31 */       10, 2, 
/*  32 */       new Insets(0, 8, 0, 0));
/*     */     
/*  34 */     addToGrid(new JLabel("Errors:", this.fErrorIcon, 2), 
/*  35 */       2, 0, 1, 1, 0.0D, 0.0D, 
/*  36 */       10, 0, 
/*  37 */       new Insets(0, 8, 0, 0));
/*  38 */     addToGrid(this.fNumberOfErrors, 
/*  39 */       3, 0, 1, 1, 0.33D, 0.0D, 
/*  40 */       10, 2, 
/*  41 */       new Insets(0, 8, 0, 0));
/*     */     
/*  43 */     addToGrid(new JLabel("Failures:", this.fFailureIcon, 2), 
/*  44 */       4, 0, 1, 1, 0.0D, 0.0D, 
/*  45 */       10, 0, 
/*  46 */       new Insets(0, 8, 0, 0));
/*  47 */     addToGrid(this.fNumberOfFailures, 
/*  48 */       5, 0, 1, 1, 0.33D, 0.0D, 
/*  49 */       10, 2, 
/*  50 */       new Insets(0, 8, 0, 0));
/*     */   }
/*     */   
/*     */   private JTextField createOutputField(int width) {
/*  54 */     JTextField field = new JTextField("0", width);
/*     */     
/*  56 */     field.setMinimumSize(field.getPreferredSize());
/*  57 */     field.setMaximumSize(field.getPreferredSize());
/*  58 */     field.setHorizontalAlignment(2);
/*  59 */     field.setFont(StatusLine.BOLD_FONT);
/*  60 */     field.setEditable(false);
/*  61 */     field.setBorder(javax.swing.BorderFactory.createEmptyBorder());
/*  62 */     return field;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addToGrid(java.awt.Component comp, int gridx, int gridy, int gridwidth, int gridheight, double weightx, double weighty, int anchor, int fill, Insets insets)
/*     */   {
/*  71 */     java.awt.GridBagConstraints constraints = new java.awt.GridBagConstraints();
/*  72 */     constraints.gridx = gridx;
/*  73 */     constraints.gridy = gridy;
/*  74 */     constraints.gridwidth = gridwidth;
/*  75 */     constraints.gridheight = gridheight;
/*  76 */     constraints.weightx = weightx;
/*  77 */     constraints.weighty = weighty;
/*  78 */     constraints.anchor = anchor;
/*  79 */     constraints.fill = fill;
/*  80 */     constraints.insets = insets;
/*  81 */     add(comp, constraints);
/*     */   }
/*     */   
/*     */   public void reset() {
/*  85 */     setLabelValue(this.fNumberOfErrors, 0);
/*  86 */     setLabelValue(this.fNumberOfFailures, 0);
/*  87 */     setLabelValue(this.fNumberOfRuns, 0);
/*  88 */     this.fTotal = 0;
/*     */   }
/*     */   
/*     */   public void setTotal(int value) {
/*  92 */     this.fTotal = value;
/*     */   }
/*     */   
/*     */   public void setRunValue(int value) {
/*  96 */     this.fNumberOfRuns.setText(Integer.toString(value) + "/" + this.fTotal);
/*     */   }
/*     */   
/*     */   public void setErrorValue(int value) {
/* 100 */     setLabelValue(this.fNumberOfErrors, value);
/*     */   }
/*     */   
/*     */   public void setFailureValue(int value) {
/* 104 */     setLabelValue(this.fNumberOfFailures, value);
/*     */   }
/*     */   
/*     */   private void setLabelValue(JTextField label, int value) {
/* 108 */     label.setText(Integer.toString(value));
/*     */   }
/*     */ }


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp2\Exp2.zip!\Exp2\lib\junit.jar!\junit\swingui\CounterPanel.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */