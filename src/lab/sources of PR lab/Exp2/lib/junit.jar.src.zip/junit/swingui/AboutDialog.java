/*    */ package junit.swingui;
/*    */ 
/*    */ import java.awt.Container;
/*    */ import java.awt.Dialog;
/*    */ import java.awt.Font;
/*    */ import java.awt.GridBagConstraints;
/*    */ import javax.swing.JDialog;
/*    */ import javax.swing.JLabel;
/*    */ 
/*    */ class AboutDialog extends JDialog
/*    */ {
/*    */   public AboutDialog(javax.swing.JFrame parent)
/*    */   {
/* 14 */     super(parent, true);
/*    */     
/* 16 */     setResizable(false);
/* 17 */     getContentPane().setLayout(new java.awt.GridBagLayout());
/* 18 */     setSize(330, 138);
/* 19 */     setTitle("About");
/*    */     try
/*    */     {
/* 22 */       setLocationRelativeTo(parent);
/*    */     } catch (NoSuchMethodError e) {
/* 24 */       TestSelector.centerWindow(this);
/*    */     }
/*    */     
/* 27 */     javax.swing.JButton close = new javax.swing.JButton("Close");
/* 28 */     close.addActionListener(
/* 29 */       new java.awt.event.ActionListener() {
/*    */         public void actionPerformed(java.awt.event.ActionEvent e) {
/* 31 */           AboutDialog.this.dispose();
/*    */         }
/*    */         
/* 34 */       });
/* 35 */     getRootPane().setDefaultButton(close);
/* 36 */     JLabel label1 = new JLabel("JUnit");
/* 37 */     label1.setFont(new Font("dialog", 0, 36));
/*    */     
/* 39 */     JLabel label2 = new JLabel("JUnit " + junit.runner.Version.id() + " by Kent Beck and Erich Gamma");
/* 40 */     label2.setFont(new Font("dialog", 0, 14));
/*    */     
/* 42 */     JLabel logo = createLogo();
/*    */     
/* 44 */     GridBagConstraints constraintsLabel1 = new GridBagConstraints();
/* 45 */     constraintsLabel1.gridx = 3;constraintsLabel1.gridy = 0;
/* 46 */     constraintsLabel1.gridwidth = 1;constraintsLabel1.gridheight = 1;
/* 47 */     constraintsLabel1.anchor = 10;
/* 48 */     getContentPane().add(label1, constraintsLabel1);
/*    */     
/* 50 */     GridBagConstraints constraintsLabel2 = new GridBagConstraints();
/* 51 */     constraintsLabel2.gridx = 2;constraintsLabel2.gridy = 1;
/* 52 */     constraintsLabel2.gridwidth = 2;constraintsLabel2.gridheight = 1;
/* 53 */     constraintsLabel2.anchor = 10;
/* 54 */     getContentPane().add(label2, constraintsLabel2);
/*    */     
/* 56 */     GridBagConstraints constraintsButton1 = new GridBagConstraints();
/* 57 */     constraintsButton1.gridx = 2;constraintsButton1.gridy = 2;
/* 58 */     constraintsButton1.gridwidth = 2;constraintsButton1.gridheight = 1;
/* 59 */     constraintsButton1.anchor = 10;
/* 60 */     constraintsButton1.insets = new java.awt.Insets(8, 0, 8, 0);
/* 61 */     getContentPane().add(close, constraintsButton1);
/*    */     
/* 63 */     GridBagConstraints constraintsLogo1 = new GridBagConstraints();
/* 64 */     constraintsLogo1.gridx = 2;constraintsLogo1.gridy = 0;
/* 65 */     constraintsLogo1.gridwidth = 1;constraintsLogo1.gridheight = 1;
/* 66 */     constraintsLogo1.anchor = 10;
/* 67 */     getContentPane().add(logo, constraintsLogo1);
/*    */     
/* 69 */     addWindowListener(
/* 70 */       new java.awt.event.WindowAdapter() {
/*    */         public void windowClosing(java.awt.event.WindowEvent e) {
/* 72 */           AboutDialog.this.dispose();
/*    */         }
/*    */       });
/*    */   }
/*    */   
/*    */   protected JLabel createLogo() {
/* 78 */     javax.swing.Icon icon = TestRunner.getIconResource(junit.runner.BaseTestRunner.class, "logo.gif");
/* 79 */     return new JLabel(icon);
/*    */   }
/*    */ }


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp2\Exp2.zip!\Exp2\lib\junit.jar!\junit\swingui\AboutDialog.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */