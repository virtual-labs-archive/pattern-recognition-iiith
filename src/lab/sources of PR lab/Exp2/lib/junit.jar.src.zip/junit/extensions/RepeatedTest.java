/*    */ package junit.extensions;
/*    */ 
/*    */ import junit.framework.Test;
/*    */ import junit.framework.TestResult;
/*    */ 
/*    */ public class RepeatedTest
/*    */   extends TestDecorator
/*    */ {
/*    */   private int fTimesRepeat;
/*    */   
/*    */   public RepeatedTest(Test test, int repeat)
/*    */   {
/* 13 */     super(test);
/* 14 */     if (repeat < 0)
/* 15 */       throw new IllegalArgumentException("Repetition count must be > 0");
/* 16 */     this.fTimesRepeat = repeat;
/*    */   }
/*    */   
/* 19 */   public int countTestCases() { return super.countTestCases() * this.fTimesRepeat; }
/*    */   
/*    */   public void run(TestResult result) {
/* 22 */     for (int i = 0; i < this.fTimesRepeat; i++) {
/* 23 */       if (result.shouldStop())
/*    */         break;
/* 25 */       super.run(result);
/*    */     }
/*    */   }
/*    */   
/* 29 */   public String toString() { return super.toString() + "(repeated)"; }
/*    */ }


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp2\Exp2.zip!\Exp2\lib\junit.jar!\junit\extensions\RepeatedTest.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */