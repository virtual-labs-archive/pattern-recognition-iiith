/*    */ package junit.framework;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ComparisonFailure
/*    */   extends AssertionFailedError
/*    */ {
/*    */   private String fExpected;
/*    */   
/*    */ 
/*    */ 
/*    */   private String fActual;
/*    */   
/*    */ 
/*    */ 
/*    */   public ComparisonFailure(String message, String expected, String actual)
/*    */   {
/* 19 */     super(message);
/* 20 */     this.fExpected = expected;
/* 21 */     this.fActual = actual;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getMessage()
/*    */   {
/* 31 */     if ((this.fExpected == null) || (this.fActual == null)) {
/* 32 */       return Assert.format(super.getMessage(), this.fExpected, this.fActual);
/*    */     }
/* 34 */     int end = Math.min(this.fExpected.length(), this.fActual.length());
/*    */     
/* 36 */     for (int i = 0; 
/* 37 */         i < end; i++) {
/* 38 */       if (this.fExpected.charAt(i) != this.fActual.charAt(i))
/*    */         break;
/*    */     }
/* 41 */     int j = this.fExpected.length() - 1;
/* 42 */     int k = this.fActual.length() - 1;
/* 43 */     for (; (k >= i) && (j >= i); j--) {
/* 44 */       if (this.fExpected.charAt(j) != this.fActual.charAt(k)) {
/*    */         break;
/*    */       }
/* 43 */       k--;
/*    */     }
/*    */     
/*    */     String actual;
/*    */     
/*    */     String expected;
/*    */     String actual;
/* 50 */     if ((j < i) && (k < i)) {
/* 51 */       String expected = this.fExpected;
/* 52 */       actual = this.fActual;
/*    */     } else {
/* 54 */       expected = this.fExpected.substring(i, j + 1);
/* 55 */       actual = this.fActual.substring(i, k + 1);
/* 56 */       if ((i <= end) && (i > 0)) {
/* 57 */         expected = "..." + expected;
/* 58 */         actual = "..." + actual;
/*    */       }
/*    */       
/* 61 */       if (j < this.fExpected.length() - 1)
/* 62 */         expected = expected + "...";
/* 63 */       if (k < this.fActual.length() - 1)
/* 64 */         actual = actual + "...";
/*    */     }
/* 66 */     return Assert.format(super.getMessage(), expected, actual);
/*    */   }
/*    */ }


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp2\Exp2.zip!\Exp2\lib\junit.jar!\junit\framework\ComparisonFailure.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */