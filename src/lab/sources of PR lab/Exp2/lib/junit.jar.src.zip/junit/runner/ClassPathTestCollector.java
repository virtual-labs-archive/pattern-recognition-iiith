/*    */ package junit.runner;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.util.Enumeration;
/*    */ import java.util.Hashtable;
/*    */ import java.util.StringTokenizer;
/*    */ import java.util.Vector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ClassPathTestCollector
/*    */   implements TestCollector
/*    */ {
/* 16 */   static final int SUFFIX_LENGTH = ".class".length();
/*    */   
/*    */ 
/*    */ 
/*    */   public Enumeration collectTests()
/*    */   {
/* 22 */     String classPath = System.getProperty("java.class.path");
/* 23 */     Hashtable result = collectFilesInPath(classPath);
/* 24 */     return result.elements();
/*    */   }
/*    */   
/*    */   public Hashtable collectFilesInPath(String classPath) {
/* 28 */     Hashtable result = collectFilesInRoots(splitClassPath(classPath));
/* 29 */     return result;
/*    */   }
/*    */   
/*    */   Hashtable collectFilesInRoots(Vector roots) {
/* 33 */     Hashtable result = new Hashtable(100);
/* 34 */     Enumeration e = roots.elements();
/* 35 */     while (e.hasMoreElements())
/* 36 */       gatherFiles(new File((String)e.nextElement()), "", result);
/* 37 */     return result;
/*    */   }
/*    */   
/*    */   void gatherFiles(File classRoot, String classFileName, Hashtable result) {
/* 41 */     File thisRoot = new File(classRoot, classFileName);
/* 42 */     if (thisRoot.isFile()) {
/* 43 */       if (isTestClass(classFileName)) {
/* 44 */         String className = classNameFromFile(classFileName);
/* 45 */         result.put(className, className);
/*    */       }
/* 47 */       return;
/*    */     }
/* 49 */     String[] contents = thisRoot.list();
/* 50 */     if (contents != null) {
/* 51 */       for (int i = 0; i < contents.length; i++)
/* 52 */         gatherFiles(classRoot, classFileName + File.separatorChar + contents[i], result);
/*    */     }
/*    */   }
/*    */   
/*    */   Vector splitClassPath(String classPath) {
/* 57 */     Vector result = new Vector();
/* 58 */     String separator = System.getProperty("path.separator");
/* 59 */     StringTokenizer tokenizer = new StringTokenizer(classPath, separator);
/* 60 */     while (tokenizer.hasMoreTokens())
/* 61 */       result.addElement(tokenizer.nextToken());
/* 62 */     return result;
/*    */   }
/*    */   
/*    */   protected boolean isTestClass(String classFileName)
/*    */   {
/* 67 */     return (classFileName.endsWith(".class")) && 
/* 68 */       (classFileName.indexOf('$') < 0) && 
/* 69 */       (classFileName.indexOf("Test") > 0);
/*    */   }
/*    */   
/*    */   protected String classNameFromFile(String classFileName)
/*    */   {
/* 74 */     String s = classFileName.substring(0, classFileName.length() - SUFFIX_LENGTH);
/* 75 */     String s2 = s.replace(File.separatorChar, '.');
/* 76 */     if (s2.startsWith("."))
/* 77 */       return s2.substring(1);
/* 78 */     return s2;
/*    */   }
/*    */ }


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp2\Exp2.zip!\Exp2\lib\junit.jar!\junit\runner\ClassPathTestCollector.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */