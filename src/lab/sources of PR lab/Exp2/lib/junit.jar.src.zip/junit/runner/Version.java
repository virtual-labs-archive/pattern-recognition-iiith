/*    */ package junit.runner;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Version
/*    */ {
/*    */   public static String id()
/*    */   {
/* 12 */     return "3.8.1";
/*    */   }
/*    */ }


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp2\Exp2.zip!\Exp2\lib\junit.jar!\junit\runner\Version.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */