package junit.runner;

import java.util.Enumeration;

public abstract interface TestCollector
{
  public abstract Enumeration collectTests();
}


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp2\Exp2.zip!\Exp2\lib\junit.jar!\junit\runner\TestCollector.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */