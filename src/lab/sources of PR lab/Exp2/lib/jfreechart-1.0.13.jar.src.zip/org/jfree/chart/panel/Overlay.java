package org.jfree.chart.panel;

import java.awt.Graphics2D;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.event.OverlayChangeListener;

public abstract interface Overlay
{
  public abstract void paintOverlay(Graphics2D paramGraphics2D, ChartPanel paramChartPanel);
  
  public abstract void addChangeListener(OverlayChangeListener paramOverlayChangeListener);
  
  public abstract void removeChangeListener(OverlayChangeListener paramOverlayChangeListener);
}


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp2\Exp2.zip!\Exp2\lib\jfreechart-1.0.13.jar!\org\jfree\chart\panel\Overlay.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       0.7.1
 */