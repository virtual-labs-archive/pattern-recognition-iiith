package org.jfree.chart.plot;

import org.jfree.chart.axis.ValueAxis;
import org.jfree.data.Range;

public abstract interface ValueAxisPlot
{
  public abstract Range getDataRange(ValueAxis paramValueAxis);
}


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp2\Exp2.zip!\Exp2\lib\jfreechart-1.0.13.jar!\org\jfree\chart\plot\ValueAxisPlot.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       0.7.1
 */