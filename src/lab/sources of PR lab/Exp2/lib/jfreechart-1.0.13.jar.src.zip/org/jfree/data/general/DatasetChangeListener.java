package org.jfree.data.general;

import java.util.EventListener;

public abstract interface DatasetChangeListener
  extends EventListener
{
  public abstract void datasetChanged(DatasetChangeEvent paramDatasetChangeEvent);
}


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp2\Exp2.zip!\Exp2\lib\jfreechart-1.0.13.jar!\org\jfree\data\general\DatasetChangeListener.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       0.7.1
 */