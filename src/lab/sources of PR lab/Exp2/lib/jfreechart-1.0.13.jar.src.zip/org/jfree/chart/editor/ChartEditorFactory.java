package org.jfree.chart.editor;

import org.jfree.chart.JFreeChart;

public abstract interface ChartEditorFactory
{
  public abstract ChartEditor createEditor(JFreeChart paramJFreeChart);
}


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp2\Exp2.zip!\Exp2\lib\jfreechart-1.0.13.jar!\org\jfree\chart\editor\ChartEditorFactory.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       0.7.1
 */