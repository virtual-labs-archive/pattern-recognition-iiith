package org.jfree.data.general;

public abstract interface KeyedValuesDataset
  extends PieDataset
{}


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp2\Exp2.zip!\Exp2\lib\jfreechart-1.0.13.jar!\org\jfree\data\general\KeyedValuesDataset.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       0.7.1
 */