package org.jfree.data.general;

public class DefaultKeyedValuesDataset
  extends DefaultPieDataset
  implements KeyedValuesDataset
{
  private static final long serialVersionUID = 306264413152815781L;
}


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp2\Exp2.zip!\Exp2\lib\jfreechart-1.0.13.jar!\org\jfree\data\general\DefaultKeyedValuesDataset.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       0.7.1
 */