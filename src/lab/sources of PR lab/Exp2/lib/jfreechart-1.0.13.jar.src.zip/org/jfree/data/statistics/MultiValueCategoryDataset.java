package org.jfree.data.statistics;

import java.util.List;
import org.jfree.data.category.CategoryDataset;

public abstract interface MultiValueCategoryDataset
  extends CategoryDataset
{
  public abstract List getValues(int paramInt1, int paramInt2);
  
  public abstract List getValues(Comparable paramComparable1, Comparable paramComparable2);
}


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp2\Exp2.zip!\Exp2\lib\jfreechart-1.0.13.jar!\org\jfree\data\statistics\MultiValueCategoryDataset.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       0.7.1
 */