/*    */ package org.jfree.data.general;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SeriesException
/*    */   extends RuntimeException
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = -3667048387550852940L;
/*    */   
/*    */   public SeriesException(String message)
/*    */   {
/* 61 */     super(message);
/*    */   }
/*    */ }


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp2\Exp2.zip!\Exp2\lib\jfreechart-1.0.13.jar!\org\jfree\data\general\SeriesException.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       0.7.1
 */