/*     */ package libsvm;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Solver
/*     */ {
/*     */   int active_size;
/*     */   byte[] y;
/*     */   double[] G;
/*     */   static final byte LOWER_BOUND = 0;
/*     */   static final byte UPPER_BOUND = 1;
/*     */   static final byte FREE = 2;
/*     */   byte[] alpha_status;
/*     */   double[] alpha;
/*     */   QMatrix Q;
/*     */   double[] QD;
/*     */   double eps;
/*     */   double Cp;
/*     */   double Cn;
/*     */   double[] p;
/*     */   int[] active_set;
/*     */   double[] G_bar;
/*     */   int l;
/*     */   boolean unshrink;
/*     */   static final double INF = Double.POSITIVE_INFINITY;
/*     */   
/*     */   double get_C(int paramInt)
/*     */   {
/* 326 */     return this.y[paramInt] > 0 ? this.Cp : this.Cn;
/*     */   }
/*     */   
/*     */   void update_alpha_status(int paramInt) {
/* 330 */     if (this.alpha[paramInt] >= get_C(paramInt)) {
/* 331 */       this.alpha_status[paramInt] = 1;
/* 332 */     } else if (this.alpha[paramInt] <= 0.0D)
/* 333 */       this.alpha_status[paramInt] = 0; else
/* 334 */       this.alpha_status[paramInt] = 2; }
/*     */   
/* 336 */   boolean is_upper_bound(int paramInt) { return this.alpha_status[paramInt] == 1; }
/* 337 */   boolean is_lower_bound(int paramInt) { return this.alpha_status[paramInt] == 0; }
/* 338 */   boolean is_free(int paramInt) { return this.alpha_status[paramInt] == 2; }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void swap_index(int paramInt1, int paramInt2)
/*     */   {
/* 352 */     this.Q.swap_index(paramInt1, paramInt2);
/* 353 */     int i = this.y[paramInt1];this.y[paramInt1] = this.y[paramInt2];this.y[paramInt2] = i;
/* 354 */     double d1 = this.G[paramInt1];this.G[paramInt1] = this.G[paramInt2];this.G[paramInt2] = d1;
/* 355 */     int j = this.alpha_status[paramInt1];this.alpha_status[paramInt1] = this.alpha_status[paramInt2];this.alpha_status[paramInt2] = j;
/* 356 */     double d2 = this.alpha[paramInt1];this.alpha[paramInt1] = this.alpha[paramInt2];this.alpha[paramInt2] = d2;
/* 357 */     d2 = this.p[paramInt1];this.p[paramInt1] = this.p[paramInt2];this.p[paramInt2] = d2;
/* 358 */     int k = this.active_set[paramInt1];this.active_set[paramInt1] = this.active_set[paramInt2];this.active_set[paramInt2] = k;
/* 359 */     double d3 = this.G_bar[paramInt1];this.G_bar[paramInt1] = this.G_bar[paramInt2];this.G_bar[paramInt2] = d3;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   void reconstruct_gradient()
/*     */   {
/* 366 */     if (this.active_size == this.l) { return;
/*     */     }
/*     */     
/* 369 */     int k = 0;
/*     */     
/* 371 */     for (int j = this.active_size; j < this.l; j++) {
/* 372 */       this.G[j] = (this.G_bar[j] + this.p[j]);
/*     */     }
/* 374 */     for (j = 0; j < this.active_size; j++) {
/* 375 */       if (is_free(j))
/* 376 */         k++;
/*     */     }
/* 378 */     if (2 * k < this.active_size)
/* 379 */       svm.info("\nWARNING: using -h 0 may be faster\n");
/*     */     float[] arrayOfFloat;
/* 381 */     if (k * this.l > 2 * this.active_size * (this.l - this.active_size))
/*     */     {
/* 383 */       for (i = this.active_size; i < this.l; i++)
/*     */       {
/* 385 */         arrayOfFloat = this.Q.get_Q(i, this.active_size);
/* 386 */         for (j = 0; j < this.active_size; j++) {
/* 387 */           if (is_free(j)) {
/* 388 */             this.G[i] += this.alpha[j] * arrayOfFloat[j];
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 393 */     for (int i = 0; i < this.active_size; i++) {
/* 394 */       if (is_free(i))
/*     */       {
/* 396 */         arrayOfFloat = this.Q.get_Q(i, this.l);
/* 397 */         double d = this.alpha[i];
/* 398 */         for (j = this.active_size; j < this.l; j++) {
/* 399 */           this.G[j] += d * arrayOfFloat[j];
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   void Solve(int paramInt1, QMatrix paramQMatrix, double[] paramArrayOfDouble1, byte[] paramArrayOfByte, double[] paramArrayOfDouble2, double paramDouble1, double paramDouble2, double paramDouble3, SolutionInfo paramSolutionInfo, int paramInt2)
/*     */   {
/* 407 */     this.l = paramInt1;
/* 408 */     this.Q = paramQMatrix;
/* 409 */     this.QD = paramQMatrix.get_QD();
/* 410 */     this.p = ((double[])paramArrayOfDouble1.clone());
/* 411 */     this.y = ((byte[])paramArrayOfByte.clone());
/* 412 */     this.alpha = ((double[])paramArrayOfDouble2.clone());
/* 413 */     this.Cp = paramDouble1;
/* 414 */     this.Cn = paramDouble2;
/* 415 */     this.eps = paramDouble3;
/* 416 */     this.unshrink = false;
/*     */     
/*     */ 
/*     */ 
/* 420 */     this.alpha_status = new byte[paramInt1];
/* 421 */     for (int i = 0; i < paramInt1; i++) {
/* 422 */       update_alpha_status(i);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 427 */     this.active_set = new int[paramInt1];
/* 428 */     for (i = 0; i < paramInt1; i++)
/* 429 */       this.active_set[i] = i;
/* 430 */     this.active_size = paramInt1;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 435 */     this.G = new double[paramInt1];
/* 436 */     this.G_bar = new double[paramInt1];
/*     */     
/* 438 */     for (i = 0; i < paramInt1; i++)
/*     */     {
/* 440 */       this.G[i] = this.p[i];
/* 441 */       this.G_bar[i] = 0.0D; }
/*     */     int m;
/* 443 */     for (i = 0; i < paramInt1; i++) {
/* 444 */       if (!is_lower_bound(i))
/*     */       {
/* 446 */         float[] arrayOfFloat1 = paramQMatrix.get_Q(i, paramInt1);
/* 447 */         double d1 = this.alpha[i];
/*     */         
/* 449 */         for (m = 0; m < paramInt1; m++)
/* 450 */           this.G[m] += d1 * arrayOfFloat1[m];
/* 451 */         if (is_upper_bound(i)) {
/* 452 */           for (m = 0; m < paramInt1; m++) {
/* 453 */             this.G_bar[m] += get_C(i) * arrayOfFloat1[m];
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 459 */     i = 0;
/* 460 */     int j = Math.max(10000000, paramInt1 > 21474836 ? Integer.MAX_VALUE : 100 * paramInt1);
/* 461 */     int k = Math.min(paramInt1, 1000) + 1;
/* 462 */     int[] arrayOfInt = new int[2];
/*     */     
/* 464 */     while (i < j)
/*     */     {
/*     */ 
/*     */ 
/* 468 */       k--; if (k == 0)
/*     */       {
/* 470 */         k = Math.min(paramInt1, 1000);
/* 471 */         if (paramInt2 != 0) do_shrinking();
/* 472 */         svm.info(".");
/*     */       }
/*     */       
/* 475 */       if (select_working_set(arrayOfInt) != 0)
/*     */       {
/*     */ 
/* 478 */         reconstruct_gradient();
/*     */         
/* 480 */         this.active_size = paramInt1;
/* 481 */         svm.info("*");
/* 482 */         if (select_working_set(arrayOfInt) != 0) {
/*     */           break;
/*     */         }
/* 485 */         k = 1;
/*     */       }
/*     */       
/* 488 */       m = arrayOfInt[0];
/* 489 */       int i1 = arrayOfInt[1];
/*     */       
/* 491 */       i++;
/*     */       
/*     */ 
/*     */ 
/* 495 */       float[] arrayOfFloat2 = paramQMatrix.get_Q(m, this.active_size);
/* 496 */       float[] arrayOfFloat3 = paramQMatrix.get_Q(i1, this.active_size);
/*     */       
/* 498 */       double d3 = get_C(m);
/* 499 */       double d4 = get_C(i1);
/*     */       
/* 501 */       double d5 = this.alpha[m];
/* 502 */       double d6 = this.alpha[i1];
/*     */       double d9;
/* 504 */       if (this.y[m] != this.y[i1])
/*     */       {
/* 506 */         d7 = this.QD[m] + this.QD[i1] + 2.0F * arrayOfFloat2[i1];
/* 507 */         if (d7 <= 0.0D)
/* 508 */           d7 = 1.0E-12D;
/* 509 */         d8 = (-this.G[m] - this.G[i1]) / d7;
/* 510 */         d9 = this.alpha[m] - this.alpha[i1];
/* 511 */         this.alpha[m] += d8;
/* 512 */         this.alpha[i1] += d8;
/*     */         
/* 514 */         if (d9 > 0.0D)
/*     */         {
/* 516 */           if (this.alpha[i1] < 0.0D)
/*     */           {
/* 518 */             this.alpha[i1] = 0.0D;
/* 519 */             this.alpha[m] = d9;
/*     */           }
/*     */           
/*     */ 
/*     */         }
/* 524 */         else if (this.alpha[m] < 0.0D)
/*     */         {
/* 526 */           this.alpha[m] = 0.0D;
/* 527 */           this.alpha[i1] = (-d9);
/*     */         }
/*     */         
/* 530 */         if (d9 > d3 - d4)
/*     */         {
/* 532 */           if (this.alpha[m] > d3)
/*     */           {
/* 534 */             this.alpha[m] = d3;
/* 535 */             this.alpha[i1] = (d3 - d9);
/*     */           }
/*     */           
/*     */ 
/*     */         }
/* 540 */         else if (this.alpha[i1] > d4)
/*     */         {
/* 542 */           this.alpha[i1] = d4;
/* 543 */           this.alpha[m] = (d4 + d9);
/*     */         }
/*     */         
/*     */       }
/*     */       else
/*     */       {
/* 549 */         d7 = this.QD[m] + this.QD[i1] - 2.0F * arrayOfFloat2[i1];
/* 550 */         if (d7 <= 0.0D)
/* 551 */           d7 = 1.0E-12D;
/* 552 */         d8 = (this.G[m] - this.G[i1]) / d7;
/* 553 */         d9 = this.alpha[m] + this.alpha[i1];
/* 554 */         this.alpha[m] -= d8;
/* 555 */         this.alpha[i1] += d8;
/*     */         
/* 557 */         if (d9 > d3)
/*     */         {
/* 559 */           if (this.alpha[m] > d3)
/*     */           {
/* 561 */             this.alpha[m] = d3;
/* 562 */             this.alpha[i1] = (d9 - d3);
/*     */           }
/*     */           
/*     */ 
/*     */         }
/* 567 */         else if (this.alpha[i1] < 0.0D)
/*     */         {
/* 569 */           this.alpha[i1] = 0.0D;
/* 570 */           this.alpha[m] = d9;
/*     */         }
/*     */         
/* 573 */         if (d9 > d4)
/*     */         {
/* 575 */           if (this.alpha[i1] > d4)
/*     */           {
/* 577 */             this.alpha[i1] = d4;
/* 578 */             this.alpha[m] = (d9 - d4);
/*     */           }
/*     */           
/*     */ 
/*     */         }
/* 583 */         else if (this.alpha[m] < 0.0D)
/*     */         {
/* 585 */           this.alpha[m] = 0.0D;
/* 586 */           this.alpha[i1] = d9;
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 593 */       double d7 = this.alpha[m] - d5;
/* 594 */       double d8 = this.alpha[i1] - d6;
/*     */       
/* 596 */       for (int i3 = 0; i3 < this.active_size; i3++)
/*     */       {
/* 598 */         this.G[i3] += arrayOfFloat2[i3] * d7 + arrayOfFloat3[i3] * d8;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 604 */       boolean bool1 = is_upper_bound(m);
/* 605 */       boolean bool2 = is_upper_bound(i1);
/* 606 */       update_alpha_status(m);
/* 607 */       update_alpha_status(i1);
/*     */       int i4;
/* 609 */       if (bool1 != is_upper_bound(m))
/*     */       {
/* 611 */         arrayOfFloat2 = paramQMatrix.get_Q(m, paramInt1);
/* 612 */         if (bool1) {
/* 613 */           for (i4 = 0; i4 < paramInt1; i4++)
/* 614 */             this.G_bar[i4] -= d3 * arrayOfFloat2[i4];
/*     */         }
/* 616 */         for (i4 = 0; i4 < paramInt1; i4++) {
/* 617 */           this.G_bar[i4] += d3 * arrayOfFloat2[i4];
/*     */         }
/*     */       }
/* 620 */       if (bool2 != is_upper_bound(i1))
/*     */       {
/* 622 */         arrayOfFloat3 = paramQMatrix.get_Q(i1, paramInt1);
/* 623 */         if (bool2) {
/* 624 */           for (i4 = 0; i4 < paramInt1; i4++)
/* 625 */             this.G_bar[i4] -= d4 * arrayOfFloat3[i4];
/*     */         }
/* 627 */         for (i4 = 0; i4 < paramInt1; i4++) {
/* 628 */           this.G_bar[i4] += d4 * arrayOfFloat3[i4];
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 634 */     if (i >= j)
/*     */     {
/* 636 */       if (this.active_size < paramInt1)
/*     */       {
/*     */ 
/* 639 */         reconstruct_gradient();
/* 640 */         this.active_size = paramInt1;
/* 641 */         svm.info("*");
/*     */       }
/* 643 */       System.err.print("\nWARNING: reaching max number of iterations\n");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 648 */     paramSolutionInfo.rho = calculate_rho();
/*     */     
/*     */ 
/*     */ 
/* 652 */     double d2 = 0.0D;
/*     */     
/* 654 */     for (int i2 = 0; i2 < paramInt1; i2++) {
/* 655 */       d2 += this.alpha[i2] * (this.G[i2] + this.p[i2]);
/*     */     }
/* 657 */     paramSolutionInfo.obj = (d2 / 2.0D);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 662 */     for (int n = 0; n < paramInt1; n++) {
/* 663 */       paramArrayOfDouble2[this.active_set[n]] = this.alpha[n];
/*     */     }
/*     */     
/* 666 */     paramSolutionInfo.upper_bound_p = paramDouble1;
/* 667 */     paramSolutionInfo.upper_bound_n = paramDouble2;
/*     */     
/* 669 */     svm.info("\noptimization finished, #iter = " + i + "\n");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int select_working_set(int[] paramArrayOfInt)
/*     */   {
/* 681 */     double d1 = Double.NEGATIVE_INFINITY;
/* 682 */     double d2 = Double.NEGATIVE_INFINITY;
/* 683 */     int i = -1;
/* 684 */     int j = -1;
/* 685 */     double d3 = Double.POSITIVE_INFINITY;
/*     */     
/* 687 */     for (int k = 0; k < this.active_size; k++) {
/* 688 */       if (this.y[k] == 1)
/*     */       {
/* 690 */         if ((!is_upper_bound(k)) && 
/* 691 */           (-this.G[k] >= d1))
/*     */         {
/* 693 */           d1 = -this.G[k];
/* 694 */           i = k;
/*     */         }
/*     */         
/*     */ 
/*     */       }
/* 699 */       else if ((!is_lower_bound(k)) && 
/* 700 */         (this.G[k] >= d1))
/*     */       {
/* 702 */         d1 = this.G[k];
/* 703 */         i = k;
/*     */       }
/*     */     }
/*     */     
/* 707 */     k = i;
/* 708 */     float[] arrayOfFloat = null;
/* 709 */     if (k != -1) {
/* 710 */       arrayOfFloat = this.Q.get_Q(k, this.active_size);
/*     */     }
/* 712 */     for (int m = 0; m < this.active_size; m++) { double d4;
/*     */       double d6;
/* 714 */       double d5; if (this.y[m] == 1)
/*     */       {
/* 716 */         if (!is_lower_bound(m))
/*     */         {
/* 718 */           d4 = d1 + this.G[m];
/* 719 */           if (this.G[m] >= d2)
/* 720 */             d2 = this.G[m];
/* 721 */           if (d4 > 0.0D)
/*     */           {
/*     */ 
/* 724 */             d6 = this.QD[k] + this.QD[m] - 2.0D * this.y[k] * arrayOfFloat[m];
/* 725 */             if (d6 > 0.0D) {
/* 726 */               d5 = -(d4 * d4) / d6;
/*     */             } else {
/* 728 */               d5 = -(d4 * d4) / 1.0E-12D;
/*     */             }
/* 730 */             if (d5 <= d3)
/*     */             {
/* 732 */               j = m;
/* 733 */               d3 = d5;
/*     */             }
/*     */             
/*     */           }
/*     */           
/*     */         }
/*     */       }
/* 740 */       else if (!is_upper_bound(m))
/*     */       {
/* 742 */         d4 = d1 - this.G[m];
/* 743 */         if (-this.G[m] >= d2)
/* 744 */           d2 = -this.G[m];
/* 745 */         if (d4 > 0.0D)
/*     */         {
/*     */ 
/* 748 */           d6 = this.QD[k] + this.QD[m] + 2.0D * this.y[k] * arrayOfFloat[m];
/* 749 */           if (d6 > 0.0D) {
/* 750 */             d5 = -(d4 * d4) / d6;
/*     */           } else {
/* 752 */             d5 = -(d4 * d4) / 1.0E-12D;
/*     */           }
/* 754 */           if (d5 <= d3)
/*     */           {
/* 756 */             j = m;
/* 757 */             d3 = d5;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 764 */     if (d1 + d2 < this.eps) {
/* 765 */       return 1;
/*     */     }
/* 767 */     paramArrayOfInt[0] = i;
/* 768 */     paramArrayOfInt[1] = j;
/* 769 */     return 0;
/*     */   }
/*     */   
/*     */   private boolean be_shrunk(int paramInt, double paramDouble1, double paramDouble2)
/*     */   {
/* 774 */     if (is_upper_bound(paramInt))
/*     */     {
/* 776 */       if (this.y[paramInt] == 1) {
/* 777 */         return -this.G[paramInt] > paramDouble1;
/*     */       }
/* 779 */       return -this.G[paramInt] > paramDouble2;
/*     */     }
/* 781 */     if (is_lower_bound(paramInt))
/*     */     {
/* 783 */       if (this.y[paramInt] == 1) {
/* 784 */         return this.G[paramInt] > paramDouble2;
/*     */       }
/* 786 */       return this.G[paramInt] > paramDouble1;
/*     */     }
/*     */     
/* 789 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   void do_shrinking()
/*     */   {
/* 795 */     double d1 = Double.NEGATIVE_INFINITY;
/* 796 */     double d2 = Double.NEGATIVE_INFINITY;
/*     */     
/*     */ 
/* 799 */     for (int i = 0; i < this.active_size; i++)
/*     */     {
/* 801 */       if (this.y[i] == 1)
/*     */       {
/* 803 */         if (!is_upper_bound(i))
/*     */         {
/* 805 */           if (-this.G[i] >= d1)
/* 806 */             d1 = -this.G[i];
/*     */         }
/* 808 */         if (!is_lower_bound(i))
/*     */         {
/* 810 */           if (this.G[i] >= d2) {
/* 811 */             d2 = this.G[i];
/*     */           }
/*     */         }
/*     */       }
/*     */       else {
/* 816 */         if (!is_upper_bound(i))
/*     */         {
/* 818 */           if (-this.G[i] >= d2)
/* 819 */             d2 = -this.G[i];
/*     */         }
/* 821 */         if (!is_lower_bound(i))
/*     */         {
/* 823 */           if (this.G[i] >= d1) {
/* 824 */             d1 = this.G[i];
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 829 */     if ((!this.unshrink) && (d1 + d2 <= this.eps * 10.0D))
/*     */     {
/* 831 */       this.unshrink = true;
/* 832 */       reconstruct_gradient();
/* 833 */       this.active_size = this.l;
/*     */     }
/*     */     
/* 836 */     for (i = 0; i < this.active_size; i++) {
/* 837 */       if (be_shrunk(i, d1, d2))
/*     */       {
/* 839 */         this.active_size -= 1;
/* 840 */         while (this.active_size > i)
/*     */         {
/* 842 */           if (!be_shrunk(this.active_size, d1, d2))
/*     */           {
/* 844 */             swap_index(i, this.active_size);
/* 845 */             break;
/*     */           }
/* 847 */           this.active_size -= 1;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   double calculate_rho()
/*     */   {
/* 855 */     int i = 0;
/* 856 */     double d2 = Double.POSITIVE_INFINITY;double d3 = Double.NEGATIVE_INFINITY;double d4 = 0.0D;
/* 857 */     for (int j = 0; j < this.active_size; j++)
/*     */     {
/* 859 */       double d5 = this.y[j] * this.G[j];
/*     */       
/* 861 */       if (is_lower_bound(j))
/*     */       {
/* 863 */         if (this.y[j] > 0) {
/* 864 */           d2 = Math.min(d2, d5);
/*     */         } else {
/* 866 */           d3 = Math.max(d3, d5);
/*     */         }
/* 868 */       } else if (is_upper_bound(j))
/*     */       {
/* 870 */         if (this.y[j] < 0) {
/* 871 */           d2 = Math.min(d2, d5);
/*     */         } else {
/* 873 */           d3 = Math.max(d3, d5);
/*     */         }
/*     */       }
/*     */       else {
/* 877 */         i++;
/* 878 */         d4 += d5;
/*     */       }
/*     */     }
/*     */     double d1;
/* 882 */     if (i > 0) {
/* 883 */       d1 = d4 / i;
/*     */     } else {
/* 885 */       d1 = (d2 + d3) / 2.0D;
/*     */     }
/* 887 */     return d1;
/*     */   }
/*     */   
/*     */   static class SolutionInfo
/*     */   {
/*     */     double obj;
/*     */     double rho;
/*     */     double upper_bound_p;
/*     */     double upper_bound_n;
/*     */     double r;
/*     */   }
/*     */ }


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp3\Exp3.zip!\Exp3\lib\libsvm.jar!\libsvm\Solver.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */