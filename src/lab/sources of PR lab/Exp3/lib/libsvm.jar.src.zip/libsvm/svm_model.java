package libsvm;

import java.io.Serializable;

public class svm_model
  implements Serializable
{
  public svm_parameter param;
  public int nr_class;
  public int l;
  public svm_node[][] SV;
  public double[][] sv_coef;
  public double[] rho;
  public double[] probA;
  public double[] probB;
  public int[] sv_indices;
  public int[] label;
  public int[] nSV;
}


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp3\Exp3.zip!\Exp3\lib\libsvm.jar!\libsvm\svm_model.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */