package libsvm;

public abstract interface svm_print_interface
{
  public abstract void print(String paramString);
}


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp3\Exp3.zip!\Exp3\lib\libsvm.jar!\libsvm\svm_print_interface.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */