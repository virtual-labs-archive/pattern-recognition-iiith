package libsvm;

import java.io.Serializable;

public class svm_problem
  implements Serializable
{
  public int l;
  public double[] y;
  public svm_node[][] x;
}


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp3\Exp3.zip!\Exp3\lib\libsvm.jar!\libsvm\svm_problem.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */