/*     */ import java.io.BufferedReader;
/*     */ import java.io.PrintStream;
/*     */ import java.util.Formatter;
/*     */ import java.util.StringTokenizer;
/*     */ 
/*     */ class svm_scale
/*     */ {
/*   8 */   private String line = null;
/*   9 */   private double lower = -1.0D;
/*  10 */   private double upper = 1.0D;
/*     */   private double y_lower;
/*     */   private double y_upper;
/*  13 */   private boolean y_scaling = false;
/*     */   private double[] feature_max;
/*     */   private double[] feature_min;
/*  16 */   private double y_max = -1.7976931348623157E308D;
/*  17 */   private double y_min = Double.MAX_VALUE;
/*     */   private int max_index;
/*  19 */   private long num_nonzeros = 0L;
/*  20 */   private long new_num_nonzeros = 0L;
/*     */   
/*     */   private static void exit_with_help()
/*     */   {
/*  24 */     System.out.print("Usage: svm-scale [options] data_filename\noptions:\n-l lower : x scaling lower limit (default -1)\n-u upper : x scaling upper limit (default +1)\n-y y_lower y_upper : y scaling limits (default: no y scaling)\n-s save_filename : save scaling parameters to save_filename\n-r restore_filename : restore scaling parameters from restore_filename\n");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  33 */     System.exit(1);
/*     */   }
/*     */   
/*     */   private BufferedReader rewind(BufferedReader paramBufferedReader, String paramString) throws java.io.IOException
/*     */   {
/*  38 */     paramBufferedReader.close();
/*  39 */     return new BufferedReader(new java.io.FileReader(paramString));
/*     */   }
/*     */   
/*     */   private void output_target(double paramDouble)
/*     */   {
/*  44 */     if (this.y_scaling)
/*     */     {
/*  46 */       if (paramDouble == this.y_min) {
/*  47 */         paramDouble = this.y_lower;
/*  48 */       } else if (paramDouble == this.y_max) {
/*  49 */         paramDouble = this.y_upper;
/*     */       } else {
/*  51 */         paramDouble = this.y_lower + (this.y_upper - this.y_lower) * (paramDouble - this.y_min) / (this.y_max - this.y_min);
/*     */       }
/*     */     }
/*     */     
/*  55 */     System.out.print(paramDouble + " ");
/*     */   }
/*     */   
/*     */ 
/*     */   private void output(int paramInt, double paramDouble)
/*     */   {
/*  61 */     if (this.feature_max[paramInt] == this.feature_min[paramInt]) {
/*  62 */       return;
/*     */     }
/*  64 */     if (paramDouble == this.feature_min[paramInt]) {
/*  65 */       paramDouble = this.lower;
/*  66 */     } else if (paramDouble == this.feature_max[paramInt]) {
/*  67 */       paramDouble = this.upper;
/*     */     } else {
/*  69 */       paramDouble = this.lower + (this.upper - this.lower) * (paramDouble - this.feature_min[paramInt]) / (this.feature_max[paramInt] - this.feature_min[paramInt]);
/*     */     }
/*     */     
/*     */ 
/*  73 */     if (paramDouble != 0.0D)
/*     */     {
/*  75 */       System.out.print(paramInt + ":" + paramDouble + " ");
/*  76 */       this.new_num_nonzeros += 1L;
/*     */     }
/*     */   }
/*     */   
/*     */   private String readline(BufferedReader paramBufferedReader) throws java.io.IOException
/*     */   {
/*  82 */     this.line = paramBufferedReader.readLine();
/*  83 */     return this.line;
/*     */   }
/*     */   
/*     */   private void run(String[] paramArrayOfString)
/*     */     throws java.io.IOException
/*     */   {
/*  89 */     BufferedReader localBufferedReader1 = null;BufferedReader localBufferedReader2 = null;
/*  90 */     String str1 = null;
/*  91 */     String str2 = null;
/*  92 */     String str3 = null;
/*     */     
/*     */ 
/*  95 */     for (int i = 0; i < paramArrayOfString.length; i++)
/*     */     {
/*  97 */       if (paramArrayOfString[i].charAt(0) != '-') break;
/*  98 */       i++;
/*  99 */       switch (paramArrayOfString[(i - 1)].charAt(1)) {
/*     */       case 'l': 
/* 101 */         this.lower = Double.parseDouble(paramArrayOfString[i]); break;
/* 102 */       case 'u':  this.upper = Double.parseDouble(paramArrayOfString[i]); break;
/*     */       case 'y': 
/* 104 */         this.y_lower = Double.parseDouble(paramArrayOfString[i]);
/* 105 */         i++;
/* 106 */         this.y_upper = Double.parseDouble(paramArrayOfString[i]);
/* 107 */         this.y_scaling = true;
/* 108 */         break;
/* 109 */       case 's':  str1 = paramArrayOfString[i]; break;
/* 110 */       case 'r':  str2 = paramArrayOfString[i]; break;
/*     */       case 'm': case 'n': case 'o': case 'p': case 'q': case 't': case 'v': case 'w': case 'x': default: 
/* 112 */         System.err.println("unknown option");
/* 113 */         exit_with_help();
/*     */       }
/*     */       
/*     */     }
/* 117 */     if ((this.upper <= this.lower) || ((this.y_scaling) && (this.y_upper <= this.y_lower)))
/*     */     {
/* 119 */       System.err.println("inconsistent lower/upper specification");
/* 120 */       System.exit(1);
/*     */     }
/* 122 */     if ((str2 != null) && (str1 != null))
/*     */     {
/* 124 */       System.err.println("cannot use -r and -s simultaneously");
/* 125 */       System.exit(1);
/*     */     }
/*     */     
/* 128 */     if (paramArrayOfString.length != i + 1) {
/* 129 */       exit_with_help();
/*     */     }
/* 131 */     str3 = paramArrayOfString[i];
/*     */     try {
/* 133 */       localBufferedReader1 = new BufferedReader(new java.io.FileReader(str3));
/*     */     } catch (Exception localException1) {
/* 135 */       System.err.println("can't open file " + str3);
/* 136 */       System.exit(1);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 141 */     this.max_index = 0;
/*     */     
/* 143 */     if (str2 != null)
/*     */     {
/*     */ 
/*     */       try
/*     */       {
/* 148 */         localBufferedReader2 = new BufferedReader(new java.io.FileReader(str2));
/*     */       }
/*     */       catch (Exception localException2) {
/* 151 */         System.err.println("can't open file " + str2);
/* 152 */         System.exit(1); }
/*     */       int i1;
/* 154 */       if ((i1 = localBufferedReader2.read()) == 121)
/*     */       {
/* 156 */         localBufferedReader2.readLine();
/* 157 */         localBufferedReader2.readLine();
/* 158 */         localBufferedReader2.readLine();
/*     */       }
/* 160 */       localBufferedReader2.readLine();
/* 161 */       localBufferedReader2.readLine();
/*     */       
/* 163 */       String str4 = null;
/* 164 */       while ((str4 = localBufferedReader2.readLine()) != null)
/*     */       {
/* 166 */         StringTokenizer localStringTokenizer2 = new StringTokenizer(str4);
/* 167 */         int k = Integer.parseInt(localStringTokenizer2.nextToken());
/* 168 */         this.max_index = Math.max(this.max_index, k);
/*     */       }
/* 170 */       localBufferedReader2 = rewind(localBufferedReader2, str2);
/*     */     }
/*     */     int j;
/* 173 */     while (readline(localBufferedReader1) != null)
/*     */     {
/* 175 */       StringTokenizer localStringTokenizer1 = new StringTokenizer(this.line, " \t\n\r\f:");
/* 176 */       localStringTokenizer1.nextToken();
/* 177 */       while (localStringTokenizer1.hasMoreTokens())
/*     */       {
/* 179 */         j = Integer.parseInt(localStringTokenizer1.nextToken());
/* 180 */         this.max_index = Math.max(this.max_index, j);
/* 181 */         localStringTokenizer1.nextToken();
/* 182 */         this.num_nonzeros += 1L;
/*     */       }
/*     */     }
/*     */     try
/*     */     {
/* 187 */       this.feature_max = new double[this.max_index + 1];
/* 188 */       this.feature_min = new double[this.max_index + 1];
/*     */     } catch (OutOfMemoryError localOutOfMemoryError) {
/* 190 */       System.err.println("can't allocate enough memory");
/* 191 */       System.exit(1);
/*     */     }
/*     */     
/* 194 */     for (i = 0; i <= this.max_index; i++)
/*     */     {
/* 196 */       this.feature_max[i] = -1.7976931348623157E308D;
/* 197 */       this.feature_min[i] = Double.MAX_VALUE;
/*     */     }
/*     */     
/* 200 */     localBufferedReader1 = rewind(localBufferedReader1, str3);
/*     */     int m;
/*     */     StringTokenizer localStringTokenizer3;
/* 203 */     double d4; while (readline(localBufferedReader1) != null)
/*     */     {
/* 205 */       m = 1;
/*     */       
/*     */ 
/*     */ 
/* 209 */       localStringTokenizer3 = new StringTokenizer(this.line, " \t\n\r\f:");
/* 210 */       double d1 = Double.parseDouble(localStringTokenizer3.nextToken());
/* 211 */       this.y_max = Math.max(this.y_max, d1);
/* 212 */       this.y_min = Math.min(this.y_min, d1);
/*     */       
/* 214 */       while (localStringTokenizer3.hasMoreTokens())
/*     */       {
/* 216 */         j = Integer.parseInt(localStringTokenizer3.nextToken());
/* 217 */         d4 = Double.parseDouble(localStringTokenizer3.nextToken());
/*     */         
/* 219 */         for (i = m; i < j; i++)
/*     */         {
/* 221 */           this.feature_max[i] = Math.max(this.feature_max[i], 0.0D);
/* 222 */           this.feature_min[i] = Math.min(this.feature_min[i], 0.0D);
/*     */         }
/*     */         
/* 225 */         this.feature_max[j] = Math.max(this.feature_max[j], d4);
/* 226 */         this.feature_min[j] = Math.min(this.feature_min[j], d4);
/* 227 */         m = j + 1;
/*     */       }
/*     */       
/* 230 */       for (i = m; i <= this.max_index; i++)
/*     */       {
/* 232 */         this.feature_max[i] = Math.max(this.feature_max[i], 0.0D);
/* 233 */         this.feature_min[i] = Math.min(this.feature_min[i], 0.0D);
/*     */       }
/*     */     }
/*     */     
/* 237 */     localBufferedReader1 = rewind(localBufferedReader1, str3);
/*     */     
/*     */ 
/* 240 */     if (str2 != null)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 246 */       localBufferedReader2.mark(2);
/* 247 */       int i2; StringTokenizer localStringTokenizer4; if ((i2 = localBufferedReader2.read()) == 121)
/*     */       {
/* 249 */         localBufferedReader2.readLine();
/* 250 */         localStringTokenizer4 = new StringTokenizer(localBufferedReader2.readLine());
/* 251 */         this.y_lower = Double.parseDouble(localStringTokenizer4.nextToken());
/* 252 */         this.y_upper = Double.parseDouble(localStringTokenizer4.nextToken());
/* 253 */         localStringTokenizer4 = new StringTokenizer(localBufferedReader2.readLine());
/* 254 */         this.y_min = Double.parseDouble(localStringTokenizer4.nextToken());
/* 255 */         this.y_max = Double.parseDouble(localStringTokenizer4.nextToken());
/* 256 */         this.y_scaling = true;
/*     */       }
/*     */       else {
/* 259 */         localBufferedReader2.reset();
/*     */       }
/* 261 */       if (localBufferedReader2.read() == 120) {
/* 262 */         localBufferedReader2.readLine();
/* 263 */         localStringTokenizer4 = new StringTokenizer(localBufferedReader2.readLine());
/* 264 */         this.lower = Double.parseDouble(localStringTokenizer4.nextToken());
/* 265 */         this.upper = Double.parseDouble(localStringTokenizer4.nextToken());
/* 266 */         String str5 = null;
/* 267 */         while ((str5 = localBufferedReader2.readLine()) != null)
/*     */         {
/* 269 */           StringTokenizer localStringTokenizer5 = new StringTokenizer(str5);
/* 270 */           m = Integer.parseInt(localStringTokenizer5.nextToken());
/* 271 */           double d3 = Double.parseDouble(localStringTokenizer5.nextToken());
/* 272 */           double d5 = Double.parseDouble(localStringTokenizer5.nextToken());
/* 273 */           if (m <= this.max_index)
/*     */           {
/* 275 */             this.feature_min[m] = d3;
/* 276 */             this.feature_max[m] = d5;
/*     */           }
/*     */         }
/*     */       }
/* 280 */       localBufferedReader2.close();
/*     */     }
/*     */     
/* 283 */     if (str1 != null)
/*     */     {
/* 285 */       Formatter localFormatter = new Formatter(new StringBuilder());
/* 286 */       java.io.BufferedWriter localBufferedWriter = null;
/*     */       try
/*     */       {
/* 289 */         localBufferedWriter = new java.io.BufferedWriter(new java.io.FileWriter(str1));
/*     */       } catch (java.io.IOException localIOException) {
/* 291 */         System.err.println("can't open file " + str1);
/* 292 */         System.exit(1);
/*     */       }
/*     */       
/* 295 */       if (this.y_scaling)
/*     */       {
/* 297 */         localFormatter.format("y\n", new Object[0]);
/* 298 */         localFormatter.format("%.16g %.16g\n", new Object[] { Double.valueOf(this.y_lower), Double.valueOf(this.y_upper) });
/* 299 */         localFormatter.format("%.16g %.16g\n", new Object[] { Double.valueOf(this.y_min), Double.valueOf(this.y_max) });
/*     */       }
/* 301 */       localFormatter.format("x\n", new Object[0]);
/* 302 */       localFormatter.format("%.16g %.16g\n", new Object[] { Double.valueOf(this.lower), Double.valueOf(this.upper) });
/* 303 */       for (i = 1; i <= this.max_index; i++)
/*     */       {
/* 305 */         if (this.feature_min[i] != this.feature_max[i])
/* 306 */           localFormatter.format("%d %.16g %.16g\n", new Object[] { Integer.valueOf(i), Double.valueOf(this.feature_min[i]), Double.valueOf(this.feature_max[i]) });
/*     */       }
/* 308 */       localBufferedWriter.write(localFormatter.toString());
/* 309 */       localBufferedWriter.close();
/*     */     }
/*     */     
/*     */ 
/* 313 */     while (readline(localBufferedReader1) != null)
/*     */     {
/* 315 */       int n = 1;
/*     */       
/*     */ 
/*     */ 
/* 319 */       localStringTokenizer3 = new StringTokenizer(this.line, " \t\n\r\f:");
/* 320 */       double d2 = Double.parseDouble(localStringTokenizer3.nextToken());
/* 321 */       output_target(d2);
/* 322 */       while (localStringTokenizer3.hasMoreElements())
/*     */       {
/* 324 */         j = Integer.parseInt(localStringTokenizer3.nextToken());
/* 325 */         d4 = Double.parseDouble(localStringTokenizer3.nextToken());
/* 326 */         for (i = n; i < j; i++)
/* 327 */           output(i, 0.0D);
/* 328 */         output(j, d4);
/* 329 */         n = j + 1;
/*     */       }
/*     */       
/* 332 */       for (i = n; i <= this.max_index; i++)
/* 333 */         output(i, 0.0D);
/* 334 */       System.out.print("\n");
/*     */     }
/* 336 */     if (this.new_num_nonzeros > this.num_nonzeros) {
/* 337 */       System.err.print("WARNING: original #nonzeros " + this.num_nonzeros + "\n" + "         new      #nonzeros " + this.new_num_nonzeros + "\n" + "Use -l 0 if many original feature values are zeros\n");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 342 */     localBufferedReader1.close();
/*     */   }
/*     */   
/*     */   public static void main(String[] paramArrayOfString) throws java.io.IOException
/*     */   {
/* 347 */     svm_scale localsvm_scale = new svm_scale();
/* 348 */     localsvm_scale.run(paramArrayOfString);
/*     */   }
/*     */ }


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp3\Exp3.zip!\Exp3\lib\libsvm.jar!\svm_scale.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */