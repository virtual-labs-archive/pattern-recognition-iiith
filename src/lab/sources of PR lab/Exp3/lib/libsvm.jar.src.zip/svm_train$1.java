import libsvm.svm_print_interface;

final class svm_train$1
  implements svm_print_interface
{
  public void print(String paramString) {}
}


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp3\Exp3.zip!\Exp3\lib\libsvm.jar!\svm_train$1.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */