package org.jfree.util;

public abstract interface PublicCloneable
  extends Cloneable
{
  public abstract Object clone()
    throws CloneNotSupportedException;
}


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp3\Exp3.zip!\Exp3\lib\jcommon-1.0.16.jar!\org\jfree\util\PublicCloneable.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */