/*    */ package org.jfree.ui.about.resources;
/*    */ 
/*    */ import java.util.ListResourceBundle;
/*    */ import javax.swing.KeyStroke;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AboutResources_de
/*    */   extends ListResourceBundle
/*    */ {
/*    */   public Object[][] getContents()
/*    */   {
/* 69 */     return CONTENTS;
/*    */   }
/*    */   
/*    */ 
/* 73 */   private static final Object[][] CONTENTS = { { "about-frame.tab.about", "Über" }, { "about-frame.tab.system", "System" }, { "about-frame.tab.contributors", "Entwickler" }, { "about-frame.tab.licence", "Lizenz" }, { "about-frame.tab.libraries", "Bibliotheken" }, { "contributors-table.column.name", "Name:" }, { "contributors-table.column.contact", "Kontakt:" }, { "libraries-table.column.name", "Name:" }, { "libraries-table.column.version", "Version:" }, { "libraries-table.column.licence", "Lizenz:" }, { "libraries-table.column.info", "Zus. Information:" }, { "system-frame.title", "Systemeigenschaften" }, { "system-frame.button.close", "Schließen" }, { "system-frame.button.close.mnemonic", new Character('C') }, { "system-frame.menu.file", "Datei" }, { "system-frame.menu.file.mnemonic", new Character('D') }, { "system-frame.menu.file.close", "Beenden" }, { "system-frame.menu.file.close.mnemonic", new Character('B') }, { "system-frame.menu.edit", "Bearbeiten" }, { "system-frame.menu.edit.mnemonic", new Character('B') }, { "system-frame.menu.edit.copy", "Kopieren" }, { "system-frame.menu.edit.copy.mnemonic", new Character('K') }, { "system-properties-table.column.name", "Eigenschaft:" }, { "system-properties-table.column.value", "Wert:" }, { "system-properties-panel.popup-menu.copy", "Kopieren" }, { "system-properties-panel.popup-menu.copy.accelerator", KeyStroke.getKeyStroke(67, 2) } };
/*    */ }


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp3\Exp3.zip!\Exp3\lib\jcommon-1.0.16.jar!\org\jfree\ui\about\resources\AboutResources_de.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */