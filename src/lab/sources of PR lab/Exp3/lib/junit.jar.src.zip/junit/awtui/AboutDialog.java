/*    */ package junit.awtui;
/*    */ 
/*    */ import java.awt.Dialog;
/*    */ import java.awt.GridBagConstraints;
/*    */ 
/*    */ class AboutDialog extends Dialog
/*    */ {
/*    */   public AboutDialog(java.awt.Frame parent)
/*    */   {
/* 10 */     super(parent);
/*    */     
/* 12 */     setResizable(false);
/* 13 */     setLayout(new java.awt.GridBagLayout());
/* 14 */     setSize(330, 138);
/* 15 */     setTitle("About");
/*    */     
/* 17 */     java.awt.Button button = new java.awt.Button("Close");
/* 18 */     button.addActionListener(
/* 19 */       new java.awt.event.ActionListener() {
/*    */         public void actionPerformed(java.awt.event.ActionEvent e) {
/* 21 */           AboutDialog.this.dispose();
/*    */         }
/*    */         
/*    */ 
/* 25 */       });
/* 26 */     java.awt.Label label1 = new java.awt.Label("JUnit");
/* 27 */     label1.setFont(new java.awt.Font("dialog", 0, 36));
/*    */     
/* 29 */     java.awt.Label label2 = new java.awt.Label("JUnit " + junit.runner.Version.id() + " by Kent Beck and Erich Gamma");
/* 30 */     label2.setFont(new java.awt.Font("dialog", 0, 14));
/*    */     
/* 32 */     Logo logo = new Logo();
/*    */     
/* 34 */     GridBagConstraints constraintsLabel1 = new GridBagConstraints();
/* 35 */     constraintsLabel1.gridx = 3;constraintsLabel1.gridy = 0;
/* 36 */     constraintsLabel1.gridwidth = 1;constraintsLabel1.gridheight = 1;
/* 37 */     constraintsLabel1.anchor = 10;
/* 38 */     add(label1, constraintsLabel1);
/*    */     
/* 40 */     GridBagConstraints constraintsLabel2 = new GridBagConstraints();
/* 41 */     constraintsLabel2.gridx = 2;constraintsLabel2.gridy = 1;
/* 42 */     constraintsLabel2.gridwidth = 2;constraintsLabel2.gridheight = 1;
/* 43 */     constraintsLabel2.anchor = 10;
/* 44 */     add(label2, constraintsLabel2);
/*    */     
/* 46 */     GridBagConstraints constraintsButton1 = new GridBagConstraints();
/* 47 */     constraintsButton1.gridx = 2;constraintsButton1.gridy = 2;
/* 48 */     constraintsButton1.gridwidth = 2;constraintsButton1.gridheight = 1;
/* 49 */     constraintsButton1.anchor = 10;
/* 50 */     constraintsButton1.insets = new java.awt.Insets(8, 0, 8, 0);
/* 51 */     add(button, constraintsButton1);
/*    */     
/* 53 */     GridBagConstraints constraintsLogo1 = new GridBagConstraints();
/* 54 */     constraintsLogo1.gridx = 2;constraintsLogo1.gridy = 0;
/* 55 */     constraintsLogo1.gridwidth = 1;constraintsLogo1.gridheight = 1;
/* 56 */     constraintsLogo1.anchor = 10;
/* 57 */     add(logo, constraintsLogo1);
/*    */     
/* 59 */     addWindowListener(
/* 60 */       new java.awt.event.WindowAdapter() {
/*    */         public void windowClosing(java.awt.event.WindowEvent e) {
/* 62 */           AboutDialog.this.dispose();
/*    */         }
/*    */       });
/*    */   }
/*    */ }


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp3\Exp3.zip!\Exp3\lib\junit.jar!\junit\awtui\AboutDialog.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */