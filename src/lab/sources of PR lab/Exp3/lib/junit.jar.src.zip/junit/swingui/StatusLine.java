/*    */ package junit.swingui;
/*    */ 
/*    */ import java.awt.Color;
/*    */ import java.awt.Font;
/*    */ import javax.swing.BorderFactory;
/*    */ import javax.swing.JComponent;
/*    */ import javax.swing.JTextField;
/*    */ import javax.swing.text.JTextComponent;
/*    */ 
/*    */ public class StatusLine extends JTextField
/*    */ {
/* 12 */   public static final Font PLAIN_FONT = new Font("dialog", 0, 12);
/* 13 */   public static final Font BOLD_FONT = new Font("dialog", 1, 12);
/*    */   
/*    */   public StatusLine(int preferredWidth)
/*    */   {
/* 17 */     setFont(BOLD_FONT);
/* 18 */     setEditable(false);
/* 19 */     setBorder(BorderFactory.createBevelBorder(1));
/* 20 */     java.awt.Dimension d = getPreferredSize();
/* 21 */     d.width = preferredWidth;
/* 22 */     setPreferredSize(d);
/*    */   }
/*    */   
/*    */   public void showInfo(String message) {
/* 26 */     setFont(PLAIN_FONT);
/* 27 */     setForeground(Color.black);
/* 28 */     setText(message);
/*    */   }
/*    */   
/*    */   public void showError(String status) {
/* 32 */     setFont(BOLD_FONT);
/* 33 */     setForeground(Color.red);
/* 34 */     setText(status);
/* 35 */     setToolTipText(status);
/*    */   }
/*    */   
/*    */   public void clear() {
/* 39 */     setText("");
/* 40 */     setToolTipText(null);
/*    */   }
/*    */ }


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp3\Exp3.zip!\Exp3\lib\junit.jar!\junit\swingui\StatusLine.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */