/*     */ package junit.swingui;
/*     */ 
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Vector;
/*     */ import javax.swing.event.TreeModelListener;
/*     */ import javax.swing.tree.TreePath;
/*     */ import junit.extensions.TestDecorator;
/*     */ import junit.framework.Test;
/*     */ import junit.framework.TestSuite;
/*     */ 
/*     */ class TestTreeModel implements javax.swing.tree.TreeModel
/*     */ {
/*     */   private Test fRoot;
/*  15 */   private Vector fModelListeners = new Vector();
/*  16 */   private Hashtable fFailures = new Hashtable();
/*  17 */   private Hashtable fErrors = new Hashtable();
/*  18 */   private Hashtable fRunTests = new Hashtable();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public TestTreeModel(Test root)
/*     */   {
/*  25 */     this.fRoot = root;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void addTreeModelListener(TreeModelListener l)
/*     */   {
/*  32 */     if (!this.fModelListeners.contains(l)) {
/*  33 */       this.fModelListeners.addElement(l);
/*     */     }
/*     */   }
/*     */   
/*     */   public void removeTreeModelListener(TreeModelListener l)
/*     */   {
/*  39 */     this.fModelListeners.removeElement(l);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int findTest(Test target, Test node, Vector path)
/*     */   {
/*  46 */     if (target.equals(node)) {
/*  47 */       return 0;
/*     */     }
/*  49 */     TestSuite suite = isTestSuite(node);
/*  50 */     for (int i = 0; i < getChildCount(node); i++) {
/*  51 */       Test t = suite.testAt(i);
/*  52 */       int index = findTest(target, t, path);
/*  53 */       if (index >= 0) {
/*  54 */         path.insertElementAt(node, 0);
/*  55 */         if (path.size() == 1)
/*  56 */           return i;
/*  57 */         return index;
/*     */       }
/*     */     }
/*  60 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */   public void fireNodeChanged(TreePath path, int index)
/*     */   {
/*  66 */     int[] indices = { index };
/*  67 */     Object[] changedChildren = { getChild(path.getLastPathComponent(), index) };
/*  68 */     javax.swing.event.TreeModelEvent event = new javax.swing.event.TreeModelEvent(this, path, indices, changedChildren);
/*     */     
/*  70 */     Enumeration e = this.fModelListeners.elements();
/*  71 */     while (e.hasMoreElements()) {
/*  72 */       TreeModelListener l = (TreeModelListener)e.nextElement();
/*  73 */       l.treeNodesChanged(event);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public Object getChild(Object parent, int index)
/*     */   {
/*  80 */     TestSuite suite = isTestSuite(parent);
/*  81 */     if (suite != null)
/*  82 */       return suite.testAt(index);
/*  83 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public int getChildCount(Object parent)
/*     */   {
/*  89 */     TestSuite suite = isTestSuite(parent);
/*  90 */     if (suite != null)
/*  91 */       return suite.testCount();
/*  92 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */   public int getIndexOfChild(Object parent, Object child)
/*     */   {
/*  98 */     TestSuite suite = isTestSuite(parent);
/*  99 */     if (suite != null) {
/* 100 */       int i = 0;
/* 101 */       for (Enumeration e = suite.tests(); e.hasMoreElements(); i++) {
/* 102 */         if (child.equals((Test)e.nextElement()))
/* 103 */           return i;
/*     */       }
/*     */     }
/* 106 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */   public Object getRoot()
/*     */   {
/* 112 */     return this.fRoot;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isLeaf(Object node)
/*     */   {
/* 118 */     return isTestSuite(node) == null;
/*     */   }
/*     */   
/*     */ 
/*     */   TestSuite isTestSuite(Object node)
/*     */   {
/* 124 */     if ((node instanceof TestSuite))
/* 125 */       return (TestSuite)node;
/* 126 */     if ((node instanceof TestDecorator)) {
/* 127 */       Test baseTest = ((TestDecorator)node).getTest();
/* 128 */       return isTestSuite(baseTest);
/*     */     }
/* 130 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void valueForPathChanged(TreePath path, Object newValue)
/*     */   {
/* 138 */     System.out.println("TreeModel.valueForPathChanged: not implemented");
/*     */   }
/*     */   
/*     */ 
/*     */   void addFailure(Test t)
/*     */   {
/* 144 */     this.fFailures.put(t, t);
/*     */   }
/*     */   
/*     */ 
/*     */   void addError(Test t)
/*     */   {
/* 150 */     this.fErrors.put(t, t);
/*     */   }
/*     */   
/*     */ 
/*     */   void addRunTest(Test t)
/*     */   {
/* 156 */     this.fRunTests.put(t, t);
/*     */   }
/*     */   
/*     */ 
/*     */   boolean wasRun(Test t)
/*     */   {
/* 162 */     return this.fRunTests.get(t) != null;
/*     */   }
/*     */   
/*     */ 
/*     */   boolean isError(Test t)
/*     */   {
/* 168 */     return (this.fErrors != null) && (this.fErrors.get(t) != null);
/*     */   }
/*     */   
/*     */ 
/*     */   boolean isFailure(Test t)
/*     */   {
/* 174 */     return (this.fFailures != null) && (this.fFailures.get(t) != null);
/*     */   }
/*     */   
/*     */ 
/*     */   void resetResults()
/*     */   {
/* 180 */     this.fFailures = new Hashtable();
/* 181 */     this.fRunTests = new Hashtable();
/* 182 */     this.fErrors = new Hashtable();
/*     */   }
/*     */ }


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp3\Exp3.zip!\Exp3\lib\junit.jar!\junit\swingui\TestTreeModel.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */