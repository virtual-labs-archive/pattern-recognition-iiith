/*    */ package junit.swingui;
/*    */ 
/*    */ import java.awt.Color;
/*    */ import javax.swing.JComponent;
/*    */ import javax.swing.JProgressBar;
/*    */ 
/*    */ 
/*    */ class ProgressBar
/*    */   extends JProgressBar
/*    */ {
/* 11 */   boolean fError = false;
/*    */   
/*    */   public ProgressBar()
/*    */   {
/* 15 */     setForeground(getStatusColor());
/*    */   }
/*    */   
/*    */   private Color getStatusColor() {
/* 19 */     if (this.fError)
/* 20 */       return Color.red;
/* 21 */     return Color.green;
/*    */   }
/*    */   
/*    */   public void reset() {
/* 25 */     this.fError = false;
/* 26 */     setForeground(getStatusColor());
/* 27 */     setValue(0);
/*    */   }
/*    */   
/*    */   public void start(int total) {
/* 31 */     setMaximum(total);
/* 32 */     reset();
/*    */   }
/*    */   
/*    */   public void step(int value, boolean successful) {
/* 36 */     setValue(value);
/* 37 */     if ((!this.fError) && (!successful)) {
/* 38 */       this.fError = true;
/* 39 */       setForeground(getStatusColor());
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp3\Exp3.zip!\Exp3\lib\junit.jar!\junit\swingui\ProgressBar.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */