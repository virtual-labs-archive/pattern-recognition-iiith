/*    */ package junit.swingui;
/*    */ 
/*    */ import java.util.Vector;
/*    */ import javax.swing.Icon;
/*    */ import javax.swing.JTabbedPane;
/*    */ import javax.swing.JTree;
/*    */ import javax.swing.event.TreeSelectionEvent;
/*    */ import javax.swing.event.TreeSelectionListener;
/*    */ import javax.swing.tree.TreePath;
/*    */ import junit.framework.Test;
/*    */ import junit.framework.TestResult;
/*    */ 
/*    */ public class TestHierarchyRunView implements TestRunView
/*    */ {
/*    */   TestSuitePanel fTreeBrowser;
/*    */   TestRunContext fTestContext;
/*    */   
/*    */   public TestHierarchyRunView(TestRunContext context)
/*    */   {
/* 20 */     this.fTestContext = context;
/* 21 */     this.fTreeBrowser = new TestSuitePanel();
/* 22 */     this.fTreeBrowser.getTree().addTreeSelectionListener(
/* 23 */       new TreeSelectionListener() {
/*    */         public void valueChanged(TreeSelectionEvent e) {
/* 25 */           TestHierarchyRunView.this.testSelected();
/*    */         }
/*    */       });
/*    */   }
/*    */   
/*    */   public void addTab(JTabbedPane pane)
/*    */   {
/* 32 */     Icon treeIcon = TestRunner.getIconResource(getClass(), "icons/hierarchy.gif");
/* 33 */     pane.addTab("Test Hierarchy", treeIcon, this.fTreeBrowser, "The test hierarchy");
/*    */   }
/*    */   
/*    */   public Test getSelectedTest() {
/* 37 */     return this.fTreeBrowser.getSelectedTest();
/*    */   }
/*    */   
/*    */   public void activate() {
/* 41 */     testSelected();
/*    */   }
/*    */   
/*    */   public void revealFailure(Test failure) {
/* 45 */     JTree tree = this.fTreeBrowser.getTree();
/* 46 */     TestTreeModel model = (TestTreeModel)tree.getModel();
/* 47 */     Vector vpath = new Vector();
/* 48 */     int index = model.findTest(failure, (Test)model.getRoot(), vpath);
/* 49 */     if (index >= 0) {
/* 50 */       Object[] path = new Object[vpath.size() + 1];
/* 51 */       vpath.copyInto(path);
/* 52 */       Object last = path[(vpath.size() - 1)];
/* 53 */       path[vpath.size()] = model.getChild(last, index);
/* 54 */       TreePath selectionPath = new TreePath(path);
/* 55 */       tree.setSelectionPath(selectionPath);
/* 56 */       tree.makeVisible(selectionPath);
/*    */     }
/*    */   }
/*    */   
/*    */   public void aboutToStart(Test suite, TestResult result) {
/* 61 */     this.fTreeBrowser.showTestTree(suite);
/* 62 */     result.addListener(this.fTreeBrowser);
/*    */   }
/*    */   
/*    */   public void runFinished(Test suite, TestResult result) {
/* 66 */     result.removeListener(this.fTreeBrowser);
/*    */   }
/*    */   
/*    */   protected void testSelected() {
/* 70 */     this.fTestContext.handleTestSelected(getSelectedTest());
/*    */   }
/*    */ }


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp3\Exp3.zip!\Exp3\lib\junit.jar!\junit\swingui\TestHierarchyRunView.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */