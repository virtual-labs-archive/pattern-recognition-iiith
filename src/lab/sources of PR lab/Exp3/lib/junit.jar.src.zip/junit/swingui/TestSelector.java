/*     */ package junit.swingui;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.Dialog;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Toolkit;
/*     */ import java.awt.Window;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.KeyAdapter;
/*     */ import java.awt.event.KeyEvent;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.WindowAdapter;
/*     */ import java.awt.event.WindowEvent;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Vector;
/*     */ import javax.swing.AbstractButton;
/*     */ import javax.swing.DefaultListCellRenderer;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JDialog;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JList;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.ListModel;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.event.ListSelectionEvent;
/*     */ import javax.swing.event.ListSelectionListener;
/*     */ import junit.runner.Sorter;
/*     */ import junit.runner.Sorter.Swapper;
/*     */ import junit.runner.TestCollector;
/*     */ 
/*     */ class TestSelector
/*     */   extends JDialog
/*     */ {
/*     */   private JButton fCancel;
/*     */   private JButton fOk;
/*     */   private JList fList;
/*     */   private JScrollPane fScrolledList;
/*     */   private JLabel fDescription;
/*     */   private String fSelectedItem;
/*     */   /* Error */
/*     */   public TestSelector(java.awt.Frame parent, TestCollector testCollector)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: aload_1
/*     */     //   2: iconst_1
/*     */     //   3: invokespecial 21	javax/swing/JDialog:<init>	(Ljava/awt/Frame;Z)V
/*     */     //   6: aload_0
/*     */     //   7: sipush 350
/*     */     //   10: sipush 300
/*     */     //   13: invokevirtual 27	java/awt/Component:setSize	(II)V
/*     */     //   16: aload_0
/*     */     //   17: iconst_0
/*     */     //   18: invokevirtual 33	java/awt/Dialog:setResizable	(Z)V
/*     */     //   21: aload_0
/*     */     //   22: aload_1
/*     */     //   23: invokevirtual 39	java/awt/Window:setLocationRelativeTo	(Ljava/awt/Component;)V
/*     */     //   26: goto +8 -> 34
/*     */     //   29: astore_3
/*     */     //   30: aload_0
/*     */     //   31: invokestatic 42	junit/swingui/TestSelector:centerWindow	(Ljava/awt/Component;)V
/*     */     //   34: aload_0
/*     */     //   35: ldc 44
/*     */     //   37: invokevirtual 48	java/awt/Dialog:setTitle	(Ljava/lang/String;)V
/*     */     //   40: aconst_null
/*     */     //   41: astore_3
/*     */     //   42: aload_1
/*     */     //   43: iconst_3
/*     */     //   44: invokestatic 54	java/awt/Cursor:getPredefinedCursor	(I)Ljava/awt/Cursor;
/*     */     //   47: invokevirtual 58	java/awt/Window:setCursor	(Ljava/awt/Cursor;)V
/*     */     //   50: aload_0
/*     */     //   51: aload_2
/*     */     //   52: invokespecial 62	junit/swingui/TestSelector:createTestList	(Ljunit/runner/TestCollector;)Ljava/util/Vector;
/*     */     //   55: astore_3
/*     */     //   56: goto +11 -> 67
/*     */     //   59: astore 5
/*     */     //   61: jsr +12 -> 73
/*     */     //   64: aload 5
/*     */     //   66: athrow
/*     */     //   67: jsr +6 -> 73
/*     */     //   70: goto +14 -> 84
/*     */     //   73: astore 4
/*     */     //   75: aload_1
/*     */     //   76: invokestatic 66	java/awt/Cursor:getDefaultCursor	()Ljava/awt/Cursor;
/*     */     //   79: invokevirtual 58	java/awt/Window:setCursor	(Ljava/awt/Cursor;)V
/*     */     //   82: ret 4
/*     */     //   84: aload_0
/*     */     //   85: new 68	javax/swing/JList
/*     */     //   88: dup
/*     */     //   89: aload_3
/*     */     //   90: invokespecial 71	javax/swing/JList:<init>	(Ljava/util/Vector;)V
/*     */     //   93: putfield 73	junit/swingui/TestSelector:fList	Ljavax/swing/JList;
/*     */     //   96: aload_0
/*     */     //   97: getfield 73	junit/swingui/TestSelector:fList	Ljavax/swing/JList;
/*     */     //   100: iconst_0
/*     */     //   101: invokevirtual 77	javax/swing/JList:setSelectionMode	(I)V
/*     */     //   104: aload_0
/*     */     //   105: getfield 73	junit/swingui/TestSelector:fList	Ljavax/swing/JList;
/*     */     //   108: new 79	junit/swingui/TestSelector$TestCellRenderer
/*     */     //   111: dup
/*     */     //   112: invokespecial 82	junit/swingui/TestSelector$TestCellRenderer:<init>	()V
/*     */     //   115: invokevirtual 86	javax/swing/JList:setCellRenderer	(Ljavax/swing/ListCellRenderer;)V
/*     */     //   118: aload_0
/*     */     //   119: new 88	javax/swing/JScrollPane
/*     */     //   122: dup
/*     */     //   123: aload_0
/*     */     //   124: getfield 73	junit/swingui/TestSelector:fList	Ljavax/swing/JList;
/*     */     //   127: invokespecial 90	javax/swing/JScrollPane:<init>	(Ljava/awt/Component;)V
/*     */     //   130: putfield 92	junit/swingui/TestSelector:fScrolledList	Ljavax/swing/JScrollPane;
/*     */     //   133: aload_0
/*     */     //   134: new 94	javax/swing/JButton
/*     */     //   137: dup
/*     */     //   138: ldc 96
/*     */     //   140: invokespecial 98	javax/swing/JButton:<init>	(Ljava/lang/String;)V
/*     */     //   143: putfield 100	junit/swingui/TestSelector:fCancel	Ljavax/swing/JButton;
/*     */     //   146: aload_0
/*     */     //   147: new 102	javax/swing/JLabel
/*     */     //   150: dup
/*     */     //   151: ldc 104
/*     */     //   153: invokespecial 105	javax/swing/JLabel:<init>	(Ljava/lang/String;)V
/*     */     //   156: putfield 107	junit/swingui/TestSelector:fDescription	Ljavax/swing/JLabel;
/*     */     //   159: aload_0
/*     */     //   160: new 94	javax/swing/JButton
/*     */     //   163: dup
/*     */     //   164: ldc 109
/*     */     //   166: invokespecial 98	javax/swing/JButton:<init>	(Ljava/lang/String;)V
/*     */     //   169: putfield 111	junit/swingui/TestSelector:fOk	Ljavax/swing/JButton;
/*     */     //   172: aload_0
/*     */     //   173: getfield 111	junit/swingui/TestSelector:fOk	Ljavax/swing/JButton;
/*     */     //   176: iconst_0
/*     */     //   177: invokevirtual 116	javax/swing/AbstractButton:setEnabled	(Z)V
/*     */     //   180: aload_0
/*     */     //   181: invokevirtual 120	javax/swing/JDialog:getRootPane	()Ljavax/swing/JRootPane;
/*     */     //   184: aload_0
/*     */     //   185: getfield 111	junit/swingui/TestSelector:fOk	Ljavax/swing/JButton;
/*     */     //   188: invokevirtual 126	javax/swing/JRootPane:setDefaultButton	(Ljavax/swing/JButton;)V
/*     */     //   191: aload_0
/*     */     //   192: invokespecial 129	junit/swingui/TestSelector:defineLayout	()V
/*     */     //   195: aload_0
/*     */     //   196: invokespecial 132	junit/swingui/TestSelector:addListeners	()V
/*     */     //   199: return
/*     */     // Line number table:
/*     */     //   Java source line #84	-> byte code offset #0
/*     */     //   Java source line #85	-> byte code offset #6
/*     */     //   Java source line #86	-> byte code offset #16
/*     */     //   Java source line #89	-> byte code offset #21
/*     */     //   Java source line #90	-> byte code offset #29
/*     */     //   Java source line #91	-> byte code offset #30
/*     */     //   Java source line #93	-> byte code offset #34
/*     */     //   Java source line #95	-> byte code offset #40
/*     */     //   Java source line #97	-> byte code offset #42
/*     */     //   Java source line #98	-> byte code offset #50
/*     */     //   Java source line #99	-> byte code offset #59
/*     */     //   Java source line #100	-> byte code offset #75
/*     */     //   Java source line #96	-> byte code offset #82
/*     */     //   Java source line #102	-> byte code offset #84
/*     */     //   Java source line #103	-> byte code offset #96
/*     */     //   Java source line #104	-> byte code offset #104
/*     */     //   Java source line #105	-> byte code offset #118
/*     */     //   Java source line #107	-> byte code offset #133
/*     */     //   Java source line #108	-> byte code offset #146
/*     */     //   Java source line #109	-> byte code offset #159
/*     */     //   Java source line #110	-> byte code offset #172
/*     */     //   Java source line #111	-> byte code offset #180
/*     */     //   Java source line #113	-> byte code offset #191
/*     */     //   Java source line #114	-> byte code offset #195
/*     */     //   Java source line #115	-> byte code offset #199
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	200	0	this	TestSelector
/*     */     //   0	200	1	parent	java.awt.Frame
/*     */     //   0	200	2	testCollector	TestCollector
/*     */     //   29	2	3	e	NoSuchMethodError
/*     */     //   41	49	3	list	Vector
/*     */     //   73	1	4	localObject1	Object
/*     */     //   59	6	5	localObject2	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   21	29	29	java/lang/NoSuchMethodError
/*     */     //   42	59	59	finally
/*     */   }
/*     */   
/*     */   static class TestCellRenderer
/*     */     extends DefaultListCellRenderer
/*     */   {
/*     */     Icon fLeafIcon;
/*     */     Icon fSuiteIcon;
/*     */     
/*     */     public TestCellRenderer()
/*     */     {
/*  30 */       this.fLeafIcon = UIManager.getIcon("Tree.leafIcon");
/*  31 */       this.fSuiteIcon = UIManager.getIcon("Tree.closedIcon");
/*     */     }
/*     */     
/*     */ 
/*     */     public Component getListCellRendererComponent(JList list, Object value, int modelIndex, boolean isSelected, boolean cellHasFocus)
/*     */     {
/*  37 */       Component c = super.getListCellRendererComponent(list, value, modelIndex, isSelected, cellHasFocus);
/*  38 */       String displayString = displayString((String)value);
/*     */       
/*  40 */       if (displayString.startsWith("AllTests")) {
/*  41 */         setIcon(this.fSuiteIcon);
/*     */       } else {
/*  43 */         setIcon(this.fLeafIcon);
/*     */       }
/*  45 */       setText(displayString);
/*  46 */       return c;
/*     */     }
/*     */     
/*     */     public static String displayString(String className) {
/*  50 */       int typeIndex = className.lastIndexOf('.');
/*  51 */       if (typeIndex < 0)
/*  52 */         return className;
/*  53 */       return className.substring(typeIndex + 1) + " - " + className.substring(0, typeIndex);
/*     */     }
/*     */     
/*     */     public static boolean matchesKey(String s, char ch) {
/*  57 */       return ch == Character.toUpperCase(s.charAt(typeIndex(s)));
/*     */     }
/*     */     
/*     */     private static int typeIndex(String s) {
/*  61 */       int typeIndex = s.lastIndexOf('.');
/*  62 */       int i = 0;
/*  63 */       if (typeIndex > 0)
/*  64 */         i = typeIndex + 1;
/*  65 */       return i;
/*     */     }
/*     */   }
/*     */   
/*     */   protected class DoubleClickListener extends MouseAdapter { protected DoubleClickListener() {}
/*     */     
/*  71 */     public void mouseClicked(MouseEvent e) { if (e.getClickCount() == 2)
/*  72 */         TestSelector.this.okSelected();
/*     */     }
/*     */   }
/*     */   
/*     */   protected class KeySelectListener extends KeyAdapter {
/*     */     protected KeySelectListener() {}
/*     */     
/*  79 */     public void keyTyped(KeyEvent e) { TestSelector.this.keySelectTestClass(e.getKeyChar()); }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void centerWindow(Component c)
/*     */   {
/* 118 */     Dimension paneSize = c.getSize();
/* 119 */     Dimension screenSize = c.getToolkit().getScreenSize();
/* 120 */     c.setLocation((screenSize.width - paneSize.width) / 2, (screenSize.height - paneSize.height) / 2);
/*     */   }
/*     */   
/*     */   private void addListeners() {
/* 124 */     this.fCancel.addActionListener(
/* 125 */       new ActionListener() {
/*     */         public void actionPerformed(ActionEvent e) {
/* 127 */           TestSelector.this.dispose();
/*     */         }
/*     */         
/*     */ 
/* 131 */       });
/* 132 */     this.fOk.addActionListener(
/* 133 */       new ActionListener() {
/*     */         public void actionPerformed(ActionEvent e) {
/* 135 */           TestSelector.this.okSelected();
/*     */         }
/*     */         
/*     */ 
/* 139 */       });
/* 140 */     this.fList.addMouseListener(new DoubleClickListener());
/* 141 */     this.fList.addKeyListener(new KeySelectListener());
/* 142 */     this.fList.addListSelectionListener(
/* 143 */       new ListSelectionListener() {
/*     */         public void valueChanged(ListSelectionEvent e) {
/* 145 */           TestSelector.this.checkEnableOK(e);
/*     */         }
/*     */         
/*     */ 
/* 149 */       });
/* 150 */     addWindowListener(
/* 151 */       new WindowAdapter() {
/*     */         public void windowClosing(WindowEvent e) {
/* 153 */           TestSelector.this.dispose();
/*     */         }
/*     */       });
/*     */   }
/*     */   
/*     */   private void defineLayout()
/*     */   {
/* 160 */     getContentPane().setLayout(new GridBagLayout());
/* 161 */     GridBagConstraints labelConstraints = new GridBagConstraints();
/* 162 */     labelConstraints.gridx = 0;labelConstraints.gridy = 0;
/* 163 */     labelConstraints.gridwidth = 1;labelConstraints.gridheight = 1;
/* 164 */     labelConstraints.fill = 1;
/* 165 */     labelConstraints.anchor = 17;
/* 166 */     labelConstraints.weightx = 1.0D;
/* 167 */     labelConstraints.weighty = 0.0D;
/* 168 */     labelConstraints.insets = new Insets(8, 8, 0, 8);
/* 169 */     getContentPane().add(this.fDescription, labelConstraints);
/*     */     
/* 171 */     GridBagConstraints listConstraints = new GridBagConstraints();
/* 172 */     listConstraints.gridx = 0;listConstraints.gridy = 1;
/* 173 */     listConstraints.gridwidth = 4;listConstraints.gridheight = 1;
/* 174 */     listConstraints.fill = 1;
/* 175 */     listConstraints.anchor = 10;
/* 176 */     listConstraints.weightx = 1.0D;
/* 177 */     listConstraints.weighty = 1.0D;
/* 178 */     listConstraints.insets = new Insets(8, 8, 8, 8);
/* 179 */     getContentPane().add(this.fScrolledList, listConstraints);
/*     */     
/* 181 */     GridBagConstraints okConstraints = new GridBagConstraints();
/* 182 */     okConstraints.gridx = 2;okConstraints.gridy = 2;
/* 183 */     okConstraints.gridwidth = 1;okConstraints.gridheight = 1;
/* 184 */     okConstraints.anchor = 13;
/* 185 */     okConstraints.insets = new Insets(0, 8, 8, 8);
/* 186 */     getContentPane().add(this.fOk, okConstraints);
/*     */     
/*     */ 
/* 189 */     GridBagConstraints cancelConstraints = new GridBagConstraints();
/* 190 */     cancelConstraints.gridx = 3;cancelConstraints.gridy = 2;
/* 191 */     cancelConstraints.gridwidth = 1;cancelConstraints.gridheight = 1;
/* 192 */     cancelConstraints.anchor = 13;
/* 193 */     cancelConstraints.insets = new Insets(0, 8, 8, 8);
/* 194 */     getContentPane().add(this.fCancel, cancelConstraints);
/*     */   }
/*     */   
/*     */   public void checkEnableOK(ListSelectionEvent e) {
/* 198 */     this.fOk.setEnabled(this.fList.getSelectedIndex() != -1);
/*     */   }
/*     */   
/*     */   public void okSelected() {
/* 202 */     this.fSelectedItem = ((String)this.fList.getSelectedValue());
/* 203 */     dispose();
/*     */   }
/*     */   
/*     */   public boolean isEmpty() {
/* 207 */     return this.fList.getModel().getSize() == 0;
/*     */   }
/*     */   
/*     */   public void keySelectTestClass(char ch) {
/* 211 */     ListModel model = this.fList.getModel();
/* 212 */     if (!Character.isJavaIdentifierStart(ch))
/* 213 */       return;
/* 214 */     for (int i = 0; i < model.getSize(); i++) {
/* 215 */       String s = (String)model.getElementAt(i);
/* 216 */       if (TestCellRenderer.matchesKey(s, Character.toUpperCase(ch))) {
/* 217 */         this.fList.setSelectedIndex(i);
/* 218 */         this.fList.ensureIndexIsVisible(i);
/* 219 */         return;
/*     */       }
/*     */     }
/* 222 */     Toolkit.getDefaultToolkit().beep();
/*     */   }
/*     */   
/*     */   public String getSelectedItem() {
/* 226 */     return this.fSelectedItem;
/*     */   }
/*     */   
/*     */   private Vector createTestList(TestCollector collector) {
/* 230 */     Enumeration each = collector.collectTests();
/* 231 */     Vector v = new Vector(200);
/* 232 */     Vector displayVector = new Vector(v.size());
/* 233 */     while (each.hasMoreElements()) {
/* 234 */       String s = (String)each.nextElement();
/* 235 */       v.addElement(s);
/* 236 */       displayVector.addElement(TestCellRenderer.displayString(s));
/*     */     }
/* 238 */     if (v.size() > 0)
/* 239 */       Sorter.sortStrings(displayVector, 0, displayVector.size() - 1, new ParallelSwapper(v));
/* 240 */     return v;
/*     */   }
/*     */   
/*     */   private class ParallelSwapper
/*     */     implements Sorter.Swapper {
/*     */     Vector fOther;
/*     */     
/* 247 */     ParallelSwapper(Vector other) { this.fOther = other; }
/*     */     
/*     */     public void swap(Vector values, int left, int right) {
/* 250 */       Object tmp = values.elementAt(left);
/* 251 */       values.setElementAt(values.elementAt(right), left);
/* 252 */       values.setElementAt(tmp, right);
/* 253 */       Object tmp2 = this.fOther.elementAt(left);
/* 254 */       this.fOther.setElementAt(this.fOther.elementAt(right), left);
/* 255 */       this.fOther.setElementAt(tmp2, right);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp3\Exp3.zip!\Exp3\lib\junit.jar!\junit\swingui\TestSelector.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */