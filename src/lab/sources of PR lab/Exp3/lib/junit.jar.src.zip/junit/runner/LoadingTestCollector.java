/*    */ package junit.runner;
/*    */ 
/*    */ import java.lang.reflect.Modifier;
/*    */ import junit.framework.Test;
/*    */ import junit.framework.TestSuite;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LoadingTestCollector
/*    */   extends ClassPathTestCollector
/*    */ {
/*    */   TestCaseClassLoader fLoader;
/*    */   
/*    */   public LoadingTestCollector()
/*    */   {
/* 18 */     this.fLoader = new TestCaseClassLoader();
/*    */   }
/*    */   
/*    */   protected boolean isTestClass(String classFileName) {
/*    */     try {
/* 23 */       if (classFileName.endsWith(".class")) {
/* 24 */         Class testClass = classFromFile(classFileName);
/* 25 */         return (testClass != null) && (isTestClass(testClass));
/*    */       }
/*    */     }
/*    */     catch (ClassNotFoundException localClassNotFoundException) {}catch (NoClassDefFoundError localNoClassDefFoundError) {}
/*    */     
/*    */ 
/*    */ 
/* 32 */     return false;
/*    */   }
/*    */   
/*    */   Class classFromFile(String classFileName) throws ClassNotFoundException {
/* 36 */     String className = classNameFromFile(classFileName);
/* 37 */     if (!this.fLoader.isExcluded(className))
/* 38 */       return this.fLoader.loadClass(className, false);
/* 39 */     return null;
/*    */   }
/*    */   
/*    */   boolean isTestClass(Class testClass) {
/* 43 */     if (hasSuiteMethod(testClass))
/* 44 */       return true;
/* 45 */     if ((Test.class.isAssignableFrom(testClass)) && (
/* 46 */       Modifier.isPublic(testClass.getModifiers())) && (
/* 47 */       hasPublicConstructor(testClass)))
/* 48 */       return true;
/* 49 */     return false;
/*    */   }
/*    */   
/*    */   boolean hasSuiteMethod(Class testClass) {
/*    */     try {
/* 54 */       testClass.getMethod("suite", new Class[0]);
/*    */     } catch (Exception e) {
/* 56 */       return false;
/*    */     }
/* 58 */     return true;
/*    */   }
/*    */   
/*    */   boolean hasPublicConstructor(Class testClass) {
/*    */     try {
/* 63 */       TestSuite.getTestConstructor(testClass);
/*    */     } catch (NoSuchMethodException e) {
/* 65 */       return false;
/*    */     }
/* 67 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp3\Exp3.zip!\Exp3\lib\junit.jar!\junit\runner\LoadingTestCollector.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */