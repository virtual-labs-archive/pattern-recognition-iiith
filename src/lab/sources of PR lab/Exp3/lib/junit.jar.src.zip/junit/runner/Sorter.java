/*    */ package junit.runner;
/*    */ 
/*    */ import java.util.Vector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Sorter
/*    */ {
/*    */   public static void sortStrings(Vector values, int left, int right, Swapper swapper)
/*    */   {
/* 18 */     int oleft = left;
/* 19 */     int oright = right;
/* 20 */     String mid = (String)values.elementAt((left + right) / 2);
/*    */     do {
/* 22 */       while (((String)values.elementAt(left)).compareTo(mid) < 0)
/* 23 */         left++;
/* 24 */       while (mid.compareTo((String)values.elementAt(right)) < 0)
/* 25 */         right--;
/* 26 */       if (left <= right) {
/* 27 */         swapper.swap(values, left, right);
/* 28 */         left++;
/* 29 */         right--;
/*    */       }
/* 31 */     } while (left <= right);
/*    */     
/* 33 */     if (oleft < right)
/* 34 */       sortStrings(values, oleft, right, swapper);
/* 35 */     if (left < oright) {
/* 36 */       sortStrings(values, left, oright, swapper);
/*    */     }
/*    */   }
/*    */   
/*    */   public static abstract interface Swapper
/*    */   {
/*    */     public abstract void swap(Vector paramVector, int paramInt1, int paramInt2);
/*    */   }
/*    */ }


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp3\Exp3.zip!\Exp3\lib\junit.jar!\junit\runner\Sorter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */