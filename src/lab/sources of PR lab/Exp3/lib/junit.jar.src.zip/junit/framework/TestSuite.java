/*     */ package junit.framework;
/*     */ 
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TestSuite
/*     */   implements Test
/*     */ {
/*  32 */   private Vector fTests = new Vector(10);
/*     */   
/*     */ 
/*     */ 
/*     */   private String fName;
/*     */   
/*     */ 
/*     */ 
/*     */   public TestSuite() {}
/*     */   
/*     */ 
/*     */ 
/*     */   public TestSuite(Class theClass, String name)
/*     */   {
/*  46 */     this(theClass);
/*  47 */     setName(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TestSuite(Class theClass)
/*     */   {
/*  57 */     this.fName = theClass.getName();
/*     */     try {
/*  59 */       getTestConstructor(theClass);
/*     */     } catch (NoSuchMethodException e) {
/*  61 */       addTest(warning("Class " + theClass.getName() + " has no public constructor TestCase(String name) or TestCase()"));
/*  62 */       return;
/*     */     }
/*     */     
/*  65 */     if (!Modifier.isPublic(theClass.getModifiers())) {
/*  66 */       addTest(warning("Class " + theClass.getName() + " is not public"));
/*  67 */       return;
/*     */     }
/*     */     
/*  70 */     Class superClass = theClass;
/*  71 */     Vector names = new Vector();
/*  72 */     while (Test.class.isAssignableFrom(superClass)) {
/*  73 */       Method[] methods = superClass.getDeclaredMethods();
/*  74 */       for (int i = 0; i < methods.length; i++) {
/*  75 */         addTestMethod(methods[i], names, theClass);
/*     */       }
/*  77 */       superClass = superClass.getSuperclass();
/*     */     }
/*  79 */     if (this.fTests.size() == 0) {
/*  80 */       addTest(warning("No tests found in " + theClass.getName()));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public TestSuite(String name)
/*     */   {
/*  87 */     setName(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void addTest(Test test)
/*     */   {
/*  94 */     this.fTests.addElement(test);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void addTestSuite(Class testClass)
/*     */   {
/* 101 */     addTest(new TestSuite(testClass));
/*     */   }
/*     */   
/*     */   private void addTestMethod(Method m, Vector names, Class theClass) {
/* 105 */     String name = m.getName();
/* 106 */     if (names.contains(name))
/* 107 */       return;
/* 108 */     if (!isPublicTestMethod(m)) {
/* 109 */       if (isTestMethod(m))
/* 110 */         addTest(warning("Test method isn't public: " + m.getName()));
/* 111 */       return;
/*     */     }
/* 113 */     names.addElement(name);
/* 114 */     addTest(createTest(theClass, name));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Test createTest(Class theClass, String name)
/*     */   {
/*     */     try
/*     */     {
/* 124 */       constructor = getTestConstructor(theClass);
/*     */     } catch (NoSuchMethodException e) { Constructor constructor;
/* 126 */       return warning("Class " + theClass.getName() + " has no public constructor TestCase(String name) or TestCase()");
/*     */     }
/*     */     try {
/*     */       Constructor constructor;
/* 130 */       if (constructor.getParameterTypes().length == 0) {
/* 131 */         Object test = constructor.newInstance(new Object[0]);
/* 132 */         if ((test instanceof TestCase))
/* 133 */           ((TestCase)test).setName(name);
/*     */       } else {
/* 135 */         test = constructor.newInstance(new Object[] { name });
/*     */       }
/*     */     } catch (InstantiationException e) { Object test;
/* 138 */       return warning("Cannot instantiate test case: " + name + " (" + exceptionToString(e) + ")");
/*     */     } catch (InvocationTargetException e) {
/* 140 */       return warning("Exception in constructor: " + name + " (" + exceptionToString(e.getTargetException()) + ")");
/*     */     } catch (IllegalAccessException e) {
/* 142 */       return warning("Cannot access test case: " + name + " (" + exceptionToString(e) + ")"); }
/*     */     Object test;
/* 144 */     return (Test)test;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static String exceptionToString(Throwable t)
/*     */   {
/* 151 */     StringWriter stringWriter = new StringWriter();
/* 152 */     PrintWriter writer = new PrintWriter(stringWriter);
/* 153 */     t.printStackTrace(writer);
/* 154 */     return stringWriter.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int countTestCases()
/*     */   {
/* 162 */     int count = 0;
/* 163 */     for (Enumeration e = tests(); e.hasMoreElements();) {
/* 164 */       Test test = (Test)e.nextElement();
/* 165 */       count += test.countTestCases();
/*     */     }
/* 167 */     return count;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static Constructor getTestConstructor(Class theClass)
/*     */     throws NoSuchMethodException
/*     */   {
/* 175 */     Class[] args = { String.class };
/*     */     try {
/* 177 */       return theClass.getConstructor(args);
/*     */     }
/*     */     catch (NoSuchMethodException localNoSuchMethodException) {}
/*     */     
/* 181 */     return theClass.getConstructor(new Class[0]);
/*     */   }
/*     */   
/*     */   private boolean isPublicTestMethod(Method m) {
/* 185 */     return (isTestMethod(m)) && (Modifier.isPublic(m.getModifiers()));
/*     */   }
/*     */   
/*     */   private boolean isTestMethod(Method m) {
/* 189 */     String name = m.getName();
/* 190 */     Class[] parameters = m.getParameterTypes();
/* 191 */     Class returnType = m.getReturnType();
/* 192 */     return (parameters.length == 0) && (name.startsWith("test")) && (returnType.equals(Void.TYPE));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void run(TestResult result)
/*     */   {
/* 199 */     for (Enumeration e = tests(); e.hasMoreElements();) {
/* 200 */       if (result.shouldStop())
/*     */         break;
/* 202 */       Test test = (Test)e.nextElement();
/* 203 */       runTest(test, result);
/*     */     }
/*     */   }
/*     */   
/*     */   public void runTest(Test test, TestResult result) {
/* 208 */     test.run(result);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Test testAt(int index)
/*     */   {
/* 215 */     return (Test)this.fTests.elementAt(index);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int testCount()
/*     */   {
/* 222 */     return this.fTests.size();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Enumeration tests()
/*     */   {
/* 229 */     return this.fTests.elements();
/*     */   }
/*     */   
/*     */ 
/*     */   public String toString()
/*     */   {
/* 235 */     if (getName() != null)
/* 236 */       return getName();
/* 237 */     return super.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setName(String name)
/*     */   {
/* 245 */     this.fName = name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/* 254 */     return this.fName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static Test warning(String message)
/*     */   {
/* 261 */     new TestCase(message) {
/*     */       protected void runTest() {
/* 263 */         Assert.fail(TestSuite.this);
/*     */       }
/*     */     };
/*     */   }
/*     */ }


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp3\Exp3.zip!\Exp3\lib\junit.jar!\junit\framework\TestSuite.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */