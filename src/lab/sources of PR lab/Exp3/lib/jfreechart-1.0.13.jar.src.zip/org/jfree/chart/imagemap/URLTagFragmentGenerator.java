package org.jfree.chart.imagemap;

public abstract interface URLTagFragmentGenerator
{
  public abstract String generateURLFragment(String paramString);
}


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp3\Exp3.zip!\Exp3\lib\jfreechart-1.0.13.jar!\org\jfree\chart\imagemap\URLTagFragmentGenerator.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       0.7.1
 */