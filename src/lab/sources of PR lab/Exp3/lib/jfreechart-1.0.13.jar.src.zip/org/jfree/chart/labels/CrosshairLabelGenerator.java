package org.jfree.chart.labels;

import org.jfree.chart.plot.Crosshair;

public abstract interface CrosshairLabelGenerator
{
  public abstract String generateLabel(Crosshair paramCrosshair);
}


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp3\Exp3.zip!\Exp3\lib\jfreechart-1.0.13.jar!\org\jfree\chart\labels\CrosshairLabelGenerator.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       0.7.1
 */