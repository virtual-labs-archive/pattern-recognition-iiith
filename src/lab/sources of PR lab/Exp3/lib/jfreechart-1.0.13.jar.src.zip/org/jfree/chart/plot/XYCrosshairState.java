package org.jfree.chart.plot;

public class XYCrosshairState
  extends CrosshairState
{}


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp3\Exp3.zip!\Exp3\lib\jfreechart-1.0.13.jar!\org\jfree\chart\plot\XYCrosshairState.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       0.7.1
 */