package org.jfree.data.function;

public abstract interface Function2D
{
  public abstract double getValue(double paramDouble);
}


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp3\Exp3.zip!\Exp3\lib\jfreechart-1.0.13.jar!\org\jfree\data\function\Function2D.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       0.7.1
 */