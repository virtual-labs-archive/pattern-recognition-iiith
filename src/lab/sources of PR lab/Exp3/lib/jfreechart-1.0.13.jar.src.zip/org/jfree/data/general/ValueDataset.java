package org.jfree.data.general;

import org.jfree.data.Value;

public abstract interface ValueDataset
  extends Value, Dataset
{}


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp3\Exp3.zip!\Exp3\lib\jfreechart-1.0.13.jar!\org\jfree\data\general\ValueDataset.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       0.7.1
 */