package org.jfree.chart.labels;

import org.jfree.data.category.CategoryDataset;

public abstract interface CategorySeriesLabelGenerator
{
  public abstract String generateLabel(CategoryDataset paramCategoryDataset, int paramInt);
}


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp3\Exp3.zip!\Exp3\lib\jfreechart-1.0.13.jar!\org\jfree\chart\labels\CategorySeriesLabelGenerator.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       0.7.1
 */