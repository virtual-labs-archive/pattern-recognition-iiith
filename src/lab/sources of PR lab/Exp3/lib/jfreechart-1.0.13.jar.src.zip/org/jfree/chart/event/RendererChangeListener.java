package org.jfree.chart.event;

import java.util.EventListener;

public abstract interface RendererChangeListener
  extends EventListener
{
  public abstract void rendererChanged(RendererChangeEvent paramRendererChangeEvent);
}


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp3\Exp3.zip!\Exp3\lib\jfreechart-1.0.13.jar!\org\jfree\chart\event\RendererChangeListener.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       0.7.1
 */