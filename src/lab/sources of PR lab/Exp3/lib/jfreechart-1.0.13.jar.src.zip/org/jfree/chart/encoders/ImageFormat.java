package org.jfree.chart.encoders;

public abstract interface ImageFormat
{
  public static final String PNG = "png";
  public static final String JPEG = "jpeg";
  public static final String GIF = "gif";
}


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp3\Exp3.zip!\Exp3\lib\jfreechart-1.0.13.jar!\org\jfree\chart\encoders\ImageFormat.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       0.7.1
 */