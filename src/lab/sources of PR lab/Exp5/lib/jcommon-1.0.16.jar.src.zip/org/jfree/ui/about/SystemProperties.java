/*    */ package org.jfree.ui.about;
/*    */ 
/*    */ import javax.swing.table.TableColumn;
/*    */ import javax.swing.table.TableColumnModel;
/*    */ import org.jfree.ui.SortableTable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SystemProperties
/*    */ {
/*    */   public static SortableTable createSystemPropertiesTable()
/*    */   {
/* 74 */     SystemPropertiesTableModel properties = new SystemPropertiesTableModel();
/* 75 */     SortableTable table = new SortableTable(properties);
/*    */     
/* 77 */     TableColumnModel model = table.getColumnModel();
/* 78 */     TableColumn column = model.getColumn(0);
/* 79 */     column.setPreferredWidth(200);
/* 80 */     column = model.getColumn(1);
/* 81 */     column.setPreferredWidth(350);
/*    */     
/* 83 */     table.setAutoResizeMode(2);
/* 84 */     return table;
/*    */   }
/*    */ }


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp5\Exp5.zip!\Exp5\lib\jcommon-1.0.16.jar!\org\jfree\ui\about\SystemProperties.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */