/*     */ package org.jfree.ui;
/*     */ 
/*     */ import java.awt.GradientPaint;
/*     */ import java.awt.Shape;
/*     */ import java.awt.geom.Rectangle2D;
/*     */ import java.io.Serializable;
/*     */ import org.jfree.util.PublicCloneable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StandardGradientPaintTransformer
/*     */   implements GradientPaintTransformer, Cloneable, PublicCloneable, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -8155025776964678320L;
/*     */   private GradientPaintTransformType type;
/*     */   
/*     */   public StandardGradientPaintTransformer()
/*     */   {
/*  74 */     this(GradientPaintTransformType.VERTICAL);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public StandardGradientPaintTransformer(GradientPaintTransformType type)
/*     */   {
/*  84 */     if (type == null) {
/*  85 */       throw new IllegalArgumentException("Null 'type' argument.");
/*     */     }
/*  87 */     this.type = type;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public GradientPaintTransformType getType()
/*     */   {
/*  98 */     return this.type;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public GradientPaint transform(GradientPaint paint, Shape target)
/*     */   {
/* 113 */     GradientPaint result = paint;
/* 114 */     Rectangle2D bounds = target.getBounds2D();
/*     */     
/* 116 */     if (this.type.equals(GradientPaintTransformType.VERTICAL)) {
/* 117 */       result = new GradientPaint((float)bounds.getCenterX(), (float)bounds.getMinY(), paint.getColor1(), (float)bounds.getCenterX(), (float)bounds.getMaxY(), paint.getColor2());
/*     */ 
/*     */ 
/*     */ 
/*     */     }
/* 122 */     else if (this.type.equals(GradientPaintTransformType.HORIZONTAL)) {
/* 123 */       result = new GradientPaint((float)bounds.getMinX(), (float)bounds.getCenterY(), paint.getColor1(), (float)bounds.getMaxX(), (float)bounds.getCenterY(), paint.getColor2());
/*     */ 
/*     */ 
/*     */ 
/*     */     }
/* 128 */     else if (this.type.equals(GradientPaintTransformType.CENTER_HORIZONTAL))
/*     */     {
/* 130 */       result = new GradientPaint((float)bounds.getCenterX(), (float)bounds.getCenterY(), paint.getColor2(), (float)bounds.getMaxX(), (float)bounds.getCenterY(), paint.getColor1(), true);
/*     */ 
/*     */ 
/*     */ 
/*     */     }
/* 135 */     else if (this.type.equals(GradientPaintTransformType.CENTER_VERTICAL)) {
/* 136 */       result = new GradientPaint((float)bounds.getCenterX(), (float)bounds.getMinY(), paint.getColor1(), (float)bounds.getCenterX(), (float)bounds.getCenterY(), paint.getColor2(), true);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 142 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 153 */     if (obj == this) {
/* 154 */       return true;
/*     */     }
/* 156 */     if (!(obj instanceof StandardGradientPaintTransformer)) {
/* 157 */       return false;
/*     */     }
/* 159 */     StandardGradientPaintTransformer that = (StandardGradientPaintTransformer)obj;
/*     */     
/* 161 */     if (this.type != that.type) {
/* 162 */       return false;
/*     */     }
/* 164 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object clone()
/*     */     throws CloneNotSupportedException
/*     */   {
/* 177 */     return super.clone();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 186 */     return this.type != null ? this.type.hashCode() : 0;
/*     */   }
/*     */ }


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp5\Exp5.zip!\Exp5\lib\jcommon-1.0.16.jar!\org\jfree\ui\StandardGradientPaintTransformer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */