package org.jfree.util;

import java.io.Serializable;
import java.util.Enumeration;
import java.util.Iterator;

public abstract interface Configuration
  extends Serializable, Cloneable
{
  public abstract String getConfigProperty(String paramString);
  
  public abstract String getConfigProperty(String paramString1, String paramString2);
  
  public abstract Iterator findPropertyKeys(String paramString);
  
  public abstract Enumeration getConfigProperties();
  
  public abstract Object clone()
    throws CloneNotSupportedException;
}


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp5\Exp5.zip!\Exp5\lib\jcommon-1.0.16.jar!\org\jfree\util\Configuration.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */