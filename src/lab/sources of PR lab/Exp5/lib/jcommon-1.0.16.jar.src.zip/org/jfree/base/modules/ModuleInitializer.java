package org.jfree.base.modules;

public abstract interface ModuleInitializer
{
  public abstract void performInit()
    throws ModuleInitializeException;
}


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp5\Exp5.zip!\Exp5\lib\jcommon-1.0.16.jar!\org\jfree\base\modules\ModuleInitializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */