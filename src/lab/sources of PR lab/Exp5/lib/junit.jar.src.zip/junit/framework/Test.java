package junit.framework;

public abstract interface Test
{
  public abstract int countTestCases();
  
  public abstract void run(TestResult paramTestResult);
}


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp5\Exp5.zip!\Exp5\lib\junit.jar!\junit\framework\Test.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */