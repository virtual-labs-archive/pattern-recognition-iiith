/*     */ package junit.runner;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Properties;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.Vector;
/*     */ import java.util.zip.ZipEntry;
/*     */ import java.util.zip.ZipFile;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TestCaseClassLoader
/*     */   extends ClassLoader
/*     */ {
/*     */   private Vector fPathItems;
/*  29 */   private String[] defaultExclusions = {
/*  30 */     "junit.framework.", 
/*  31 */     "junit.extensions.", 
/*  32 */     "junit.runner." };
/*     */   
/*     */ 
/*     */   static final String EXCLUDED_FILE = "excluded.properties";
/*     */   
/*     */ 
/*     */   private Vector fExcluded;
/*     */   
/*     */ 
/*     */ 
/*     */   public TestCaseClassLoader()
/*     */   {
/*  44 */     this(System.getProperty("java.class.path"));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public TestCaseClassLoader(String classPath)
/*     */   {
/*  52 */     scanPath(classPath);
/*  53 */     readExcludedPackages();
/*     */   }
/*     */   
/*     */   private void scanPath(String classPath) {
/*  57 */     String separator = System.getProperty("path.separator");
/*  58 */     this.fPathItems = new Vector(10);
/*  59 */     StringTokenizer st = new StringTokenizer(classPath, separator);
/*  60 */     while (st.hasMoreTokens()) {
/*  61 */       this.fPathItems.addElement(st.nextToken());
/*     */     }
/*     */   }
/*     */   
/*     */   public URL getResource(String name) {
/*  66 */     return ClassLoader.getSystemResource(name);
/*     */   }
/*     */   
/*     */   public InputStream getResourceAsStream(String name) {
/*  70 */     return ClassLoader.getSystemResourceAsStream(name);
/*     */   }
/*     */   
/*     */   public boolean isExcluded(String name) {
/*  74 */     for (int i = 0; i < this.fExcluded.size(); i++) {
/*  75 */       if (name.startsWith((String)this.fExcluded.elementAt(i))) {
/*  76 */         return true;
/*     */       }
/*     */     }
/*  79 */     return false;
/*     */   }
/*     */   
/*     */   public synchronized Class loadClass(String name, boolean resolve)
/*     */     throws ClassNotFoundException
/*     */   {
/*  85 */     Class c = findLoadedClass(name);
/*  86 */     if (c != null) {
/*  87 */       return c;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  92 */     if (isExcluded(name)) {
/*     */       try {
/*  94 */         return findSystemClass(name);
/*     */       }
/*     */       catch (ClassNotFoundException localClassNotFoundException) {}
/*     */     }
/*     */     
/*     */ 
/* 100 */     if (c == null) {
/* 101 */       byte[] data = lookupClassData(name);
/* 102 */       if (data == null)
/* 103 */         throw new ClassNotFoundException();
/* 104 */       c = defineClass(name, data, 0, data.length);
/*     */     }
/* 106 */     if (resolve)
/* 107 */       resolveClass(c);
/* 108 */     return c;
/*     */   }
/*     */   
/*     */   private byte[] lookupClassData(String className) throws ClassNotFoundException {
/* 112 */     byte[] data = null;
/* 113 */     for (int i = 0; i < this.fPathItems.size(); i++) {
/* 114 */       String path = (String)this.fPathItems.elementAt(i);
/* 115 */       String fileName = className.replace('.', '/') + ".class";
/* 116 */       if (isJar(path)) {
/* 117 */         data = loadJarData(path, fileName);
/*     */       } else {
/* 119 */         data = loadFileData(path, fileName);
/*     */       }
/* 121 */       if (data != null)
/* 122 */         return data;
/*     */     }
/* 124 */     throw new ClassNotFoundException(className);
/*     */   }
/*     */   
/*     */   boolean isJar(String pathEntry) {
/* 128 */     return (pathEntry.endsWith(".jar")) || (pathEntry.endsWith(".zip"));
/*     */   }
/*     */   
/*     */   private byte[] loadFileData(String path, String fileName) {
/* 132 */     File file = new File(path, fileName);
/* 133 */     if (file.exists()) {
/* 134 */       return getClassData(file);
/*     */     }
/* 136 */     return null;
/*     */   }
/*     */   
/*     */   private byte[] getClassData(File f) {
/*     */     try {
/* 141 */       FileInputStream stream = new FileInputStream(f);
/* 142 */       ByteArrayOutputStream out = new ByteArrayOutputStream(1000);
/* 143 */       byte[] b = new byte['Ϩ'];
/*     */       int n;
/* 145 */       while ((n = stream.read(b)) != -1) { int n;
/* 146 */         out.write(b, 0, n); }
/* 147 */       stream.close();
/* 148 */       out.close();
/* 149 */       return out.toByteArray();
/*     */     }
/*     */     catch (IOException localIOException) {}
/*     */     
/* 153 */     return null;
/*     */   }
/*     */   
/*     */   private byte[] loadJarData(String path, String fileName) {
/* 157 */     ZipFile zipFile = null;
/* 158 */     InputStream stream = null;
/* 159 */     File archive = new File(path);
/* 160 */     if (!archive.exists())
/* 161 */       return null;
/*     */     try {
/* 163 */       zipFile = new ZipFile(archive);
/*     */     } catch (IOException io) {
/* 165 */       return null;
/*     */     }
/* 167 */     ZipEntry entry = zipFile.getEntry(fileName);
/* 168 */     if (entry == null)
/* 169 */       return null;
/* 170 */     int size = (int)entry.getSize();
/*     */     try {
/* 172 */       stream = zipFile.getInputStream(entry);
/* 173 */       byte[] data = new byte[size];
/* 174 */       int pos = 0;
/* 175 */       while (pos < size) {
/* 176 */         int n = stream.read(data, pos, data.length - pos);
/* 177 */         pos += n;
/*     */       }
/* 179 */       zipFile.close();
/* 180 */       return data;
/*     */     } catch (IOException localIOException1) {}finally { break label167;
/* 182 */       localObject1 = returnAddress;
/*     */       try {
/* 184 */         if (stream != null)
/* 185 */           stream.close();
/*     */       } catch (IOException e) {}
/*     */     }
/*     */     label167:
/* 189 */     return null;
/*     */   }
/*     */   
/*     */   private void readExcludedPackages() {
/* 193 */     this.fExcluded = new Vector(10);
/* 194 */     for (int i = 0; i < this.defaultExclusions.length; i++) {
/* 195 */       this.fExcluded.addElement(this.defaultExclusions[i]);
/*     */     }
/* 197 */     InputStream is = getClass().getResourceAsStream("excluded.properties");
/* 198 */     if (is == null)
/* 199 */       return;
/* 200 */     Properties p = new Properties();
/*     */     try {
/* 202 */       p.load(is);
/*     */     } catch (IOException e) {
/*     */       return;
/*     */     } finally { break label106;
/* 206 */       localObject1 = returnAddress;
/*     */       try {
/* 208 */         is.close();
/*     */       } catch (IOException e) {}
/*     */     }
/*     */     label106:
/* 212 */     for (Enumeration e = p.propertyNames(); e.hasMoreElements();) {
/* 213 */       String key = (String)e.nextElement();
/* 214 */       if (key.startsWith("excluded.")) {
/* 215 */         String path = p.getProperty(key);
/* 216 */         path = path.trim();
/* 217 */         if (path.endsWith("*"))
/* 218 */           path = path.substring(0, path.length() - 1);
/* 219 */         if (path.length() > 0) {
/* 220 */           this.fExcluded.addElement(path);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp5\Exp5.zip!\Exp5\lib\junit.jar!\junit\runner\TestCaseClassLoader.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */