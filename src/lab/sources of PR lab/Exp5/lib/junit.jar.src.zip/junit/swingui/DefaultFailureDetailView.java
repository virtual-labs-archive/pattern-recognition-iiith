/*    */ package junit.swingui;
/*    */ 
/*    */ import java.awt.Component;
/*    */ import java.awt.Font;
/*    */ import java.util.StringTokenizer;
/*    */ import java.util.Vector;
/*    */ import javax.swing.AbstractListModel;
/*    */ import javax.swing.DefaultListCellRenderer;
/*    */ import javax.swing.JComponent;
/*    */ import javax.swing.JLabel;
/*    */ import javax.swing.JList;
/*    */ import junit.framework.TestFailure;
/*    */ 
/*    */ public class DefaultFailureDetailView implements junit.runner.FailureDetailView
/*    */ {
/*    */   JList fList;
/*    */   
/*    */   static class StackTraceListModel extends AbstractListModel
/*    */   {
/* 20 */     private Vector fLines = new Vector(20);
/*    */     
/*    */     public Object getElementAt(int index) {
/* 23 */       return this.fLines.elementAt(index);
/*    */     }
/*    */     
/*    */     public int getSize() {
/* 27 */       return this.fLines.size();
/*    */     }
/*    */     
/*    */     public void setTrace(String trace) {
/* 31 */       scan(trace);
/* 32 */       fireContentsChanged(this, 0, this.fLines.size());
/*    */     }
/*    */     
/*    */     public void clear() {
/* 36 */       this.fLines.removeAllElements();
/* 37 */       fireContentsChanged(this, 0, this.fLines.size());
/*    */     }
/*    */     
/*    */     private void scan(String trace) {
/* 41 */       this.fLines.removeAllElements();
/* 42 */       StringTokenizer st = new StringTokenizer(trace, "\n\r", false);
/* 43 */       while (st.hasMoreTokens()) {
/* 44 */         this.fLines.add(st.nextToken());
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   static class StackEntryRenderer
/*    */     extends DefaultListCellRenderer
/*    */   {
/*    */     public Component getListCellRendererComponent(JList list, Object value, int modelIndex, boolean isSelected, boolean cellHasFocus)
/*    */     {
/* 56 */       String text = ((String)value).replace('\t', ' ');
/* 57 */       Component c = super.getListCellRendererComponent(list, text, modelIndex, isSelected, cellHasFocus);
/* 58 */       setText(text);
/* 59 */       setToolTipText(text);
/* 60 */       return c;
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public Component getComponent()
/*    */   {
/* 68 */     if (this.fList == null) {
/* 69 */       this.fList = new JList(new StackTraceListModel());
/* 70 */       this.fList.setFont(new Font("Dialog", 0, 12));
/* 71 */       this.fList.setSelectionMode(0);
/* 72 */       this.fList.setVisibleRowCount(5);
/* 73 */       this.fList.setCellRenderer(new StackEntryRenderer());
/*    */     }
/* 75 */     return this.fList;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void showFailure(TestFailure failure)
/*    */   {
/* 82 */     getModel().setTrace(junit.runner.BaseTestRunner.getFilteredTrace(failure.trace()));
/*    */   }
/*    */   
/*    */ 
/*    */   public void clear()
/*    */   {
/* 88 */     getModel().clear();
/*    */   }
/*    */   
/*    */   private StackTraceListModel getModel() {
/* 92 */     return (StackTraceListModel)this.fList.getModel();
/*    */   }
/*    */ }


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp5\Exp5.zip!\Exp5\lib\junit.jar!\junit\swingui\DefaultFailureDetailView.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */