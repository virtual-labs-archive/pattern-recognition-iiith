/*     */ package junit.swingui;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Vector;
/*     */ import javax.swing.AbstractButton;
/*     */ import javax.swing.DefaultListModel;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JMenu;
/*     */ import javax.swing.JMenuBar;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JTabbedPane;
/*     */ import javax.swing.SwingUtilities;
/*     */ import junit.framework.Test;
/*     */ import junit.framework.TestResult;
/*     */ import junit.runner.BaseTestRunner;
/*     */ import junit.runner.FailureDetailView;
/*     */ 
/*     */ public class TestRunner extends BaseTestRunner implements TestRunContext
/*     */ {
/*     */   private static final int GAP = 4;
/*     */   private static final int HISTORY_LENGTH = 5;
/*     */   protected JFrame fFrame;
/*     */   private Thread fRunner;
/*     */   private TestResult fTestResult;
/*     */   private JComboBox fSuiteCombo;
/*     */   private ProgressBar fProgressIndicator;
/*     */   private DefaultListModel fFailures;
/*     */   private JLabel fLogo;
/*     */   private CounterPanel fCounterPanel;
/*     */   private JButton fRun;
/*     */   private JButton fQuitButton;
/*     */   private JButton fRerunButton;
/*     */   private StatusLine fStatusLine;
/*     */   private FailureDetailView fFailureView;
/*     */   private JTabbedPane fTestViewTab;
/*     */   private javax.swing.JCheckBox fUseLoadingRunner;
/*  43 */   private Vector fTestRunViews = new Vector();
/*     */   
/*     */   private static final String TESTCOLLECTOR_KEY = "TestCollectorClass";
/*     */   
/*     */   private static final String FAILUREDETAILVIEW_KEY = "FailureViewClass";
/*     */   
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/*  52 */     new TestRunner().start(args);
/*     */   }
/*     */   
/*     */   public static void run(Class test) {
/*  56 */     String[] args = { test.getName() };
/*  57 */     main(args);
/*     */   }
/*     */   
/*     */   public void testFailed(int status, Test test, Throwable t) {
/*  61 */     SwingUtilities.invokeLater(
/*  62 */       new Runnable() { private final int val$status;
/*     */         
/*  64 */         public void run() { switch (this.val$status) {
/*     */           case 1: 
/*  66 */             TestRunner.this.fCounterPanel.setErrorValue(TestRunner.this.fTestResult.errorCount());
/*  67 */             TestRunner.this.appendFailure(this.val$test, this.val$t);
/*  68 */             break;
/*     */           case 2: 
/*  70 */             TestRunner.this.fCounterPanel.setFailureValue(TestRunner.this.fTestResult.failureCount());
/*  71 */             TestRunner.this.appendFailure(this.val$test, this.val$t);
/*     */           }
/*     */           
/*     */         }
/*     */       });
/*     */   }
/*     */   
/*     */   public void testStarted(String testName)
/*     */   {
/*  80 */     postInfo("Running: " + testName);
/*     */   }
/*     */   
/*     */   public void testEnded(String stringName) {
/*  84 */     synchUI();
/*  85 */     SwingUtilities.invokeLater(
/*  86 */       new Runnable() {
/*     */         public void run() {
/*  88 */           if (TestRunner.this.fTestResult != null) {
/*  89 */             TestRunner.this.fCounterPanel.setRunValue(TestRunner.this.fTestResult.runCount());
/*  90 */             TestRunner.this.fProgressIndicator.step(TestRunner.this.fTestResult.runCount(), TestRunner.this.fTestResult.wasSuccessful());
/*     */           }
/*     */         }
/*     */       });
/*     */   }
/*     */   
/*     */   public void setSuite(String suiteName)
/*     */   {
/*  98 */     this.fSuiteCombo.getEditor().setItem(suiteName);
/*     */   }
/*     */   
/*     */   private void addToHistory(String suite) {
/* 102 */     for (int i = 0; i < this.fSuiteCombo.getItemCount(); i++) {
/* 103 */       if (suite.equals(this.fSuiteCombo.getItemAt(i))) {
/* 104 */         this.fSuiteCombo.removeItemAt(i);
/* 105 */         this.fSuiteCombo.insertItemAt(suite, 0);
/* 106 */         this.fSuiteCombo.setSelectedIndex(0);
/* 107 */         return;
/*     */       }
/*     */     }
/* 110 */     this.fSuiteCombo.insertItemAt(suite, 0);
/* 111 */     this.fSuiteCombo.setSelectedIndex(0);
/* 112 */     pruneHistory();
/*     */   }
/*     */   
/*     */   private void pruneHistory() {
/* 116 */     int historyLength = BaseTestRunner.getPreference("maxhistory", 5);
/* 117 */     if (historyLength < 1)
/* 118 */       historyLength = 1;
/* 119 */     for (int i = this.fSuiteCombo.getItemCount() - 1; i > historyLength - 1; i--)
/* 120 */       this.fSuiteCombo.removeItemAt(i);
/*     */   }
/*     */   
/*     */   private void appendFailure(Test test, Throwable t) {
/* 124 */     this.fFailures.addElement(new junit.framework.TestFailure(test, t));
/* 125 */     if (this.fFailures.size() == 1)
/* 126 */       revealFailure(test);
/*     */   }
/*     */   
/*     */   private void revealFailure(Test test) {
/* 130 */     for (Enumeration e = this.fTestRunViews.elements(); e.hasMoreElements();) {
/* 131 */       TestRunView v = (TestRunView)e.nextElement();
/* 132 */       v.revealFailure(test);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void aboutToStart(Test testSuite) {
/* 137 */     for (Enumeration e = this.fTestRunViews.elements(); e.hasMoreElements();) {
/* 138 */       TestRunView v = (TestRunView)e.nextElement();
/* 139 */       v.aboutToStart(testSuite, this.fTestResult);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void runFinished(Test testSuite) {
/* 144 */     SwingUtilities.invokeLater(
/* 145 */       new Runnable() { private final Test val$testSuite;
/*     */         
/* 147 */         public void run() { for (Enumeration e = TestRunner.this.fTestRunViews.elements(); e.hasMoreElements();) {
/* 148 */             TestRunView v = (TestRunView)e.nextElement();
/* 149 */             v.runFinished(this.val$testSuite, TestRunner.this.fTestResult);
/*     */           }
/*     */         }
/*     */       });
/*     */   }
/*     */   
/*     */   protected CounterPanel createCounterPanel()
/*     */   {
/* 157 */     return new CounterPanel();
/*     */   }
/*     */   
/*     */   protected JPanel createFailedPanel() {
/* 161 */     JPanel failedPanel = new JPanel(new java.awt.GridLayout(0, 1, 0, 2));
/* 162 */     this.fRerunButton = new JButton("Run");
/* 163 */     this.fRerunButton.setEnabled(false);
/* 164 */     this.fRerunButton.addActionListener(
/* 165 */       new ActionListener() {
/*     */         public void actionPerformed(ActionEvent e) {
/* 167 */           TestRunner.this.rerun();
/*     */         }
/*     */         
/* 170 */       });
/* 171 */     failedPanel.add(this.fRerunButton);
/* 172 */     return failedPanel;
/*     */   }
/*     */   
/*     */   protected FailureDetailView createFailureDetailView() {
/* 176 */     String className = BaseTestRunner.getPreference("FailureViewClass");
/* 177 */     if (className != null) {
/* 178 */       Class viewClass = null;
/*     */       try {
/* 180 */         viewClass = Class.forName(className);
/* 181 */         return (FailureDetailView)viewClass.newInstance();
/*     */       } catch (Exception e) {
/* 183 */         javax.swing.JOptionPane.showMessageDialog(this.fFrame, "Could not create Failure DetailView - using default view");
/*     */       }
/*     */     }
/* 186 */     return new DefaultFailureDetailView();
/*     */   }
/*     */   
/*     */ 
/*     */   private final Test val$test;
/*     */   private final Throwable val$t;
/*     */   protected JMenu createJUnitMenu()
/*     */   {
/* 194 */     JMenu menu = new JMenu("JUnit");
/* 195 */     menu.setMnemonic('J');
/* 196 */     javax.swing.JMenuItem mi1 = new javax.swing.JMenuItem("About...");
/* 197 */     mi1.addActionListener(
/* 198 */       new ActionListener() {
/*     */         public void actionPerformed(ActionEvent event) {
/* 200 */           TestRunner.this.about();
/*     */         }
/*     */         
/* 203 */       });
/* 204 */     mi1.setMnemonic('A');
/* 205 */     menu.add(mi1);
/*     */     
/* 207 */     menu.addSeparator();
/* 208 */     javax.swing.JMenuItem mi2 = new javax.swing.JMenuItem(" Exit ");
/* 209 */     mi2.addActionListener(
/* 210 */       new ActionListener() {
/*     */         public void actionPerformed(ActionEvent event) {
/* 212 */           TestRunner.this.terminate();
/*     */         }
/*     */         
/* 215 */       });
/* 216 */     mi2.setMnemonic('x');
/* 217 */     menu.add(mi2);
/*     */     
/* 219 */     return menu;
/*     */   }
/*     */   
/*     */   protected JFrame createFrame() {
/* 223 */     JFrame frame = new JFrame("JUnit");
/* 224 */     java.awt.Image icon = loadFrameIcon();
/* 225 */     if (icon != null)
/* 226 */       frame.setIconImage(icon);
/* 227 */     frame.getContentPane().setLayout(new java.awt.BorderLayout(0, 0));
/*     */     
/* 229 */     frame.addWindowListener(
/* 230 */       new java.awt.event.WindowAdapter() {
/*     */         public void windowClosing(java.awt.event.WindowEvent e) {
/* 232 */           TestRunner.this.terminate();
/*     */         }
/*     */         
/* 235 */       });
/* 236 */     return frame;
/*     */   }
/*     */   
/*     */   protected JLabel createLogo()
/*     */   {
/* 241 */     javax.swing.Icon icon = getIconResource(BaseTestRunner.class, "logo.gif");
/* 242 */     JLabel label; JLabel label; if (icon != null) {
/* 243 */       label = new JLabel(icon);
/*     */     } else
/* 245 */       label = new JLabel("JV");
/* 246 */     label.setToolTipText("JUnit Version " + junit.runner.Version.id());
/* 247 */     return label;
/*     */   }
/*     */   
/*     */   protected void createMenus(JMenuBar mb) {
/* 251 */     mb.add(createJUnitMenu());
/*     */   }
/*     */   
/*     */   protected javax.swing.JCheckBox createUseLoaderCheckBox() {
/* 255 */     boolean useLoader = useReloadingTestSuiteLoader();
/* 256 */     javax.swing.JCheckBox box = new javax.swing.JCheckBox("Reload classes every run", useLoader);
/* 257 */     box.setToolTipText("Use a custom class loader to reload the classes for every run");
/* 258 */     if (BaseTestRunner.inVAJava())
/* 259 */       box.setVisible(false);
/* 260 */     return box;
/*     */   }
/*     */   
/*     */ 
/*     */   protected JButton createQuitButton()
/*     */   {
/* 266 */     JButton quit = new JButton(" Exit ");
/* 267 */     quit.addActionListener(
/* 268 */       new ActionListener() {
/*     */         public void actionPerformed(ActionEvent e) {
/* 270 */           TestRunner.this.terminate();
/*     */         }
/*     */         
/* 273 */       });
/* 274 */     return quit;
/*     */   }
/*     */   
/*     */   protected JButton createRunButton() {
/* 278 */     JButton run = new JButton("Run");
/* 279 */     run.setEnabled(true);
/* 280 */     run.addActionListener(
/* 281 */       new ActionListener() {
/*     */         public void actionPerformed(ActionEvent e) {
/* 283 */           TestRunner.this.runSuite();
/*     */         }
/*     */         
/* 286 */       });
/* 287 */     return run;
/*     */   }
/*     */   
/*     */   protected Component createBrowseButton() {
/* 291 */     JButton browse = new JButton("...");
/* 292 */     browse.setToolTipText("Select a Test class");
/* 293 */     browse.addActionListener(
/* 294 */       new ActionListener() {
/*     */         public void actionPerformed(ActionEvent e) {
/* 296 */           TestRunner.this.browseTestClasses();
/*     */         }
/*     */         
/* 299 */       });
/* 300 */     return browse;
/*     */   }
/*     */   
/*     */   protected StatusLine createStatusLine() {
/* 304 */     return new StatusLine(380);
/*     */   }
/*     */   
/*     */   protected JComboBox createSuiteCombo() {
/* 308 */     JComboBox combo = new JComboBox();
/* 309 */     combo.setEditable(true);
/* 310 */     combo.setLightWeightPopupEnabled(false);
/*     */     
/* 312 */     combo.getEditor().getEditorComponent().addKeyListener(
/* 313 */       new java.awt.event.KeyAdapter() {
/*     */         public void keyTyped(java.awt.event.KeyEvent e) {
/* 315 */           TestRunner.this.textChanged();
/* 316 */           if (e.getKeyChar() == '\n') {
/* 317 */             TestRunner.this.runSuite();
/*     */           }
/*     */         }
/*     */       });
/*     */     try {
/* 322 */       loadHistory(combo);
/*     */     }
/*     */     catch (java.io.IOException localIOException) {}
/*     */     
/* 326 */     combo.addItemListener(
/* 327 */       new java.awt.event.ItemListener() {
/*     */         public void itemStateChanged(java.awt.event.ItemEvent event) {
/* 329 */           if (event.getStateChange() == 1) {
/* 330 */             TestRunner.this.textChanged();
/*     */           }
/*     */           
/*     */         }
/* 334 */       });
/* 335 */     return combo;
/*     */   }
/*     */   
/*     */   protected JTabbedPane createTestRunViews() {
/* 339 */     JTabbedPane pane = new JTabbedPane(3);
/*     */     
/* 341 */     FailureRunView lv = new FailureRunView(this);
/* 342 */     this.fTestRunViews.addElement(lv);
/* 343 */     lv.addTab(pane);
/*     */     
/* 345 */     TestHierarchyRunView tv = new TestHierarchyRunView(this);
/* 346 */     this.fTestRunViews.addElement(tv);
/* 347 */     tv.addTab(pane);
/*     */     
/* 349 */     pane.addChangeListener(
/* 350 */       new javax.swing.event.ChangeListener() {
/*     */         public void stateChanged(javax.swing.event.ChangeEvent e) {
/* 352 */           TestRunner.this.testViewChanged();
/*     */         }
/*     */         
/* 355 */       });
/* 356 */     return pane;
/*     */   }
/*     */   
/*     */   public void testViewChanged() {
/* 360 */     TestRunView view = (TestRunView)this.fTestRunViews.elementAt(this.fTestViewTab.getSelectedIndex());
/* 361 */     view.activate();
/*     */   }
/*     */   
/*     */   protected TestResult createTestResult() {
/* 365 */     return new TestResult();
/*     */   }
/*     */   
/*     */   protected JFrame createUI(String suiteName) {
/* 369 */     JFrame frame = createFrame();
/* 370 */     JMenuBar mb = new JMenuBar();
/* 371 */     createMenus(mb);
/* 372 */     frame.setJMenuBar(mb);
/*     */     
/* 374 */     JLabel suiteLabel = new JLabel("Test class name:");
/* 375 */     this.fSuiteCombo = createSuiteCombo();
/* 376 */     this.fRun = createRunButton();
/* 377 */     frame.getRootPane().setDefaultButton(this.fRun);
/* 378 */     Component browseButton = createBrowseButton();
/*     */     
/* 380 */     this.fUseLoadingRunner = createUseLoaderCheckBox();
/* 381 */     this.fProgressIndicator = new ProgressBar();
/* 382 */     this.fCounterPanel = createCounterPanel();
/*     */     
/* 384 */     this.fFailures = new DefaultListModel();
/*     */     
/* 386 */     this.fTestViewTab = createTestRunViews();
/* 387 */     JPanel failedPanel = createFailedPanel();
/*     */     
/* 389 */     this.fFailureView = createFailureDetailView();
/* 390 */     javax.swing.JScrollPane tracePane = new javax.swing.JScrollPane(this.fFailureView.getComponent(), 22, 32);
/*     */     
/* 392 */     this.fStatusLine = createStatusLine();
/* 393 */     this.fQuitButton = createQuitButton();
/* 394 */     this.fLogo = createLogo();
/*     */     
/* 396 */     JPanel panel = new JPanel(new java.awt.GridBagLayout());
/*     */     
/* 398 */     addGrid(panel, suiteLabel, 0, 0, 2, 2, 1.0D, 17);
/* 399 */     addGrid(panel, this.fSuiteCombo, 0, 1, 1, 2, 1.0D, 17);
/* 400 */     addGrid(panel, browseButton, 1, 1, 1, 0, 0.0D, 17);
/* 401 */     addGrid(panel, this.fRun, 2, 1, 1, 2, 0.0D, 10);
/*     */     
/* 403 */     addGrid(panel, this.fUseLoadingRunner, 0, 2, 3, 0, 1.0D, 17);
/*     */     
/*     */ 
/*     */ 
/* 407 */     addGrid(panel, this.fProgressIndicator, 0, 3, 2, 2, 1.0D, 17);
/* 408 */     addGrid(panel, this.fLogo, 2, 3, 1, 0, 0.0D, 11);
/*     */     
/* 410 */     addGrid(panel, this.fCounterPanel, 0, 4, 2, 0, 0.0D, 17);
/* 411 */     addGrid(panel, new javax.swing.JSeparator(), 0, 5, 2, 2, 1.0D, 17);
/* 412 */     addGrid(panel, new JLabel("Results:"), 0, 6, 2, 2, 1.0D, 17);
/*     */     
/* 414 */     javax.swing.JSplitPane splitter = new javax.swing.JSplitPane(0, this.fTestViewTab, tracePane);
/* 415 */     addGrid(panel, splitter, 0, 7, 2, 1, 1.0D, 17);
/*     */     
/* 417 */     addGrid(panel, failedPanel, 2, 7, 1, 2, 0.0D, 11);
/*     */     
/* 419 */     addGrid(panel, this.fStatusLine, 0, 9, 2, 2, 1.0D, 10);
/* 420 */     addGrid(panel, this.fQuitButton, 2, 9, 1, 2, 0.0D, 10);
/*     */     
/* 422 */     frame.setContentPane(panel);
/* 423 */     frame.pack();
/* 424 */     frame.setLocation(200, 200);
/* 425 */     return frame;
/*     */   }
/*     */   
/*     */   private void addGrid(JPanel p, Component co, int x, int y, int w, int fill, double wx, int anchor) {
/* 429 */     java.awt.GridBagConstraints c = new java.awt.GridBagConstraints();
/* 430 */     c.gridx = x;c.gridy = y;
/* 431 */     c.gridwidth = w;
/* 432 */     c.anchor = anchor;
/* 433 */     c.weightx = wx;
/* 434 */     c.fill = fill;
/* 435 */     if ((fill == 1) || (fill == 3))
/* 436 */       c.weighty = 1.0D;
/* 437 */     c.insets = new java.awt.Insets(y == 0 ? 10 : 0, x == 0 ? 10 : 4, 4, 4);
/* 438 */     p.add(co, c);
/*     */   }
/*     */   
/*     */   protected String getSuiteText() {
/* 442 */     if (this.fSuiteCombo == null)
/* 443 */       return "";
/* 444 */     return (String)this.fSuiteCombo.getEditor().getItem();
/*     */   }
/*     */   
/*     */   public javax.swing.ListModel getFailures() {
/* 448 */     return this.fFailures;
/*     */   }
/*     */   
/*     */   public void insertUpdate(javax.swing.event.DocumentEvent event) {
/* 452 */     textChanged();
/*     */   }
/*     */   
/*     */   public void browseTestClasses() {
/* 456 */     junit.runner.TestCollector collector = createTestCollector();
/* 457 */     TestSelector selector = new TestSelector(this.fFrame, collector);
/* 458 */     if (selector.isEmpty()) {
/* 459 */       javax.swing.JOptionPane.showMessageDialog(this.fFrame, "No Test Cases found.\nCheck that the configured 'TestCollector' is supported on this platform.");
/* 460 */       return;
/*     */     }
/* 462 */     selector.show();
/* 463 */     String className = selector.getSelectedItem();
/* 464 */     if (className != null)
/* 465 */       setSuite(className);
/*     */   }
/*     */   
/*     */   junit.runner.TestCollector createTestCollector() {
/* 469 */     String className = BaseTestRunner.getPreference("TestCollectorClass");
/* 470 */     if (className != null) {
/* 471 */       Class collectorClass = null;
/*     */       try {
/* 473 */         collectorClass = Class.forName(className);
/* 474 */         return (junit.runner.TestCollector)collectorClass.newInstance();
/*     */       } catch (Exception e) {
/* 476 */         javax.swing.JOptionPane.showMessageDialog(this.fFrame, "Could not create TestCollector - using default collector");
/*     */       }
/*     */     }
/* 479 */     return new junit.runner.SimpleTestCollector();
/*     */   }
/*     */   
/*     */   private java.awt.Image loadFrameIcon() {
/* 483 */     javax.swing.ImageIcon icon = (javax.swing.ImageIcon)getIconResource(BaseTestRunner.class, "smalllogo.gif");
/* 484 */     if (icon != null)
/* 485 */       return icon.getImage();
/* 486 */     return null;
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   private void loadHistory(JComboBox combo)
/*     */     throws java.io.IOException
/*     */   {
/*     */     // Byte code:
/*     */     //   0: new 790	java/io/BufferedReader
/*     */     //   3: dup
/*     */     //   4: new 792	java/io/FileReader
/*     */     //   7: dup
/*     */     //   8: aload_0
/*     */     //   9: invokespecial 796	junit/swingui/TestRunner:getSettingsFile	()Ljava/io/File;
/*     */     //   12: invokespecial 799	java/io/FileReader:<init>	(Ljava/io/File;)V
/*     */     //   15: invokespecial 802	java/io/BufferedReader:<init>	(Ljava/io/Reader;)V
/*     */     //   18: astore_2
/*     */     //   19: iconst_0
/*     */     //   20: istore_3
/*     */     //   21: goto +12 -> 33
/*     */     //   24: aload_1
/*     */     //   25: aload 4
/*     */     //   27: invokevirtual 805	javax/swing/JComboBox:addItem	(Ljava/lang/Object;)V
/*     */     //   30: iinc 3 1
/*     */     //   33: aload_2
/*     */     //   34: invokevirtual 808	java/io/BufferedReader:readLine	()Ljava/lang/String;
/*     */     //   37: dup
/*     */     //   38: astore 4
/*     */     //   40: ifnonnull -16 -> 24
/*     */     //   43: iload_3
/*     */     //   44: ifle +19 -> 63
/*     */     //   47: aload_1
/*     */     //   48: iconst_0
/*     */     //   49: invokevirtual 169	javax/swing/JComboBox:setSelectedIndex	(I)V
/*     */     //   52: goto +11 -> 63
/*     */     //   55: astore 6
/*     */     //   57: jsr +12 -> 69
/*     */     //   60: aload 6
/*     */     //   62: athrow
/*     */     //   63: jsr +6 -> 69
/*     */     //   66: goto +11 -> 77
/*     */     //   69: astore 5
/*     */     //   71: aload_2
/*     */     //   72: invokevirtual 811	java/io/BufferedReader:close	()V
/*     */     //   75: ret 5
/*     */     //   77: return
/*     */     // Line number table:
/*     */     //   Java source line #490	-> byte code offset #0
/*     */     //   Java source line #491	-> byte code offset #19
/*     */     //   Java source line #494	-> byte code offset #21
/*     */     //   Java source line #495	-> byte code offset #24
/*     */     //   Java source line #496	-> byte code offset #30
/*     */     //   Java source line #494	-> byte code offset #33
/*     */     //   Java source line #498	-> byte code offset #43
/*     */     //   Java source line #499	-> byte code offset #47
/*     */     //   Java source line #501	-> byte code offset #55
/*     */     //   Java source line #502	-> byte code offset #71
/*     */     //   Java source line #492	-> byte code offset #75
/*     */     //   Java source line #504	-> byte code offset #77
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	78	0	this	TestRunner
/*     */     //   0	78	1	combo	JComboBox
/*     */     //   18	54	2	br	java.io.BufferedReader
/*     */     //   20	24	3	itemCount	int
/*     */     //   24	2	4	line	String
/*     */     //   38	3	4	line	String
/*     */     //   69	1	5	localObject1	Object
/*     */     //   55	6	6	localObject2	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   21	55	55	finally
/*     */   }
/*     */   
/*     */   private java.io.File getSettingsFile()
/*     */   {
/* 507 */     String home = System.getProperty("user.home");
/* 508 */     return new java.io.File(home, ".junitsession");
/*     */   }
/*     */   
/*     */   private void postInfo(String message) {
/* 512 */     SwingUtilities.invokeLater(
/* 513 */       new Runnable() { private final String val$message;
/*     */         
/* 515 */         public void run() { TestRunner.this.showInfo(this.val$message); }
/*     */       });
/*     */   }
/*     */   
/*     */ 
/*     */   private void postStatus(String status)
/*     */   {
/* 522 */     SwingUtilities.invokeLater(
/* 523 */       new Runnable() { private final String val$status;
/*     */         
/* 525 */         public void run() { TestRunner.this.showStatus(this.val$status); }
/*     */       });
/*     */   }
/*     */   
/*     */ 
/*     */   public void removeUpdate(javax.swing.event.DocumentEvent event)
/*     */   {
/* 532 */     textChanged();
/*     */   }
/*     */   
/*     */   private void rerun() {
/* 536 */     TestRunView view = (TestRunView)this.fTestRunViews.elementAt(this.fTestViewTab.getSelectedIndex());
/* 537 */     Test rerunTest = view.getSelectedTest();
/* 538 */     if (rerunTest != null)
/* 539 */       rerunTest(rerunTest);
/*     */   }
/*     */   
/*     */   private void rerunTest(Test test) {
/* 543 */     if (!(test instanceof junit.framework.TestCase)) {
/* 544 */       showInfo("Could not reload " + test.toString());
/* 545 */       return;
/*     */     }
/* 547 */     Test reloadedTest = null;
/* 548 */     junit.framework.TestCase rerunTest = (junit.framework.TestCase)test;
/*     */     try
/*     */     {
/* 551 */       Class reloadedTestClass = getLoader().reload(test.getClass());
/* 552 */       reloadedTest = junit.framework.TestSuite.createTest(reloadedTestClass, rerunTest.getName());
/*     */     } catch (Exception e) {
/* 554 */       showInfo("Could not reload " + test.toString());
/* 555 */       return;
/*     */     }
/* 557 */     TestResult result = new TestResult();
/* 558 */     reloadedTest.run(result);
/*     */     
/* 560 */     String message = reloadedTest.toString();
/* 561 */     if (result.wasSuccessful()) {
/* 562 */       showInfo(message + " was successful");
/* 563 */     } else if (result.errorCount() == 1) {
/* 564 */       showStatus(message + " had an error");
/*     */     } else
/* 566 */       showStatus(message + " had a failure");
/*     */   }
/*     */   
/*     */   protected void reset() {
/* 570 */     this.fCounterPanel.reset();
/* 571 */     this.fProgressIndicator.reset();
/* 572 */     this.fRerunButton.setEnabled(false);
/* 573 */     this.fFailureView.clear();
/* 574 */     this.fFailures.clear();
/*     */   }
/*     */   
/*     */   protected void runFailed(String message) {
/* 578 */     showStatus(message);
/* 579 */     this.fRun.setText("Run");
/* 580 */     this.fRunner = null;
/*     */   }
/*     */   
/*     */   public synchronized void runSuite() {
/* 584 */     if (this.fRunner != null) {
/* 585 */       this.fTestResult.stop();
/*     */     } else {
/* 587 */       setLoading(shouldReload());
/* 588 */       reset();
/* 589 */       showInfo("Load Test Case...");
/* 590 */       String suiteName = getSuiteText();
/* 591 */       Test testSuite = getTest(suiteName);
/* 592 */       if (testSuite != null) {
/* 593 */         addToHistory(suiteName);
/* 594 */         doRunTest(testSuite);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean shouldReload() {
/* 600 */     return (!BaseTestRunner.inVAJava()) && (this.fUseLoadingRunner.isSelected());
/*     */   }
/*     */   
/*     */   protected synchronized void runTest(Test testSuite)
/*     */   {
/* 605 */     if (this.fRunner != null) {
/* 606 */       this.fTestResult.stop();
/*     */     } else {
/* 608 */       reset();
/* 609 */       if (testSuite != null) {
/* 610 */         doRunTest(testSuite);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void doRunTest(Test testSuite) {
/* 616 */     setButtonLabel(this.fRun, "Stop");
/* 617 */     this.fRunner = new Thread(testSuite) { private final Test val$testSuite;
/*     */       
/* 619 */       public void run() { TestRunner.this.start(this.val$testSuite);
/* 620 */         TestRunner.this.postInfo("Running...");
/*     */         
/* 622 */         long startTime = System.currentTimeMillis();
/* 623 */         this.val$testSuite.run(TestRunner.this.fTestResult);
/*     */         
/* 625 */         if (TestRunner.this.fTestResult.shouldStop()) {
/* 626 */           TestRunner.this.postStatus("Stopped");
/*     */         } else {
/* 628 */           long endTime = System.currentTimeMillis();
/* 629 */           long runTime = endTime - startTime;
/* 630 */           TestRunner.this.postInfo("Finished: " + TestRunner.this.elapsedTimeAsString(runTime) + " seconds");
/*     */         }
/* 632 */         TestRunner.this.runFinished(this.val$testSuite);
/* 633 */         TestRunner.this.setButtonLabel(TestRunner.this.fRun, "Run");
/* 634 */         TestRunner.this.fRunner = null;
/* 635 */         System.gc();
/*     */       }
/*     */       
/*     */ 
/* 639 */     };
/* 640 */     this.fTestResult = createTestResult();
/* 641 */     this.fTestResult.addListener(this);
/* 642 */     aboutToStart(testSuite);
/*     */     
/* 644 */     this.fRunner.start();
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   private void saveHistory()
/*     */     throws java.io.IOException
/*     */   {
/*     */     // Byte code:
/*     */     //   0: new 978	java/io/BufferedWriter
/*     */     //   3: dup
/*     */     //   4: new 980	java/io/FileWriter
/*     */     //   7: dup
/*     */     //   8: aload_0
/*     */     //   9: invokespecial 796	junit/swingui/TestRunner:getSettingsFile	()Ljava/io/File;
/*     */     //   12: invokespecial 981	java/io/FileWriter:<init>	(Ljava/io/File;)V
/*     */     //   15: invokespecial 984	java/io/BufferedWriter:<init>	(Ljava/io/Writer;)V
/*     */     //   18: astore_1
/*     */     //   19: iconst_0
/*     */     //   20: istore_2
/*     */     //   21: goto +32 -> 53
/*     */     //   24: aload_0
/*     */     //   25: getfield 136	junit/swingui/TestRunner:fSuiteCombo	Ljavax/swing/JComboBox;
/*     */     //   28: iload_2
/*     */     //   29: invokevirtual 154	javax/swing/JComboBox:getItemAt	(I)Ljava/lang/Object;
/*     */     //   32: invokevirtual 856	java/lang/Object:toString	()Ljava/lang/String;
/*     */     //   35: astore_3
/*     */     //   36: aload_1
/*     */     //   37: aload_3
/*     */     //   38: iconst_0
/*     */     //   39: aload_3
/*     */     //   40: invokevirtual 987	java/lang/String:length	()I
/*     */     //   43: invokevirtual 991	java/io/BufferedWriter:write	(Ljava/lang/String;II)V
/*     */     //   46: aload_1
/*     */     //   47: invokevirtual 994	java/io/BufferedWriter:newLine	()V
/*     */     //   50: iinc 2 1
/*     */     //   53: iload_2
/*     */     //   54: aload_0
/*     */     //   55: getfield 136	junit/swingui/TestRunner:fSuiteCombo	Ljavax/swing/JComboBox;
/*     */     //   58: invokevirtual 173	javax/swing/JComboBox:getItemCount	()I
/*     */     //   61: if_icmplt -37 -> 24
/*     */     //   64: goto +11 -> 75
/*     */     //   67: astore 5
/*     */     //   69: jsr +12 -> 81
/*     */     //   72: aload 5
/*     */     //   74: athrow
/*     */     //   75: jsr +6 -> 81
/*     */     //   78: goto +11 -> 89
/*     */     //   81: astore 4
/*     */     //   83: aload_1
/*     */     //   84: invokevirtual 995	java/io/BufferedWriter:close	()V
/*     */     //   87: ret 4
/*     */     //   89: return
/*     */     // Line number table:
/*     */     //   Java source line #648	-> byte code offset #0
/*     */     //   Java source line #650	-> byte code offset #19
/*     */     //   Java source line #651	-> byte code offset #24
/*     */     //   Java source line #652	-> byte code offset #36
/*     */     //   Java source line #653	-> byte code offset #46
/*     */     //   Java source line #650	-> byte code offset #50
/*     */     //   Java source line #655	-> byte code offset #67
/*     */     //   Java source line #656	-> byte code offset #83
/*     */     //   Java source line #649	-> byte code offset #87
/*     */     //   Java source line #658	-> byte code offset #89
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	90	0	this	TestRunner
/*     */     //   18	66	1	bw	java.io.BufferedWriter
/*     */     //   20	34	2	i	int
/*     */     //   35	5	3	testsuite	String
/*     */     //   81	1	4	localObject1	Object
/*     */     //   67	6	5	localObject2	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   19	67	67	finally
/*     */   }
/*     */   
/*     */   private void setButtonLabel(JButton button, String label)
/*     */   {
/* 661 */     SwingUtilities.invokeLater(
/* 662 */       new Runnable() { private final String val$label;
/*     */         
/* 664 */         public void run() { TestRunner.this.setText(this.val$label); }
/*     */       });
/*     */   }
/*     */   
/*     */ 
/*     */   public void handleTestSelected(Test test)
/*     */   {
/* 671 */     this.fRerunButton.setEnabled((test != null) && ((test instanceof junit.framework.TestCase)));
/* 672 */     showFailureDetail(test);
/*     */   }
/*     */   
/*     */   private void showFailureDetail(Test test) {
/* 676 */     if (test != null) {
/* 677 */       javax.swing.ListModel failures = getFailures();
/* 678 */       for (int i = 0; i < failures.getSize(); i++) {
/* 679 */         junit.framework.TestFailure failure = (junit.framework.TestFailure)failures.getElementAt(i);
/* 680 */         if (failure.failedTest() == test) {
/* 681 */           this.fFailureView.showFailure(failure);
/* 682 */           return;
/*     */         }
/*     */       }
/*     */     }
/* 686 */     this.fFailureView.clear();
/*     */   }
/*     */   
/*     */   private void showInfo(String message) {
/* 690 */     this.fStatusLine.showInfo(message);
/*     */   }
/*     */   
/*     */   private void showStatus(String status) {
/* 694 */     this.fStatusLine.showError(status);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void start(String[] args)
/*     */   {
/* 701 */     String suiteName = processArguments(args);
/* 702 */     this.fFrame = createUI(suiteName);
/* 703 */     this.fFrame.pack();
/* 704 */     this.fFrame.setVisible(true);
/*     */     
/* 706 */     if (suiteName != null) {
/* 707 */       setSuite(suiteName);
/* 708 */       runSuite();
/*     */     }
/*     */   }
/*     */   
/*     */   private void start(Test test) {
/* 713 */     SwingUtilities.invokeLater(
/* 714 */       new Runnable() { private final Test val$test;
/*     */         
/* 716 */         public void run() { int total = this.val$test.countTestCases();
/* 717 */           TestRunner.this.fProgressIndicator.start(total);
/* 718 */           TestRunner.this.fCounterPanel.setTotal(total);
/*     */         }
/*     */       });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void synchUI()
/*     */   {
/*     */     try
/*     */     {
/* 729 */       SwingUtilities.invokeAndWait(
/* 730 */         new Runnable()
/*     */         {
/*     */           public void run() {}
/*     */         });
/*     */     }
/*     */     catch (Exception localException) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void terminate()
/*     */   {
/* 743 */     this.fFrame.dispose();
/*     */     try {
/* 745 */       saveHistory();
/*     */     } catch (java.io.IOException e) {
/* 747 */       System.out.println("Couldn't save test run history");
/*     */     }
/* 749 */     System.exit(0);
/*     */   }
/*     */   
/*     */   public void textChanged() {
/* 753 */     this.fRun.setEnabled(getSuiteText().length() > 0);
/* 754 */     clearStatus();
/*     */   }
/*     */   
/*     */   protected void clearStatus() {
/* 758 */     this.fStatusLine.clear();
/*     */   }
/*     */   
/*     */   public static javax.swing.Icon getIconResource(Class clazz, String name) {
/* 762 */     java.net.URL url = clazz.getResource(name);
/* 763 */     if (url == null) {
/* 764 */       System.err.println("Warning: could not load \"" + name + "\" icon");
/* 765 */       return null;
/*     */     }
/* 767 */     return new javax.swing.ImageIcon(url);
/*     */   }
/*     */   
/*     */   private void about() {
/* 771 */     AboutDialog about = new AboutDialog(this.fFrame);
/* 772 */     about.show();
/*     */   }
/*     */ }


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp5\Exp5.zip!\Exp5\lib\junit.jar!\junit\swingui\TestRunner.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */