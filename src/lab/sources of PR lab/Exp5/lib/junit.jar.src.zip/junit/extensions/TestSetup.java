/*    */ package junit.extensions;
/*    */ 
/*    */ import junit.framework.Protectable;
/*    */ import junit.framework.Test;
/*    */ import junit.framework.TestResult;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TestSetup
/*    */   extends TestDecorator
/*    */ {
/* 13 */   public TestSetup(Test test) { super(test); }
/*    */   
/*    */   public void run(TestResult result) {
/* 16 */     Protectable p = new Protectable() { private final TestResult val$result;
/*    */       
/* 18 */       public void protect() throws Exception { TestSetup.this.setUp();
/* 19 */         TestSetup.this.basicRun(this.val$result);
/* 20 */         TestSetup.this.tearDown();
/*    */       }
/* 22 */     };
/* 23 */     result.runProtected(this, p);
/*    */   }
/*    */   
/*    */   protected void setUp()
/*    */     throws Exception
/*    */   {}
/*    */   
/*    */   protected void tearDown()
/*    */     throws Exception
/*    */   {}
/*    */ }


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp5\Exp5.zip!\Exp5\lib\junit.jar!\junit\extensions\TestSetup.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */