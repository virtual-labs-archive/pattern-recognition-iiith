/*    */ package junit.extensions;
/*    */ 
/*    */ import junit.framework.Assert;
/*    */ import junit.framework.TestCase;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExceptionTestCase
/*    */   extends TestCase
/*    */ {
/*    */   Class fExpected;
/*    */   
/*    */   public ExceptionTestCase(String name, Class exception)
/*    */   {
/* 27 */     super(name);
/* 28 */     this.fExpected = exception;
/*    */   }
/*    */   
/*    */   protected void runTest()
/*    */     throws Throwable
/*    */   {
/*    */     try
/*    */     {
/* 36 */       super.runTest();
/*    */     }
/*    */     catch (Exception e) {
/* 39 */       if (this.fExpected.isAssignableFrom(e.getClass())) {
/* 40 */         return;
/*    */       }
/* 42 */       throw e;
/*    */     }
/* 44 */     Assert.fail("Expected exception " + this.fExpected);
/*    */   }
/*    */ }


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp5\Exp5.zip!\Exp5\lib\junit.jar!\junit\extensions\ExceptionTestCase.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */