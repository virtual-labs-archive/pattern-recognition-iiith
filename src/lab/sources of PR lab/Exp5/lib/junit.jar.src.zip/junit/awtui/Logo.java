/*    */ package junit.awtui;
/*    */ 
/*    */ import java.awt.Graphics;
/*    */ import java.awt.Image;
/*    */ import java.awt.MediaTracker;
/*    */ 
/*    */ public class Logo extends java.awt.Canvas
/*    */ {
/*    */   private Image fImage;
/*    */   private int fWidth;
/*    */   private int fHeight;
/*    */   
/*    */   public Logo()
/*    */   {
/* 15 */     this.fImage = loadImage("logo.gif");
/* 16 */     MediaTracker tracker = new MediaTracker(this);
/* 17 */     tracker.addImage(this.fImage, 0);
/*    */     try {
/* 19 */       tracker.waitForAll();
/*    */     }
/*    */     catch (Exception localException) {}
/*    */     
/* 23 */     if (this.fImage != null) {
/* 24 */       this.fWidth = this.fImage.getWidth(this);
/* 25 */       this.fHeight = this.fImage.getHeight(this);
/*    */     } else {
/* 27 */       this.fWidth = 20;
/* 28 */       this.fHeight = 20;
/*    */     }
/* 30 */     setSize(this.fWidth, this.fHeight);
/*    */   }
/*    */   
/*    */   public Image loadImage(String name) {
/* 34 */     java.awt.Toolkit toolkit = java.awt.Toolkit.getDefaultToolkit();
/*    */     try {
/* 36 */       java.net.URL url = junit.runner.BaseTestRunner.class.getResource(name);
/* 37 */       return toolkit.createImage((java.awt.image.ImageProducer)url.getContent());
/*    */     }
/*    */     catch (Exception localException) {}
/* 40 */     return null;
/*    */   }
/*    */   
/*    */   public void paint(Graphics g) {
/* 44 */     paintBackground(g);
/* 45 */     if (this.fImage != null)
/* 46 */       g.drawImage(this.fImage, 0, 0, this.fWidth, this.fHeight, this);
/*    */   }
/*    */   
/*    */   public void paintBackground(Graphics g) {
/* 50 */     g.setColor(java.awt.SystemColor.control);
/* 51 */     g.fillRect(0, 0, getBounds().width, getBounds().height);
/*    */   }
/*    */ }


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp5\Exp5.zip!\Exp5\lib\junit.jar!\junit\awtui\Logo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */