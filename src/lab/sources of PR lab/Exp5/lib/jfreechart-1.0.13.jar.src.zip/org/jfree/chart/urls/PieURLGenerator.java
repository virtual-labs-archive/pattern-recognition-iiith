package org.jfree.chart.urls;

import org.jfree.data.general.PieDataset;

public abstract interface PieURLGenerator
{
  public abstract String generateURL(PieDataset paramPieDataset, Comparable paramComparable, int paramInt);
}


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp5\Exp5.zip!\Exp5\lib\jfreechart-1.0.13.jar!\org\jfree\chart\urls\PieURLGenerator.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       0.7.1
 */