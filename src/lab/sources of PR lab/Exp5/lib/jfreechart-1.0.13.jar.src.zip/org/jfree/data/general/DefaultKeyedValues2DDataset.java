package org.jfree.data.general;

import java.io.Serializable;
import org.jfree.data.category.DefaultCategoryDataset;

public class DefaultKeyedValues2DDataset
  extends DefaultCategoryDataset
  implements KeyedValues2DDataset, Serializable
{
  private static final long serialVersionUID = 4288210771905990424L;
}


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp5\Exp5.zip!\Exp5\lib\jfreechart-1.0.13.jar!\org\jfree\data\general\DefaultKeyedValues2DDataset.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       0.7.1
 */