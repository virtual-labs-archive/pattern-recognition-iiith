package org.jfree.chart.block;

import org.jfree.chart.entity.EntityCollection;

public abstract interface EntityBlockResult
{
  public abstract EntityCollection getEntityCollection();
}


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp5\Exp5.zip!\Exp5\lib\jfreechart-1.0.13.jar!\org\jfree\chart\block\EntityBlockResult.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       0.7.1
 */