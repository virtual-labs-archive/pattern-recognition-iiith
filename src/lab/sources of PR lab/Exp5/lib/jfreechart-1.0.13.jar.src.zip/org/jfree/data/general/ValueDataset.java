package org.jfree.data.general;

import org.jfree.data.Value;

public abstract interface ValueDataset
  extends Value, Dataset
{}


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp5\Exp5.zip!\Exp5\lib\jfreechart-1.0.13.jar!\org\jfree\data\general\ValueDataset.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       0.7.1
 */