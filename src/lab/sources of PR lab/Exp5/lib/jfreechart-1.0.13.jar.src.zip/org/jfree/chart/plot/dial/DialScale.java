package org.jfree.chart.plot.dial;

public abstract interface DialScale
  extends DialLayer
{
  public abstract double valueToAngle(double paramDouble);
  
  public abstract double angleToValue(double paramDouble);
}


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp5\Exp5.zip!\Exp5\lib\jfreechart-1.0.13.jar!\org\jfree\chart\plot\dial\DialScale.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       0.7.1
 */