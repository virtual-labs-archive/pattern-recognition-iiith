/*     */ package org.jfree.chart.block;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Paint;
/*     */ import java.awt.Shape;
/*     */ import java.awt.geom.Point2D;
/*     */ import java.awt.geom.Rectangle2D;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import org.jfree.chart.entity.ChartEntity;
/*     */ import org.jfree.chart.entity.StandardEntityCollection;
/*     */ import org.jfree.io.SerialUtilities;
/*     */ import org.jfree.text.TextBlock;
/*     */ import org.jfree.text.TextBlockAnchor;
/*     */ import org.jfree.text.TextUtilities;
/*     */ import org.jfree.ui.RectangleAnchor;
/*     */ import org.jfree.ui.Size2D;
/*     */ import org.jfree.util.ObjectUtilities;
/*     */ import org.jfree.util.PaintUtilities;
/*     */ import org.jfree.util.PublicCloneable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LabelBlock
/*     */   extends AbstractBlock
/*     */   implements Block, PublicCloneable
/*     */ {
/*     */   static final long serialVersionUID = 249626098864178017L;
/*     */   private String text;
/*     */   private TextBlock label;
/*     */   private Font font;
/*     */   private String toolTipText;
/*     */   private String urlText;
/* 104 */   public static final Paint DEFAULT_PAINT = Color.black;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private transient Paint paint;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private TextBlockAnchor contentAlignmentPoint;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private RectangleAnchor textAnchor;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public LabelBlock(String label)
/*     */   {
/* 129 */     this(label, new Font("SansSerif", 0, 10), DEFAULT_PAINT);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public LabelBlock(String text, Font font)
/*     */   {
/* 139 */     this(text, font, DEFAULT_PAINT);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public LabelBlock(String text, Font font, Paint paint)
/*     */   {
/* 150 */     this.text = text;
/* 151 */     this.paint = paint;
/* 152 */     this.label = TextUtilities.createTextBlock(text, font, this.paint);
/* 153 */     this.font = font;
/* 154 */     this.toolTipText = null;
/* 155 */     this.urlText = null;
/* 156 */     this.contentAlignmentPoint = TextBlockAnchor.CENTER;
/* 157 */     this.textAnchor = RectangleAnchor.CENTER;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Font getFont()
/*     */   {
/* 168 */     return this.font;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFont(Font font)
/*     */   {
/* 179 */     if (font == null) {
/* 180 */       throw new IllegalArgumentException("Null 'font' argument.");
/*     */     }
/* 182 */     this.font = font;
/* 183 */     this.label = TextUtilities.createTextBlock(this.text, font, this.paint);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Paint getPaint()
/*     */   {
/* 194 */     return this.paint;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPaint(Paint paint)
/*     */   {
/* 205 */     if (paint == null) {
/* 206 */       throw new IllegalArgumentException("Null 'paint' argument.");
/*     */     }
/* 208 */     this.paint = paint;
/* 209 */     this.label = TextUtilities.createTextBlock(this.text, this.font, this.paint);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getToolTipText()
/*     */   {
/* 221 */     return this.toolTipText;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setToolTipText(String text)
/*     */   {
/* 232 */     this.toolTipText = text;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getURLText()
/*     */   {
/* 243 */     return this.urlText;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setURLText(String text)
/*     */   {
/* 254 */     this.urlText = text;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TextBlockAnchor getContentAlignmentPoint()
/*     */   {
/* 265 */     return this.contentAlignmentPoint;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setContentAlignmentPoint(TextBlockAnchor anchor)
/*     */   {
/* 277 */     if (anchor == null) {
/* 278 */       throw new IllegalArgumentException("Null 'anchor' argument.");
/*     */     }
/* 280 */     this.contentAlignmentPoint = anchor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RectangleAnchor getTextAnchor()
/*     */   {
/* 291 */     return this.textAnchor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTextAnchor(RectangleAnchor anchor)
/*     */   {
/* 302 */     this.textAnchor = anchor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Size2D arrange(Graphics2D g2, RectangleConstraint constraint)
/*     */   {
/* 315 */     g2.setFont(this.font);
/* 316 */     Size2D s = this.label.calculateDimensions(g2);
/* 317 */     return new Size2D(calculateTotalWidth(s.getWidth()), calculateTotalHeight(s.getHeight()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void draw(Graphics2D g2, Rectangle2D area)
/*     */   {
/* 328 */     draw(g2, area, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object draw(Graphics2D g2, Rectangle2D area, Object params)
/*     */   {
/* 341 */     area = trimMargin(area);
/* 342 */     drawBorder(g2, area);
/* 343 */     area = trimBorder(area);
/* 344 */     area = trimPadding(area);
/*     */     
/*     */ 
/* 347 */     EntityBlockParams ebp = null;
/* 348 */     StandardEntityCollection sec = null;
/* 349 */     Shape entityArea = null;
/* 350 */     if ((params instanceof EntityBlockParams)) {
/* 351 */       ebp = (EntityBlockParams)params;
/* 352 */       if (ebp.getGenerateEntities()) {
/* 353 */         sec = new StandardEntityCollection();
/* 354 */         entityArea = (Shape)area.clone();
/*     */       }
/*     */     }
/* 357 */     g2.setPaint(this.paint);
/* 358 */     g2.setFont(this.font);
/* 359 */     Point2D pt = RectangleAnchor.coordinates(area, this.textAnchor);
/* 360 */     this.label.draw(g2, (float)pt.getX(), (float)pt.getY(), this.contentAlignmentPoint);
/*     */     
/* 362 */     BlockResult result = null;
/* 363 */     if ((ebp != null) && (sec != null) && (
/* 364 */       (this.toolTipText != null) || (this.urlText != null))) {
/* 365 */       ChartEntity entity = new ChartEntity(entityArea, this.toolTipText, this.urlText);
/*     */       
/* 367 */       sec.add(entity);
/* 368 */       result = new BlockResult();
/* 369 */       result.setEntityCollection(sec);
/*     */     }
/*     */     
/* 372 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 384 */     if (!(obj instanceof LabelBlock)) {
/* 385 */       return false;
/*     */     }
/* 387 */     LabelBlock that = (LabelBlock)obj;
/* 388 */     if (!this.text.equals(that.text)) {
/* 389 */       return false;
/*     */     }
/* 391 */     if (!this.font.equals(that.font)) {
/* 392 */       return false;
/*     */     }
/* 394 */     if (!PaintUtilities.equal(this.paint, that.paint)) {
/* 395 */       return false;
/*     */     }
/* 397 */     if (!ObjectUtilities.equal(this.toolTipText, that.toolTipText)) {
/* 398 */       return false;
/*     */     }
/* 400 */     if (!ObjectUtilities.equal(this.urlText, that.urlText)) {
/* 401 */       return false;
/*     */     }
/* 403 */     if (!this.contentAlignmentPoint.equals(that.contentAlignmentPoint)) {
/* 404 */       return false;
/*     */     }
/* 406 */     if (!this.textAnchor.equals(that.textAnchor)) {
/* 407 */       return false;
/*     */     }
/* 409 */     return super.equals(obj);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object clone()
/*     */     throws CloneNotSupportedException
/*     */   {
/* 420 */     return super.clone();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void writeObject(ObjectOutputStream stream)
/*     */     throws IOException
/*     */   {
/* 431 */     stream.defaultWriteObject();
/* 432 */     SerialUtilities.writePaint(this.paint, stream);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void readObject(ObjectInputStream stream)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 445 */     stream.defaultReadObject();
/* 446 */     this.paint = SerialUtilities.readPaint(stream);
/*     */   }
/*     */ }


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp5\Exp5.zip!\Exp5\lib\jfreechart-1.0.13.jar!\org\jfree\chart\block\LabelBlock.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       0.7.1
 */