/*    */ package Jama.util;
/*    */ 
/*    */ 
/*    */ public class Maths
/*    */ {
/*    */   public static double hypot(double paramDouble1, double paramDouble2)
/*    */   {
/*    */     double d;
/*  9 */     if (Math.abs(paramDouble1) > Math.abs(paramDouble2)) {
/* 10 */       d = paramDouble2 / paramDouble1;
/* 11 */       d = Math.abs(paramDouble1) * Math.sqrt(1.0D + d * d);
/* 12 */     } else if (paramDouble2 != 0.0D) {
/* 13 */       d = paramDouble1 / paramDouble2;
/* 14 */       d = Math.abs(paramDouble2) * Math.sqrt(1.0D + d * d);
/*    */     } else {
/* 16 */       d = 0.0D;
/*    */     }
/* 18 */     return d;
/*    */   }
/*    */ }


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp5\Exp5.zip!\Exp5\lib\Jama-1.0.2.jar!\Jama\util\Maths.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */