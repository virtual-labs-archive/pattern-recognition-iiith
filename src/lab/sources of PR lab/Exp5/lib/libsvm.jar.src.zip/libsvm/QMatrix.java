package libsvm;

abstract class QMatrix
{
  abstract float[] get_Q(int paramInt1, int paramInt2);
  
  abstract double[] get_QD();
  
  abstract void swap_index(int paramInt1, int paramInt2);
}


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp5\Exp5.zip!\Exp5\lib\libsvm.jar!\libsvm\QMatrix.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */