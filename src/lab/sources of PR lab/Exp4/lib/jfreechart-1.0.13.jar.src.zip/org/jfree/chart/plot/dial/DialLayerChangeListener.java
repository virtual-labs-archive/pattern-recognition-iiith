package org.jfree.chart.plot.dial;

import java.util.EventListener;

public abstract interface DialLayerChangeListener
  extends EventListener
{
  public abstract void dialLayerChanged(DialLayerChangeEvent paramDialLayerChangeEvent);
}


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp10\Exp10.zip!\Exp10\lib\jfreechart-1.0.13.jar!\org\jfree\chart\plot\dial\DialLayerChangeListener.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       0.7.1
 */