package org.jfree.chart.editor;

import org.jfree.chart.JFreeChart;

public abstract interface ChartEditor
{
  public abstract void updateChart(JFreeChart paramJFreeChart);
}


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp10\Exp10.zip!\Exp10\lib\jfreechart-1.0.13.jar!\org\jfree\chart\editor\ChartEditor.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       0.7.1
 */