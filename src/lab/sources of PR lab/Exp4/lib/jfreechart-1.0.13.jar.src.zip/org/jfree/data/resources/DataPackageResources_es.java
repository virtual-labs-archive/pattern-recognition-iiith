/*    */ package org.jfree.data.resources;
/*    */ 
/*    */ import java.util.ListResourceBundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DataPackageResources_es
/*    */   extends ListResourceBundle
/*    */ {
/*    */   public Object[][] getContents()
/*    */   {
/* 58 */     return CONTENTS;
/*    */   }
/*    */   
/*    */ 
/* 62 */   private static final Object[][] CONTENTS = { { "series.default-prefix", "Series" }, { "categories.default-prefix", "Categor?a" } };
/*    */ }


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp10\Exp10.zip!\Exp10\lib\jfreechart-1.0.13.jar!\org\jfree\data\resources\DataPackageResources_es.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       0.7.1
 */