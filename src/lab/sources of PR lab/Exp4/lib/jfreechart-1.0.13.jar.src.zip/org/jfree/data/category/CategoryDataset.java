package org.jfree.data.category;

import org.jfree.data.KeyedValues2D;
import org.jfree.data.general.Dataset;

public abstract interface CategoryDataset
  extends KeyedValues2D, Dataset
{}


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp10\Exp10.zip!\Exp10\lib\jfreechart-1.0.13.jar!\org\jfree\data\category\CategoryDataset.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       0.7.1
 */