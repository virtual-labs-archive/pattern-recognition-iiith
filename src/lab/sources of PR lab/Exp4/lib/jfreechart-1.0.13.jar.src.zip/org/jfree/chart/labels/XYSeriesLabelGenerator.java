package org.jfree.chart.labels;

import org.jfree.data.xy.XYDataset;

public abstract interface XYSeriesLabelGenerator
{
  public abstract String generateLabel(XYDataset paramXYDataset, int paramInt);
}


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp10\Exp10.zip!\Exp10\lib\jfreechart-1.0.13.jar!\org\jfree\chart\labels\XYSeriesLabelGenerator.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       0.7.1
 */