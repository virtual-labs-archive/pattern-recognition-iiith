package org.jfree.data.general;

import java.io.Serializable;
import org.jfree.data.category.DefaultCategoryDataset;

public class DefaultKeyedValues2DDataset
  extends DefaultCategoryDataset
  implements KeyedValues2DDataset, Serializable
{
  private static final long serialVersionUID = 4288210771905990424L;
}


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp10\Exp10.zip!\Exp10\lib\jfreechart-1.0.13.jar!\org\jfree\data\general\DefaultKeyedValues2DDataset.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       0.7.1
 */