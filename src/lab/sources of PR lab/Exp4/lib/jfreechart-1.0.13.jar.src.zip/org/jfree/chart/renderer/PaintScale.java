package org.jfree.chart.renderer;

import java.awt.Paint;

public abstract interface PaintScale
{
  public abstract double getLowerBound();
  
  public abstract double getUpperBound();
  
  public abstract Paint getPaint(double paramDouble);
}


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp10\Exp10.zip!\Exp10\lib\jfreechart-1.0.13.jar!\org\jfree\chart\renderer\PaintScale.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       0.7.1
 */