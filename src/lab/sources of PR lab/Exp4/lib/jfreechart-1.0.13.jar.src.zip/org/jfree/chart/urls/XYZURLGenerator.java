package org.jfree.chart.urls;

import org.jfree.data.xy.XYZDataset;

public abstract interface XYZURLGenerator
  extends XYURLGenerator
{
  public abstract String generateURL(XYZDataset paramXYZDataset, int paramInt1, int paramInt2);
}


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp10\Exp10.zip!\Exp10\lib\jfreechart-1.0.13.jar!\org\jfree\chart\urls\XYZURLGenerator.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       0.7.1
 */