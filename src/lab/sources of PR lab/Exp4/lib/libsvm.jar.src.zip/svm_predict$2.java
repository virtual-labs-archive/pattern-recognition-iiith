/*    */ import java.io.PrintStream;
/*    */ import libsvm.svm_print_interface;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class svm_predict$2
/*    */   implements svm_print_interface
/*    */ {
/*    */   public void print(String paramString)
/*    */   {
/* 15 */     System.out.print(paramString);
/*    */   }
/*    */ }


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp10\Exp10.zip!\Exp10\lib\libsvm.jar!\svm_predict$2.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */