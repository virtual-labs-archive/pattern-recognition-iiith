/*     */ package libsvm;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class Kernel
/*     */   extends QMatrix
/*     */ {
/*     */   private svm_node[][] x;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final double[] x_square;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final int kernel_type;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final int degree;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final double gamma;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final double coef0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   abstract float[] get_Q(int paramInt1, int paramInt2);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   abstract double[] get_QD();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void swap_index(int paramInt1, int paramInt2)
/*     */   {
/* 151 */     svm_node[] arrayOfsvm_node = this.x[paramInt1];this.x[paramInt1] = this.x[paramInt2];this.x[paramInt2] = arrayOfsvm_node;
/* 152 */     if (this.x_square != null) { double d = this.x_square[paramInt1];this.x_square[paramInt1] = this.x_square[paramInt2];this.x_square[paramInt2] = d;
/*     */     }
/*     */   }
/*     */   
/*     */   private static double powi(double paramDouble, int paramInt) {
/* 157 */     double d1 = paramDouble;double d2 = 1.0D;
/*     */     
/* 159 */     for (int i = paramInt; i > 0; i /= 2)
/*     */     {
/* 161 */       if (i % 2 == 1) d2 *= d1;
/* 162 */       d1 *= d1;
/*     */     }
/* 164 */     return d2;
/*     */   }
/*     */   
/*     */   double kernel_function(int paramInt1, int paramInt2)
/*     */   {
/* 169 */     switch (this.kernel_type)
/*     */     {
/*     */     case 0: 
/* 172 */       return dot(this.x[paramInt1], this.x[paramInt2]);
/*     */     case 1: 
/* 174 */       return powi(this.gamma * dot(this.x[paramInt1], this.x[paramInt2]) + this.coef0, this.degree);
/*     */     case 2: 
/* 176 */       return Math.exp(-this.gamma * (this.x_square[paramInt1] + this.x_square[paramInt2] - 2.0D * dot(this.x[paramInt1], this.x[paramInt2])));
/*     */     case 3: 
/* 178 */       return Math.tanh(this.gamma * dot(this.x[paramInt1], this.x[paramInt2]) + this.coef0);
/*     */     case 4: 
/* 180 */       return this.x[paramInt1][((int)this.x[paramInt2][0].value)].value;
/*     */     }
/* 182 */     return 0.0D;
/*     */   }
/*     */   
/*     */ 
/*     */   Kernel(int paramInt, svm_node[][] paramArrayOfsvm_node, svm_parameter paramsvm_parameter)
/*     */   {
/* 188 */     this.kernel_type = paramsvm_parameter.kernel_type;
/* 189 */     this.degree = paramsvm_parameter.degree;
/* 190 */     this.gamma = paramsvm_parameter.gamma;
/* 191 */     this.coef0 = paramsvm_parameter.coef0;
/*     */     
/* 193 */     this.x = ((svm_node[][])paramArrayOfsvm_node.clone());
/*     */     
/* 195 */     if (this.kernel_type == 2)
/*     */     {
/* 197 */       this.x_square = new double[paramInt];
/* 198 */       for (int i = 0; i < paramInt; i++)
/* 199 */         this.x_square[i] = dot(this.x[i], this.x[i]);
/*     */     } else {
/* 201 */       this.x_square = null;
/*     */     }
/*     */   }
/*     */   
/*     */   static double dot(svm_node[] paramArrayOfsvm_node1, svm_node[] paramArrayOfsvm_node2) {
/* 206 */     double d = 0.0D;
/* 207 */     int i = paramArrayOfsvm_node1.length;
/* 208 */     int j = paramArrayOfsvm_node2.length;
/* 209 */     int k = 0;
/* 210 */     int m = 0;
/* 211 */     while ((k < i) && (m < j))
/*     */     {
/* 213 */       if (paramArrayOfsvm_node1[k].index == paramArrayOfsvm_node2[m].index) {
/* 214 */         d += paramArrayOfsvm_node1[(k++)].value * paramArrayOfsvm_node2[(m++)].value;
/*     */ 
/*     */       }
/* 217 */       else if (paramArrayOfsvm_node1[k].index > paramArrayOfsvm_node2[m].index) {
/* 218 */         m++;
/*     */       } else {
/* 220 */         k++;
/*     */       }
/*     */     }
/* 223 */     return d;
/*     */   }
/*     */   
/*     */ 
/*     */   static double k_function(svm_node[] paramArrayOfsvm_node1, svm_node[] paramArrayOfsvm_node2, svm_parameter paramsvm_parameter)
/*     */   {
/* 229 */     switch (paramsvm_parameter.kernel_type)
/*     */     {
/*     */     case 0: 
/* 232 */       return dot(paramArrayOfsvm_node1, paramArrayOfsvm_node2);
/*     */     case 1: 
/* 234 */       return powi(paramsvm_parameter.gamma * dot(paramArrayOfsvm_node1, paramArrayOfsvm_node2) + paramsvm_parameter.coef0, paramsvm_parameter.degree);
/*     */     
/*     */     case 2: 
/* 237 */       double d1 = 0.0D;
/* 238 */       int i = paramArrayOfsvm_node1.length;
/* 239 */       int j = paramArrayOfsvm_node2.length;
/* 240 */       int k = 0;
/* 241 */       int m = 0;
/* 242 */       while ((k < i) && (m < j))
/*     */       {
/* 244 */         if (paramArrayOfsvm_node1[k].index == paramArrayOfsvm_node2[m].index)
/*     */         {
/* 246 */           double d2 = paramArrayOfsvm_node1[(k++)].value - paramArrayOfsvm_node2[(m++)].value;
/* 247 */           d1 += d2 * d2;
/*     */         }
/* 249 */         else if (paramArrayOfsvm_node1[k].index > paramArrayOfsvm_node2[m].index)
/*     */         {
/* 251 */           d1 += paramArrayOfsvm_node2[m].value * paramArrayOfsvm_node2[m].value;
/* 252 */           m++;
/*     */         }
/*     */         else
/*     */         {
/* 256 */           d1 += paramArrayOfsvm_node1[k].value * paramArrayOfsvm_node1[k].value;
/* 257 */           k++;
/*     */         }
/*     */       }
/*     */       
/* 261 */       while (k < i)
/*     */       {
/* 263 */         d1 += paramArrayOfsvm_node1[k].value * paramArrayOfsvm_node1[k].value;
/* 264 */         k++;
/*     */       }
/*     */       
/* 267 */       while (m < j)
/*     */       {
/* 269 */         d1 += paramArrayOfsvm_node2[m].value * paramArrayOfsvm_node2[m].value;
/* 270 */         m++;
/*     */       }
/*     */       
/* 273 */       return Math.exp(-paramsvm_parameter.gamma * d1);
/*     */     
/*     */     case 3: 
/* 276 */       return Math.tanh(paramsvm_parameter.gamma * dot(paramArrayOfsvm_node1, paramArrayOfsvm_node2) + paramsvm_parameter.coef0);
/*     */     case 4: 
/* 278 */       return paramArrayOfsvm_node1[((int)paramArrayOfsvm_node2[0].value)].value;
/*     */     }
/* 280 */     return 0.0D;
/*     */   }
/*     */ }


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp10\Exp10.zip!\Exp10\lib\libsvm.jar!\libsvm\Kernel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */