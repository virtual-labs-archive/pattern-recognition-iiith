/*      */ package libsvm;
/*      */ 
/*      */ import java.io.BufferedOutputStream;
/*      */ import java.io.BufferedReader;
/*      */ import java.io.DataOutputStream;
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.FileReader;
/*      */ import java.io.IOException;
/*      */ import java.io.PrintStream;
/*      */ import java.util.Random;
/*      */ import java.util.StringTokenizer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class svm
/*      */ {
/*      */   public static final int LIBSVM_VERSION = 317;
/* 1297 */   public static final Random rand = new Random();
/*      */   
/* 1299 */   private static svm_print_interface svm_print_stdout = new svm_print_interface()
/*      */   {
/*      */     public void print(String paramAnonymousString)
/*      */     {
/* 1303 */       System.out.print(paramAnonymousString);
/* 1304 */       System.out.flush();
/*      */     }
/*      */   };
/*      */   
/* 1308 */   private static svm_print_interface svm_print_string = svm_print_stdout;
/*      */   
/*      */   static void info(String paramString)
/*      */   {
/* 1312 */     svm_print_string.print(paramString);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static void solve_c_svc(svm_problem paramsvm_problem, svm_parameter paramsvm_parameter, double[] paramArrayOfDouble, Solver.SolutionInfo paramSolutionInfo, double paramDouble1, double paramDouble2)
/*      */   {
/* 1319 */     int i = paramsvm_problem.l;
/* 1320 */     double[] arrayOfDouble = new double[i];
/* 1321 */     byte[] arrayOfByte = new byte[i];
/*      */     
/*      */ 
/*      */ 
/* 1325 */     for (int j = 0; j < i; j++)
/*      */     {
/* 1327 */       paramArrayOfDouble[j] = 0.0D;
/* 1328 */       arrayOfDouble[j] = -1.0D;
/* 1329 */       if (paramsvm_problem.y[j] > 0.0D) arrayOfByte[j] = 1; else { arrayOfByte[j] = -1;
/*      */       }
/*      */     }
/* 1332 */     Solver localSolver = new Solver();
/* 1333 */     localSolver.Solve(i, new SVC_Q(paramsvm_problem, paramsvm_parameter, arrayOfByte), arrayOfDouble, arrayOfByte, paramArrayOfDouble, paramDouble1, paramDouble2, paramsvm_parameter.eps, paramSolutionInfo, paramsvm_parameter.shrinking);
/*      */     
/*      */ 
/* 1336 */     double d = 0.0D;
/* 1337 */     for (j = 0; j < i; j++) {
/* 1338 */       d += paramArrayOfDouble[j];
/*      */     }
/* 1340 */     if (paramDouble1 == paramDouble2) {
/* 1341 */       info("nu = " + d / (paramDouble1 * paramsvm_problem.l) + "\n");
/*      */     }
/* 1343 */     for (j = 0; j < i; j++) {
/* 1344 */       paramArrayOfDouble[j] *= arrayOfByte[j];
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private static void solve_nu_svc(svm_problem paramsvm_problem, svm_parameter paramsvm_parameter, double[] paramArrayOfDouble, Solver.SolutionInfo paramSolutionInfo)
/*      */   {
/* 1351 */     int j = paramsvm_problem.l;
/* 1352 */     double d1 = paramsvm_parameter.nu;
/*      */     
/* 1354 */     byte[] arrayOfByte = new byte[j];
/*      */     
/* 1356 */     for (int i = 0; i < j; i++) {
/* 1357 */       if (paramsvm_problem.y[i] > 0.0D) {
/* 1358 */         arrayOfByte[i] = 1;
/*      */       } else
/* 1360 */         arrayOfByte[i] = -1;
/*      */     }
/* 1362 */     double d2 = d1 * j / 2.0D;
/* 1363 */     double d3 = d1 * j / 2.0D;
/*      */     
/* 1365 */     for (i = 0; i < j; i++) {
/* 1366 */       if (arrayOfByte[i] == 1)
/*      */       {
/* 1368 */         paramArrayOfDouble[i] = Math.min(1.0D, d2);
/* 1369 */         d2 -= paramArrayOfDouble[i];
/*      */       }
/*      */       else
/*      */       {
/* 1373 */         paramArrayOfDouble[i] = Math.min(1.0D, d3);
/* 1374 */         d3 -= paramArrayOfDouble[i];
/*      */       }
/*      */     }
/* 1377 */     double[] arrayOfDouble = new double[j];
/*      */     
/* 1379 */     for (i = 0; i < j; i++) {
/* 1380 */       arrayOfDouble[i] = 0.0D;
/*      */     }
/* 1382 */     Solver_NU localSolver_NU = new Solver_NU();
/* 1383 */     localSolver_NU.Solve(j, new SVC_Q(paramsvm_problem, paramsvm_parameter, arrayOfByte), arrayOfDouble, arrayOfByte, paramArrayOfDouble, 1.0D, 1.0D, paramsvm_parameter.eps, paramSolutionInfo, paramsvm_parameter.shrinking);
/*      */     
/* 1385 */     double d4 = paramSolutionInfo.r;
/*      */     
/* 1387 */     info("C = " + 1.0D / d4 + "\n");
/*      */     
/* 1389 */     for (i = 0; i < j; i++) {
/* 1390 */       paramArrayOfDouble[i] *= arrayOfByte[i] / d4;
/*      */     }
/* 1392 */     paramSolutionInfo.rho /= d4;
/* 1393 */     paramSolutionInfo.obj /= d4 * d4;
/* 1394 */     paramSolutionInfo.upper_bound_p = (1.0D / d4);
/* 1395 */     paramSolutionInfo.upper_bound_n = (1.0D / d4);
/*      */   }
/*      */   
/*      */ 
/*      */   private static void solve_one_class(svm_problem paramsvm_problem, svm_parameter paramsvm_parameter, double[] paramArrayOfDouble, Solver.SolutionInfo paramSolutionInfo)
/*      */   {
/* 1401 */     int i = paramsvm_problem.l;
/* 1402 */     double[] arrayOfDouble = new double[i];
/* 1403 */     byte[] arrayOfByte = new byte[i];
/*      */     
/*      */ 
/* 1406 */     int k = (int)(paramsvm_parameter.nu * paramsvm_problem.l);
/*      */     
/* 1408 */     for (int j = 0; j < k; j++)
/* 1409 */       paramArrayOfDouble[j] = 1.0D;
/* 1410 */     if (k < paramsvm_problem.l)
/* 1411 */       paramArrayOfDouble[k] = (paramsvm_parameter.nu * paramsvm_problem.l - k);
/* 1412 */     for (j = k + 1; j < i; j++) {
/* 1413 */       paramArrayOfDouble[j] = 0.0D;
/*      */     }
/* 1415 */     for (j = 0; j < i; j++)
/*      */     {
/* 1417 */       arrayOfDouble[j] = 0.0D;
/* 1418 */       arrayOfByte[j] = 1;
/*      */     }
/*      */     
/* 1421 */     Solver localSolver = new Solver();
/* 1422 */     localSolver.Solve(i, new ONE_CLASS_Q(paramsvm_problem, paramsvm_parameter), arrayOfDouble, arrayOfByte, paramArrayOfDouble, 1.0D, 1.0D, paramsvm_parameter.eps, paramSolutionInfo, paramsvm_parameter.shrinking);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static void solve_epsilon_svr(svm_problem paramsvm_problem, svm_parameter paramsvm_parameter, double[] paramArrayOfDouble, Solver.SolutionInfo paramSolutionInfo)
/*      */   {
/* 1429 */     int i = paramsvm_problem.l;
/* 1430 */     double[] arrayOfDouble1 = new double[2 * i];
/* 1431 */     double[] arrayOfDouble2 = new double[2 * i];
/* 1432 */     byte[] arrayOfByte = new byte[2 * i];
/*      */     
/*      */ 
/* 1435 */     for (int j = 0; j < i; j++)
/*      */     {
/* 1437 */       arrayOfDouble1[j] = 0.0D;
/* 1438 */       arrayOfDouble2[j] = (paramsvm_parameter.p - paramsvm_problem.y[j]);
/* 1439 */       arrayOfByte[j] = 1;
/*      */       
/* 1441 */       arrayOfDouble1[(j + i)] = 0.0D;
/* 1442 */       arrayOfDouble2[(j + i)] = (paramsvm_parameter.p + paramsvm_problem.y[j]);
/* 1443 */       arrayOfByte[(j + i)] = -1;
/*      */     }
/*      */     
/* 1446 */     Solver localSolver = new Solver();
/* 1447 */     localSolver.Solve(2 * i, new SVR_Q(paramsvm_problem, paramsvm_parameter), arrayOfDouble2, arrayOfByte, arrayOfDouble1, paramsvm_parameter.C, paramsvm_parameter.C, paramsvm_parameter.eps, paramSolutionInfo, paramsvm_parameter.shrinking);
/*      */     
/*      */ 
/* 1450 */     double d = 0.0D;
/* 1451 */     for (j = 0; j < i; j++)
/*      */     {
/* 1453 */       arrayOfDouble1[j] -= arrayOfDouble1[(j + i)];
/* 1454 */       d += Math.abs(paramArrayOfDouble[j]);
/*      */     }
/* 1456 */     info("nu = " + d / (paramsvm_parameter.C * i) + "\n");
/*      */   }
/*      */   
/*      */ 
/*      */   private static void solve_nu_svr(svm_problem paramsvm_problem, svm_parameter paramsvm_parameter, double[] paramArrayOfDouble, Solver.SolutionInfo paramSolutionInfo)
/*      */   {
/* 1462 */     int i = paramsvm_problem.l;
/* 1463 */     double d1 = paramsvm_parameter.C;
/* 1464 */     double[] arrayOfDouble1 = new double[2 * i];
/* 1465 */     double[] arrayOfDouble2 = new double[2 * i];
/* 1466 */     byte[] arrayOfByte = new byte[2 * i];
/*      */     
/*      */ 
/* 1469 */     double d2 = d1 * paramsvm_parameter.nu * i / 2.0D;
/* 1470 */     for (int j = 0; j < i; j++)
/*      */     {
/* 1472 */       arrayOfDouble1[j] = (arrayOfDouble1[(j + i)] = Math.min(d2, d1));
/* 1473 */       d2 -= arrayOfDouble1[j];
/*      */       
/* 1475 */       arrayOfDouble2[j] = (-paramsvm_problem.y[j]);
/* 1476 */       arrayOfByte[j] = 1;
/*      */       
/* 1478 */       arrayOfDouble2[(j + i)] = paramsvm_problem.y[j];
/* 1479 */       arrayOfByte[(j + i)] = -1;
/*      */     }
/*      */     
/* 1482 */     Solver_NU localSolver_NU = new Solver_NU();
/* 1483 */     localSolver_NU.Solve(2 * i, new SVR_Q(paramsvm_problem, paramsvm_parameter), arrayOfDouble2, arrayOfByte, arrayOfDouble1, d1, d1, paramsvm_parameter.eps, paramSolutionInfo, paramsvm_parameter.shrinking);
/*      */     
/*      */ 
/* 1486 */     info("epsilon = " + -paramSolutionInfo.r + "\n");
/*      */     
/* 1488 */     for (j = 0; j < i; j++) {
/* 1489 */       arrayOfDouble1[j] -= arrayOfDouble1[(j + i)];
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static decision_function svm_train_one(svm_problem paramsvm_problem, svm_parameter paramsvm_parameter, double paramDouble1, double paramDouble2)
/*      */   {
/* 1505 */     double[] arrayOfDouble = new double[paramsvm_problem.l];
/* 1506 */     Solver.SolutionInfo localSolutionInfo = new Solver.SolutionInfo();
/* 1507 */     switch (paramsvm_parameter.svm_type)
/*      */     {
/*      */     case 0: 
/* 1510 */       solve_c_svc(paramsvm_problem, paramsvm_parameter, arrayOfDouble, localSolutionInfo, paramDouble1, paramDouble2);
/* 1511 */       break;
/*      */     case 1: 
/* 1513 */       solve_nu_svc(paramsvm_problem, paramsvm_parameter, arrayOfDouble, localSolutionInfo);
/* 1514 */       break;
/*      */     case 2: 
/* 1516 */       solve_one_class(paramsvm_problem, paramsvm_parameter, arrayOfDouble, localSolutionInfo);
/* 1517 */       break;
/*      */     case 3: 
/* 1519 */       solve_epsilon_svr(paramsvm_problem, paramsvm_parameter, arrayOfDouble, localSolutionInfo);
/* 1520 */       break;
/*      */     case 4: 
/* 1522 */       solve_nu_svr(paramsvm_problem, paramsvm_parameter, arrayOfDouble, localSolutionInfo);
/*      */     }
/*      */     
/*      */     
/* 1526 */     info("obj = " + localSolutionInfo.obj + ", rho = " + localSolutionInfo.rho + "\n");
/*      */     
/*      */ 
/*      */ 
/* 1530 */     int i = 0;
/* 1531 */     int j = 0;
/* 1532 */     for (int k = 0; k < paramsvm_problem.l; k++)
/*      */     {
/* 1534 */       if (Math.abs(arrayOfDouble[k]) > 0.0D)
/*      */       {
/* 1536 */         i++;
/* 1537 */         if (paramsvm_problem.y[k] > 0.0D)
/*      */         {
/* 1539 */           if (Math.abs(arrayOfDouble[k]) >= localSolutionInfo.upper_bound_p) {
/* 1540 */             j++;
/*      */           }
/*      */           
/*      */         }
/* 1544 */         else if (Math.abs(arrayOfDouble[k]) >= localSolutionInfo.upper_bound_n) {
/* 1545 */           j++;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 1550 */     info("nSV = " + i + ", nBSV = " + j + "\n");
/*      */     
/* 1552 */     decision_function localdecision_function = new decision_function();
/* 1553 */     localdecision_function.alpha = arrayOfDouble;
/* 1554 */     localdecision_function.rho = localSolutionInfo.rho;
/* 1555 */     return localdecision_function;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private static void sigmoid_train(int paramInt, double[] paramArrayOfDouble1, double[] paramArrayOfDouble2, double[] paramArrayOfDouble3)
/*      */   {
/* 1563 */     double d3 = 0.0D;double d4 = 0.0D;
/*      */     
/*      */ 
/* 1566 */     for (int i = 0; i < paramInt; i++) {
/* 1567 */       if (paramArrayOfDouble2[i] > 0.0D) d3 += 1.0D; else
/* 1568 */         d4 += 1.0D;
/*      */     }
/* 1570 */     int j = 100;
/* 1571 */     double d5 = 1.0E-10D;
/* 1572 */     double d6 = 1.0E-12D;
/* 1573 */     double d7 = 1.0E-5D;
/* 1574 */     double d8 = (d3 + 1.0D) / (d3 + 2.0D);
/* 1575 */     double d9 = 1.0D / (d4 + 2.0D);
/* 1576 */     double[] arrayOfDouble = new double[paramInt];
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1582 */     double d1 = 0.0D;double d2 = Math.log((d4 + 1.0D) / (d3 + 1.0D));
/* 1583 */     double d28 = 0.0D;
/*      */     double d10;
/* 1585 */     for (i = 0; i < paramInt; i++)
/*      */     {
/* 1587 */       if (paramArrayOfDouble2[i] > 0.0D) arrayOfDouble[i] = d8; else
/* 1588 */         arrayOfDouble[i] = d9;
/* 1589 */       d10 = paramArrayOfDouble1[i] * d1 + d2;
/* 1590 */       if (d10 >= 0.0D) {
/* 1591 */         d28 += arrayOfDouble[i] * d10 + Math.log(1.0D + Math.exp(-d10));
/*      */       } else
/* 1593 */         d28 += (arrayOfDouble[i] - 1.0D) * d10 + Math.log(1.0D + Math.exp(d10));
/*      */     }
/* 1595 */     for (int k = 0; k < j; k++)
/*      */     {
/*      */ 
/* 1598 */       double d13 = d6;
/* 1599 */       double d14 = d6;
/* 1600 */       double d15 = 0.0D;double d16 = 0.0D;double d17 = 0.0D;
/* 1601 */       for (i = 0; i < paramInt; i++)
/*      */       {
/* 1603 */         d10 = paramArrayOfDouble1[i] * d1 + d2;
/* 1604 */         double d11; double d12; if (d10 >= 0.0D)
/*      */         {
/* 1606 */           d11 = Math.exp(-d10) / (1.0D + Math.exp(-d10));
/* 1607 */           d12 = 1.0D / (1.0D + Math.exp(-d10));
/*      */         }
/*      */         else
/*      */         {
/* 1611 */           d11 = 1.0D / (1.0D + Math.exp(d10));
/* 1612 */           d12 = Math.exp(d10) / (1.0D + Math.exp(d10));
/*      */         }
/* 1614 */         double d27 = d11 * d12;
/* 1615 */         d13 += paramArrayOfDouble1[i] * paramArrayOfDouble1[i] * d27;
/* 1616 */         d14 += d27;
/* 1617 */         d15 += paramArrayOfDouble1[i] * d27;
/* 1618 */         double d26 = arrayOfDouble[i] - d11;
/* 1619 */         d16 += paramArrayOfDouble1[i] * d26;
/* 1620 */         d17 += d26;
/*      */       }
/*      */       
/*      */ 
/* 1624 */       if ((Math.abs(d16) < d7) && (Math.abs(d17) < d7)) {
/*      */         break;
/*      */       }
/*      */       
/* 1628 */       double d18 = d13 * d14 - d15 * d15;
/* 1629 */       double d19 = -(d14 * d16 - d15 * d17) / d18;
/* 1630 */       double d20 = -(-d15 * d16 + d13 * d17) / d18;
/* 1631 */       double d21 = d16 * d19 + d17 * d20;
/*      */       
/*      */ 
/* 1634 */       double d22 = 1.0D;
/* 1635 */       while (d22 >= d5)
/*      */       {
/* 1637 */         double d23 = d1 + d22 * d19;
/* 1638 */         double d24 = d2 + d22 * d20;
/*      */         
/*      */ 
/* 1641 */         double d25 = 0.0D;
/* 1642 */         for (i = 0; i < paramInt; i++)
/*      */         {
/* 1644 */           d10 = paramArrayOfDouble1[i] * d23 + d24;
/* 1645 */           if (d10 >= 0.0D) {
/* 1646 */             d25 += arrayOfDouble[i] * d10 + Math.log(1.0D + Math.exp(-d10));
/*      */           } else {
/* 1648 */             d25 += (arrayOfDouble[i] - 1.0D) * d10 + Math.log(1.0D + Math.exp(d10));
/*      */           }
/*      */         }
/* 1651 */         if (d25 < d28 + 1.0E-4D * d22 * d21)
/*      */         {
/* 1653 */           d1 = d23;d2 = d24;d28 = d25;
/* 1654 */           break;
/*      */         }
/*      */         
/* 1657 */         d22 /= 2.0D;
/*      */       }
/*      */       
/* 1660 */       if (d22 < d5)
/*      */       {
/* 1662 */         info("Line search fails in two-class probability estimates\n");
/* 1663 */         break;
/*      */       }
/*      */     }
/*      */     
/* 1667 */     if (k >= j)
/* 1668 */       info("Reaching maximal iterations in two-class probability estimates\n");
/* 1669 */     paramArrayOfDouble3[0] = d1;paramArrayOfDouble3[1] = d2;
/*      */   }
/*      */   
/*      */   private static double sigmoid_predict(double paramDouble1, double paramDouble2, double paramDouble3)
/*      */   {
/* 1674 */     double d = paramDouble1 * paramDouble2 + paramDouble3;
/* 1675 */     if (d >= 0.0D) {
/* 1676 */       return Math.exp(-d) / (1.0D + Math.exp(-d));
/*      */     }
/* 1678 */     return 1.0D / (1.0D + Math.exp(d));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static void multiclass_probability(int paramInt, double[][] paramArrayOfDouble, double[] paramArrayOfDouble1)
/*      */   {
/* 1685 */     int k = 0;int m = Math.max(100, paramInt);
/* 1686 */     double[][] arrayOfDouble = new double[paramInt][paramInt];
/* 1687 */     double[] arrayOfDouble1 = new double[paramInt];
/* 1688 */     double d2 = 0.005D / paramInt;
/*      */     int j;
/* 1690 */     for (int i = 0; i < paramInt; i++)
/*      */     {
/* 1692 */       paramArrayOfDouble1[i] = (1.0D / paramInt);
/* 1693 */       arrayOfDouble[i][i] = 0.0D;
/* 1694 */       for (j = 0; j < i; j++)
/*      */       {
/* 1696 */         arrayOfDouble[i][i] += paramArrayOfDouble[j][i] * paramArrayOfDouble[j][i];
/* 1697 */         arrayOfDouble[i][j] = arrayOfDouble[j][i];
/*      */       }
/* 1699 */       for (j = i + 1; j < paramInt; j++)
/*      */       {
/* 1701 */         arrayOfDouble[i][i] += paramArrayOfDouble[j][i] * paramArrayOfDouble[j][i];
/* 1702 */         arrayOfDouble[i][j] = (-paramArrayOfDouble[j][i] * paramArrayOfDouble[i][j]);
/*      */       }
/*      */     }
/* 1705 */     for (k = 0; k < m; k++)
/*      */     {
/*      */ 
/* 1708 */       double d1 = 0.0D;
/* 1709 */       for (i = 0; i < paramInt; i++)
/*      */       {
/* 1711 */         arrayOfDouble1[i] = 0.0D;
/* 1712 */         for (j = 0; j < paramInt; j++)
/* 1713 */           arrayOfDouble1[i] += arrayOfDouble[i][j] * paramArrayOfDouble1[j];
/* 1714 */         d1 += paramArrayOfDouble1[i] * arrayOfDouble1[i];
/*      */       }
/* 1716 */       double d3 = 0.0D;
/* 1717 */       double d4; for (i = 0; i < paramInt; i++)
/*      */       {
/* 1719 */         d4 = Math.abs(arrayOfDouble1[i] - d1);
/* 1720 */         if (d4 > d3)
/* 1721 */           d3 = d4;
/*      */       }
/* 1723 */       if (d3 < d2)
/*      */         break;
/* 1725 */       for (i = 0; i < paramInt; i++)
/*      */       {
/* 1727 */         d4 = (-arrayOfDouble1[i] + d1) / arrayOfDouble[i][i];
/* 1728 */         paramArrayOfDouble1[i] += d4;
/* 1729 */         d1 = (d1 + d4 * (d4 * arrayOfDouble[i][i] + 2.0D * arrayOfDouble1[i])) / (1.0D + d4) / (1.0D + d4);
/* 1730 */         for (j = 0; j < paramInt; j++)
/*      */         {
/* 1732 */           arrayOfDouble1[j] = ((arrayOfDouble1[j] + d4 * arrayOfDouble[i][j]) / (1.0D + d4));
/* 1733 */           paramArrayOfDouble1[j] /= (1.0D + d4);
/*      */         }
/*      */       }
/*      */     }
/* 1737 */     if (k >= m) {
/* 1738 */       info("Exceeds max_iter in multiclass_prob\n");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private static void svm_binary_svc_probability(svm_problem paramsvm_problem, svm_parameter paramsvm_parameter, double paramDouble1, double paramDouble2, double[] paramArrayOfDouble)
/*      */   {
/* 1745 */     int j = 5;
/* 1746 */     int[] arrayOfInt = new int[paramsvm_problem.l];
/* 1747 */     double[] arrayOfDouble1 = new double[paramsvm_problem.l];
/*      */     
/*      */ 
/* 1750 */     for (int i = 0; i < paramsvm_problem.l; i++) arrayOfInt[i] = i;
/* 1751 */     int k; int m; for (i = 0; i < paramsvm_problem.l; i++)
/*      */     {
/* 1753 */       k = i + rand.nextInt(paramsvm_problem.l - i);
/* 1754 */       m = arrayOfInt[i];arrayOfInt[i] = arrayOfInt[k];arrayOfInt[k] = m; }
/*      */     svm_problem localsvm_problem;
/* 1756 */     int n; int i2; int i3; for (i = 0; i < j; i++)
/*      */     {
/* 1758 */       k = i * paramsvm_problem.l / j;
/* 1759 */       m = (i + 1) * paramsvm_problem.l / j;
/*      */       
/* 1761 */       localsvm_problem = new svm_problem();
/*      */       
/* 1763 */       paramsvm_problem.l -= m - k;
/* 1764 */       localsvm_problem.x = new svm_node[localsvm_problem.l][];
/* 1765 */       localsvm_problem.y = new double[localsvm_problem.l];
/*      */       
/* 1767 */       int i1 = 0;
/* 1768 */       for (n = 0; n < k; n++)
/*      */       {
/* 1770 */         localsvm_problem.x[i1] = paramsvm_problem.x[arrayOfInt[n]];
/* 1771 */         localsvm_problem.y[i1] = paramsvm_problem.y[arrayOfInt[n]];
/* 1772 */         i1++;
/*      */       }
/* 1774 */       for (n = m; n < paramsvm_problem.l; n++)
/*      */       {
/* 1776 */         localsvm_problem.x[i1] = paramsvm_problem.x[arrayOfInt[n]];
/* 1777 */         localsvm_problem.y[i1] = paramsvm_problem.y[arrayOfInt[n]];
/* 1778 */         i1++;
/*      */       }
/* 1780 */       i2 = 0;i3 = 0;
/* 1781 */       for (n = 0; n < i1; n++) {
/* 1782 */         if (localsvm_problem.y[n] > 0.0D) {
/* 1783 */           i2++;
/*      */         } else
/* 1785 */           i3++;
/*      */       }
/* 1787 */       if ((i2 == 0) && (i3 == 0))
/* 1788 */         for (n = k; n < m;) {
/* 1789 */           arrayOfDouble1[arrayOfInt[n]] = 0.0D;n++; continue;
/* 1790 */           if ((i2 > 0) && (i3 == 0))
/* 1791 */             n = k; for (;;) { if (n < m) {
/* 1792 */               arrayOfDouble1[arrayOfInt[n]] = 1.0D;n++; continue;
/* 1793 */               if ((i2 == 0) && (i3 > 0))
/* 1794 */                 for (n = k; n < m;) {
/* 1795 */                   arrayOfDouble1[arrayOfInt[n]] = -1.0D;n++; continue;
/*      */                   
/*      */ 
/* 1798 */                   svm_parameter localsvm_parameter = (svm_parameter)paramsvm_parameter.clone();
/* 1799 */                   localsvm_parameter.probability = 0;
/* 1800 */                   localsvm_parameter.C = 1.0D;
/* 1801 */                   localsvm_parameter.nr_weight = 2;
/* 1802 */                   localsvm_parameter.weight_label = new int[2];
/* 1803 */                   localsvm_parameter.weight = new double[2];
/* 1804 */                   localsvm_parameter.weight_label[0] = 1;
/* 1805 */                   localsvm_parameter.weight_label[1] = -1;
/* 1806 */                   localsvm_parameter.weight[0] = paramDouble1;
/* 1807 */                   localsvm_parameter.weight[1] = paramDouble2;
/* 1808 */                   svm_model localsvm_model = svm_train(localsvm_problem, localsvm_parameter);
/* 1809 */                   for (n = k; n < m; n++)
/*      */                   {
/* 1811 */                     double[] arrayOfDouble2 = new double[1];
/* 1812 */                     svm_predict_values(localsvm_model, paramsvm_problem.x[arrayOfInt[n]], arrayOfDouble2);
/* 1813 */                     arrayOfDouble1[arrayOfInt[n]] = arrayOfDouble2[0];
/*      */                     
/* 1815 */                     arrayOfDouble1[arrayOfInt[n]] *= localsvm_model.label[0];
/*      */                   }
/*      */                 }
/*      */             } } } }
/* 1819 */     sigmoid_train(paramsvm_problem.l, arrayOfDouble1, paramsvm_problem.y, paramArrayOfDouble);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static double svm_svr_probability(svm_problem paramsvm_problem, svm_parameter paramsvm_parameter)
/*      */   {
/* 1826 */     int j = 5;
/* 1827 */     double[] arrayOfDouble = new double[paramsvm_problem.l];
/* 1828 */     double d1 = 0.0D;
/*      */     
/* 1830 */     svm_parameter localsvm_parameter = (svm_parameter)paramsvm_parameter.clone();
/* 1831 */     localsvm_parameter.probability = 0;
/* 1832 */     svm_cross_validation(paramsvm_problem, localsvm_parameter, j, arrayOfDouble);
/* 1833 */     for (int i = 0; i < paramsvm_problem.l; i++)
/*      */     {
/* 1835 */       arrayOfDouble[i] = (paramsvm_problem.y[i] - arrayOfDouble[i]);
/* 1836 */       d1 += Math.abs(arrayOfDouble[i]);
/*      */     }
/* 1838 */     d1 /= paramsvm_problem.l;
/* 1839 */     double d2 = Math.sqrt(2.0D * d1 * d1);
/* 1840 */     int k = 0;
/* 1841 */     d1 = 0.0D;
/* 1842 */     for (i = 0; i < paramsvm_problem.l; i++)
/* 1843 */       if (Math.abs(arrayOfDouble[i]) > 5.0D * d2) {
/* 1844 */         k += 1;
/*      */       } else
/* 1846 */         d1 += Math.abs(arrayOfDouble[i]);
/* 1847 */     d1 /= (paramsvm_problem.l - k);
/* 1848 */     info("Prob. model for test data: target value = predicted value + z,\nz: Laplace distribution e^(-|z|/sigma)/(2sigma),sigma=" + d1 + "\n");
/* 1849 */     return d1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static void svm_group_classes(svm_problem paramsvm_problem, int[] paramArrayOfInt1, int[][] paramArrayOfInt2, int[][] paramArrayOfInt3, int[][] paramArrayOfInt4, int[] paramArrayOfInt5)
/*      */   {
/* 1856 */     int i = paramsvm_problem.l;
/* 1857 */     int j = 16;
/* 1858 */     int k = 0;
/* 1859 */     Object localObject1 = new int[j];
/* 1860 */     Object localObject2 = new int[j];
/* 1861 */     int[] arrayOfInt1 = new int[i];
/*      */     
/*      */     int n;
/* 1864 */     for (int m = 0; m < i; m++)
/*      */     {
/* 1866 */       n = (int)paramsvm_problem.y[m];
/*      */       
/* 1868 */       for (int i1 = 0; i1 < k; i1++)
/*      */       {
/* 1870 */         if (n == localObject1[i1])
/*      */         {
/* 1872 */           localObject2[i1] += 1;
/* 1873 */           break;
/*      */         }
/*      */       }
/* 1876 */       arrayOfInt1[m] = i1;
/* 1877 */       if (i1 == k)
/*      */       {
/* 1879 */         if (k == j)
/*      */         {
/* 1881 */           j *= 2;
/* 1882 */           int[] arrayOfInt3 = new int[j];
/* 1883 */           System.arraycopy(localObject1, 0, arrayOfInt3, 0, localObject1.length);
/* 1884 */           localObject1 = arrayOfInt3;
/* 1885 */           arrayOfInt3 = new int[j];
/* 1886 */           System.arraycopy(localObject2, 0, arrayOfInt3, 0, localObject2.length);
/* 1887 */           localObject2 = arrayOfInt3;
/*      */         }
/* 1889 */         localObject1[k] = n;
/* 1890 */         localObject2[k] = 1;
/* 1891 */         k++;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1900 */     if ((k == 2) && (localObject1[0] == -1) && (localObject1[1] == 1))
/*      */     {
/* 1902 */       n = localObject1[0];localObject1[0] = localObject1[1];localObject1[1] = n;
/* 1903 */       n = localObject2[0];localObject2[0] = localObject2[1];localObject2[1] = n;
/* 1904 */       for (m = 0; m < i; m++)
/*      */       {
/* 1906 */         if (arrayOfInt1[m] == 0) {
/* 1907 */           arrayOfInt1[m] = 1;
/*      */         } else {
/* 1909 */           arrayOfInt1[m] = 0;
/*      */         }
/*      */       }
/*      */     }
/* 1913 */     int[] arrayOfInt2 = new int[k];
/* 1914 */     arrayOfInt2[0] = 0;
/* 1915 */     for (m = 1; m < k; m++)
/* 1916 */       arrayOfInt2[m] = (arrayOfInt2[(m - 1)] + localObject2[(m - 1)]);
/* 1917 */     for (m = 0; m < i; m++)
/*      */     {
/* 1919 */       paramArrayOfInt5[arrayOfInt2[arrayOfInt1[m]]] = m;
/* 1920 */       arrayOfInt2[arrayOfInt1[m]] += 1;
/*      */     }
/* 1922 */     arrayOfInt2[0] = 0;
/* 1923 */     for (m = 1; m < k; m++) {
/* 1924 */       arrayOfInt2[m] = (arrayOfInt2[(m - 1)] + localObject2[(m - 1)]);
/*      */     }
/* 1926 */     paramArrayOfInt1[0] = k;
/* 1927 */     paramArrayOfInt2[0] = localObject1;
/* 1928 */     paramArrayOfInt3[0] = arrayOfInt2;
/* 1929 */     paramArrayOfInt4[0] = localObject2;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static svm_model svm_train(svm_problem paramsvm_problem, svm_parameter paramsvm_parameter)
/*      */   {
/* 1937 */     svm_model localsvm_model = new svm_model();
/* 1938 */     localsvm_model.param = paramsvm_parameter;
/*      */     
/* 1940 */     if ((paramsvm_parameter.svm_type == 2) || (paramsvm_parameter.svm_type == 3) || (paramsvm_parameter.svm_type == 4))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1945 */       localsvm_model.nr_class = 2;
/* 1946 */       localsvm_model.label = null;
/* 1947 */       localsvm_model.nSV = null;
/* 1948 */       localsvm_model.probA = null;localsvm_model.probB = null;
/* 1949 */       localsvm_model.sv_coef = new double[1][];
/*      */       
/* 1951 */       if ((paramsvm_parameter.probability == 1) && ((paramsvm_parameter.svm_type == 3) || (paramsvm_parameter.svm_type == 4)))
/*      */       {
/*      */ 
/*      */ 
/* 1955 */         localsvm_model.probA = new double[1];
/* 1956 */         localsvm_model.probA[0] = svm_svr_probability(paramsvm_problem, paramsvm_parameter);
/*      */       }
/*      */       
/* 1959 */       decision_function localdecision_function = svm_train_one(paramsvm_problem, paramsvm_parameter, 0.0D, 0.0D);
/* 1960 */       localsvm_model.rho = new double[1];
/* 1961 */       localsvm_model.rho[0] = localdecision_function.rho;
/*      */       
/* 1963 */       int j = 0;
/*      */       
/* 1965 */       for (int k = 0; k < paramsvm_problem.l; k++)
/* 1966 */         if (Math.abs(localdecision_function.alpha[k]) > 0.0D) j++;
/* 1967 */       localsvm_model.l = j;
/* 1968 */       localsvm_model.SV = new svm_node[j][];
/* 1969 */       localsvm_model.sv_coef[0] = new double[j];
/* 1970 */       localsvm_model.sv_indices = new int[j];
/* 1971 */       int m = 0;
/* 1972 */       for (k = 0; k < paramsvm_problem.l; k++) {
/* 1973 */         if (Math.abs(localdecision_function.alpha[k]) > 0.0D)
/*      */         {
/* 1975 */           localsvm_model.SV[m] = paramsvm_problem.x[k];
/* 1976 */           localsvm_model.sv_coef[0][m] = localdecision_function.alpha[k];
/* 1977 */           localsvm_model.sv_indices[m] = (k + 1);
/* 1978 */           m++;
/*      */         }
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/* 1984 */       int i = paramsvm_problem.l;
/* 1985 */       int[] arrayOfInt1 = new int[1];
/* 1986 */       int[][] arrayOfInt2 = new int[1][];
/* 1987 */       int[][] arrayOfInt3 = new int[1][];
/* 1988 */       int[][] arrayOfInt4 = new int[1][];
/* 1989 */       int[] arrayOfInt5 = new int[i];
/*      */       
/*      */ 
/* 1992 */       svm_group_classes(paramsvm_problem, arrayOfInt1, arrayOfInt2, arrayOfInt3, arrayOfInt4, arrayOfInt5);
/* 1993 */       int n = arrayOfInt1[0];
/* 1994 */       int[] arrayOfInt6 = arrayOfInt2[0];
/* 1995 */       int[] arrayOfInt7 = arrayOfInt3[0];
/* 1996 */       int[] arrayOfInt8 = arrayOfInt4[0];
/*      */       
/* 1998 */       if (n == 1) {
/* 1999 */         info("WARNING: training data in only one class. See README for details.\n");
/*      */       }
/* 2001 */       svm_node[][] arrayOfsvm_node = new svm_node[i][];
/*      */       
/* 2003 */       for (int i1 = 0; i1 < i; i1++) {
/* 2004 */         arrayOfsvm_node[i1] = paramsvm_problem.x[arrayOfInt5[i1]];
/*      */       }
/*      */       
/*      */ 
/* 2008 */       double[] arrayOfDouble1 = new double[n];
/* 2009 */       for (i1 = 0; i1 < n; i1++)
/* 2010 */         arrayOfDouble1[i1] = paramsvm_parameter.C;
/* 2011 */       for (i1 = 0; i1 < paramsvm_parameter.nr_weight; i1++)
/*      */       {
/*      */ 
/* 2014 */         for (int i2 = 0; i2 < n; i2++)
/* 2015 */           if (paramsvm_parameter.weight_label[i1] == arrayOfInt6[i2])
/*      */             break;
/* 2017 */         if (i2 == n) {
/* 2018 */           System.err.print("WARNING: class label " + paramsvm_parameter.weight_label[i1] + " specified in weight is not found\n");
/*      */         } else {
/* 2020 */           arrayOfDouble1[i2] *= paramsvm_parameter.weight[i1];
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 2025 */       boolean[] arrayOfBoolean = new boolean[i];
/* 2026 */       for (i1 = 0; i1 < i; i1++)
/* 2027 */         arrayOfBoolean[i1] = false;
/* 2028 */       decision_function[] arrayOfdecision_function = new decision_function[n * (n - 1) / 2];
/*      */       
/* 2030 */       double[] arrayOfDouble2 = null;double[] arrayOfDouble3 = null;
/* 2031 */       if (paramsvm_parameter.probability == 1)
/*      */       {
/* 2033 */         arrayOfDouble2 = new double[n * (n - 1) / 2];
/* 2034 */         arrayOfDouble3 = new double[n * (n - 1) / 2];
/*      */       }
/*      */       
/* 2037 */       int i3 = 0;
/* 2038 */       int i5; int i6; int i7; int i8; int i9; for (i1 = 0; i1 < n; i1++) {
/* 2039 */         for (i4 = i1 + 1; i4 < n; i4++)
/*      */         {
/* 2041 */           localObject = new svm_problem();
/* 2042 */           i5 = arrayOfInt7[i1];i6 = arrayOfInt7[i4];
/* 2043 */           i7 = arrayOfInt8[i1];i8 = arrayOfInt8[i4];
/* 2044 */           ((svm_problem)localObject).l = (i7 + i8);
/* 2045 */           ((svm_problem)localObject).x = new svm_node[((svm_problem)localObject).l][];
/* 2046 */           ((svm_problem)localObject).y = new double[((svm_problem)localObject).l];
/*      */           
/* 2048 */           for (i9 = 0; i9 < i7; i9++)
/*      */           {
/* 2050 */             ((svm_problem)localObject).x[i9] = arrayOfsvm_node[(i5 + i9)];
/* 2051 */             ((svm_problem)localObject).y[i9] = 1.0D;
/*      */           }
/* 2053 */           for (i9 = 0; i9 < i8; i9++)
/*      */           {
/* 2055 */             ((svm_problem)localObject).x[(i7 + i9)] = arrayOfsvm_node[(i6 + i9)];
/* 2056 */             ((svm_problem)localObject).y[(i7 + i9)] = -1.0D;
/*      */           }
/*      */           
/* 2059 */           if (paramsvm_parameter.probability == 1)
/*      */           {
/* 2061 */             double[] arrayOfDouble4 = new double[2];
/* 2062 */             svm_binary_svc_probability((svm_problem)localObject, paramsvm_parameter, arrayOfDouble1[i1], arrayOfDouble1[i4], arrayOfDouble4);
/* 2063 */             arrayOfDouble2[i3] = arrayOfDouble4[0];
/* 2064 */             arrayOfDouble3[i3] = arrayOfDouble4[1];
/*      */           }
/*      */           
/* 2067 */           arrayOfdecision_function[i3] = svm_train_one((svm_problem)localObject, paramsvm_parameter, arrayOfDouble1[i1], arrayOfDouble1[i4]);
/* 2068 */           for (i9 = 0; i9 < i7; i9++)
/* 2069 */             if ((arrayOfBoolean[(i5 + i9)] == 0) && (Math.abs(arrayOfdecision_function[i3].alpha[i9]) > 0.0D))
/* 2070 */               arrayOfBoolean[(i5 + i9)] = true;
/* 2071 */           for (i9 = 0; i9 < i8; i9++)
/* 2072 */             if ((arrayOfBoolean[(i6 + i9)] == 0) && (Math.abs(arrayOfdecision_function[i3].alpha[(i7 + i9)]) > 0.0D))
/* 2073 */               arrayOfBoolean[(i6 + i9)] = true;
/* 2074 */           i3++;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 2079 */       localsvm_model.nr_class = n;
/*      */       
/* 2081 */       localsvm_model.label = new int[n];
/* 2082 */       for (i1 = 0; i1 < n; i1++) {
/* 2083 */         localsvm_model.label[i1] = arrayOfInt6[i1];
/*      */       }
/* 2085 */       localsvm_model.rho = new double[n * (n - 1) / 2];
/* 2086 */       for (i1 = 0; i1 < n * (n - 1) / 2; i1++) {
/* 2087 */         localsvm_model.rho[i1] = arrayOfdecision_function[i1].rho;
/*      */       }
/* 2089 */       if (paramsvm_parameter.probability == 1)
/*      */       {
/* 2091 */         localsvm_model.probA = new double[n * (n - 1) / 2];
/* 2092 */         localsvm_model.probB = new double[n * (n - 1) / 2];
/* 2093 */         for (i1 = 0; i1 < n * (n - 1) / 2; i1++)
/*      */         {
/* 2095 */           localsvm_model.probA[i1] = arrayOfDouble2[i1];
/* 2096 */           localsvm_model.probB[i1] = arrayOfDouble3[i1];
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 2101 */       localsvm_model.probA = null;
/* 2102 */       localsvm_model.probB = null;
/*      */       
/*      */ 
/* 2105 */       int i4 = 0;
/* 2106 */       Object localObject = new int[n];
/* 2107 */       localsvm_model.nSV = new int[n];
/* 2108 */       for (i1 = 0; i1 < n; i1++)
/*      */       {
/* 2110 */         i5 = 0;
/* 2111 */         for (i6 = 0; i6 < arrayOfInt8[i1]; i6++)
/* 2112 */           if (arrayOfBoolean[(arrayOfInt7[i1] + i6)] != 0)
/*      */           {
/* 2114 */             i5++;
/* 2115 */             i4++;
/*      */           }
/* 2117 */         localsvm_model.nSV[i1] = i5;
/* 2118 */         localObject[i1] = i5;
/*      */       }
/*      */       
/* 2121 */       info("Total nSV = " + i4 + "\n");
/*      */       
/* 2123 */       localsvm_model.l = i4;
/* 2124 */       localsvm_model.SV = new svm_node[i4][];
/* 2125 */       localsvm_model.sv_indices = new int[i4];
/* 2126 */       i3 = 0;
/* 2127 */       for (i1 = 0; i1 < i; i1++) {
/* 2128 */         if (arrayOfBoolean[i1] != 0)
/*      */         {
/* 2130 */           localsvm_model.SV[i3] = arrayOfsvm_node[i1];
/* 2131 */           localsvm_model.sv_indices[(i3++)] = (arrayOfInt5[i1] + 1);
/*      */         }
/*      */       }
/* 2134 */       int[] arrayOfInt9 = new int[n];
/* 2135 */       arrayOfInt9[0] = 0;
/* 2136 */       for (i1 = 1; i1 < n; i1++) {
/* 2137 */         arrayOfInt9[i1] = (arrayOfInt9[(i1 - 1)] + localObject[(i1 - 1)]);
/*      */       }
/* 2139 */       localsvm_model.sv_coef = new double[n - 1][];
/* 2140 */       for (i1 = 0; i1 < n - 1; i1++) {
/* 2141 */         localsvm_model.sv_coef[i1] = new double[i4];
/*      */       }
/* 2143 */       i3 = 0;
/* 2144 */       for (i1 = 0; i1 < n; i1++)
/* 2145 */         for (i6 = i1 + 1; i6 < n; i6++)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2151 */           i7 = arrayOfInt7[i1];
/* 2152 */           i8 = arrayOfInt7[i6];
/* 2153 */           i9 = arrayOfInt8[i1];
/* 2154 */           int i10 = arrayOfInt8[i6];
/*      */           
/* 2156 */           int i11 = arrayOfInt9[i1];
/*      */           
/* 2158 */           for (int i12 = 0; i12 < i9; i12++)
/* 2159 */             if (arrayOfBoolean[(i7 + i12)] != 0)
/* 2160 */               localsvm_model.sv_coef[(i6 - 1)][(i11++)] = arrayOfdecision_function[i3].alpha[i12];
/* 2161 */           i11 = arrayOfInt9[i6];
/* 2162 */           for (i12 = 0; i12 < i10; i12++)
/* 2163 */             if (arrayOfBoolean[(i8 + i12)] != 0)
/* 2164 */               localsvm_model.sv_coef[i1][(i11++)] = arrayOfdecision_function[i3].alpha[(i9 + i12)];
/* 2165 */           i3++;
/*      */         }
/*      */     }
/* 2168 */     return localsvm_model;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static void svm_cross_validation(svm_problem paramsvm_problem, svm_parameter paramsvm_parameter, int paramInt, double[] paramArrayOfDouble)
/*      */   {
/* 2175 */     int[] arrayOfInt1 = new int[paramInt + 1];
/* 2176 */     int j = paramsvm_problem.l;
/* 2177 */     int[] arrayOfInt2 = new int[j];
/*      */     Object localObject1;
/*      */     Object localObject2;
/*      */     int k;
/* 2181 */     int m; if (((paramsvm_parameter.svm_type == 0) || (paramsvm_parameter.svm_type == 1)) && (paramInt < j))
/*      */     {
/*      */ 
/* 2184 */       int[] arrayOfInt3 = new int[1];
/* 2185 */       int[][] arrayOfInt4 = new int[1][];
/* 2186 */       int[][] arrayOfInt5 = new int[1][];
/* 2187 */       int[][] arrayOfInt6 = new int[1][];
/*      */       
/* 2189 */       svm_group_classes(paramsvm_problem, arrayOfInt3, arrayOfInt4, arrayOfInt5, arrayOfInt6, arrayOfInt2);
/*      */       
/* 2191 */       int i2 = arrayOfInt3[0];
/* 2192 */       localObject1 = arrayOfInt5[0];
/* 2193 */       localObject2 = arrayOfInt6[0];
/*      */       
/*      */ 
/* 2196 */       int[] arrayOfInt7 = new int[paramInt];
/*      */       
/* 2198 */       int[] arrayOfInt8 = new int[j];
/* 2199 */       for (i = 0; i < j; i++)
/* 2200 */         arrayOfInt8[i] = arrayOfInt2[i];
/* 2201 */       int i4; int i5; for (int i3 = 0; i3 < i2; i3++)
/* 2202 */         for (i = 0; i < localObject2[i3]; i++)
/*      */         {
/* 2204 */           i4 = i + rand.nextInt(localObject2[i3] - i);
/* 2205 */           i5 = arrayOfInt8[(localObject1[i3] + i4)];arrayOfInt8[(localObject1[i3] + i4)] = arrayOfInt8[(localObject1[i3] + i)];arrayOfInt8[(localObject1[i3] + i)] = i5;
/*      */         }
/* 2207 */       for (i = 0; i < paramInt; i++)
/*      */       {
/* 2209 */         arrayOfInt7[i] = 0;
/* 2210 */         for (i3 = 0; i3 < i2; i3++)
/* 2211 */           arrayOfInt7[i] += (i + 1) * localObject2[i3] / paramInt - i * localObject2[i3] / paramInt;
/*      */       }
/* 2213 */       arrayOfInt1[0] = 0;
/* 2214 */       for (i = 1; i <= paramInt; i++)
/* 2215 */         arrayOfInt1[i] = (arrayOfInt1[(i - 1)] + arrayOfInt7[(i - 1)]);
/* 2216 */       for (i3 = 0; i3 < i2; i3++)
/* 2217 */         for (i = 0; i < paramInt; i++)
/*      */         {
/* 2219 */           i4 = localObject1[i3] + i * localObject2[i3] / paramInt;
/* 2220 */           i5 = localObject1[i3] + (i + 1) * localObject2[i3] / paramInt;
/* 2221 */           for (int i6 = i4; i6 < i5; i6++)
/*      */           {
/* 2223 */             arrayOfInt2[arrayOfInt1[i]] = arrayOfInt8[i6];
/* 2224 */             arrayOfInt1[i] += 1;
/*      */           }
/*      */         }
/* 2227 */       arrayOfInt1[0] = 0;
/* 2228 */       for (i = 1; i <= paramInt; i++) {
/* 2229 */         arrayOfInt1[i] = (arrayOfInt1[(i - 1)] + arrayOfInt7[(i - 1)]);
/*      */       }
/*      */     }
/*      */     else {
/* 2233 */       for (i = 0; i < j; i++) arrayOfInt2[i] = i;
/* 2234 */       for (i = 0; i < j; i++)
/*      */       {
/* 2236 */         k = i + rand.nextInt(j - i);
/* 2237 */         m = arrayOfInt2[i];arrayOfInt2[i] = arrayOfInt2[k];arrayOfInt2[k] = m;
/*      */       }
/* 2239 */       for (i = 0; i <= paramInt; i++) {
/* 2240 */         arrayOfInt1[i] = (i * j / paramInt);
/*      */       }
/*      */     }
/* 2243 */     for (int i = 0; i < paramInt; i++)
/*      */     {
/* 2245 */       k = arrayOfInt1[i];
/* 2246 */       m = arrayOfInt1[(i + 1)];
/*      */       
/* 2248 */       svm_problem localsvm_problem = new svm_problem();
/*      */       
/* 2250 */       localsvm_problem.l = (j - (m - k));
/* 2251 */       localsvm_problem.x = new svm_node[localsvm_problem.l][];
/* 2252 */       localsvm_problem.y = new double[localsvm_problem.l];
/*      */       
/* 2254 */       int i1 = 0;
/* 2255 */       for (int n = 0; n < k; n++)
/*      */       {
/* 2257 */         localsvm_problem.x[i1] = paramsvm_problem.x[arrayOfInt2[n]];
/* 2258 */         localsvm_problem.y[i1] = paramsvm_problem.y[arrayOfInt2[n]];
/* 2259 */         i1++;
/*      */       }
/* 2261 */       for (n = m; n < j; n++)
/*      */       {
/* 2263 */         localsvm_problem.x[i1] = paramsvm_problem.x[arrayOfInt2[n]];
/* 2264 */         localsvm_problem.y[i1] = paramsvm_problem.y[arrayOfInt2[n]];
/* 2265 */         i1++;
/*      */       }
/* 2267 */       localObject1 = svm_train(localsvm_problem, paramsvm_parameter);
/* 2268 */       if ((paramsvm_parameter.probability == 1) && ((paramsvm_parameter.svm_type == 0) || (paramsvm_parameter.svm_type == 1)))
/*      */       {
/*      */ 
/*      */ 
/* 2272 */         localObject2 = new double[svm_get_nr_class((svm_model)localObject1)];
/* 2273 */         for (n = k; n < m; n++) {
/* 2274 */           paramArrayOfDouble[arrayOfInt2[n]] = svm_predict_probability((svm_model)localObject1, paramsvm_problem.x[arrayOfInt2[n]], (double[])localObject2);
/*      */         }
/*      */       } else {
/* 2277 */         for (n = k; n < m; n++)
/* 2278 */           paramArrayOfDouble[arrayOfInt2[n]] = svm_predict((svm_model)localObject1, paramsvm_problem.x[arrayOfInt2[n]]);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public static int svm_get_svm_type(svm_model paramsvm_model) {
/* 2284 */     return paramsvm_model.param.svm_type;
/*      */   }
/*      */   
/*      */   public static int svm_get_nr_class(svm_model paramsvm_model)
/*      */   {
/* 2289 */     return paramsvm_model.nr_class;
/*      */   }
/*      */   
/*      */   public static void svm_get_labels(svm_model paramsvm_model, int[] paramArrayOfInt)
/*      */   {
/* 2294 */     if (paramsvm_model.label != null) {
/* 2295 */       for (int i = 0; i < paramsvm_model.nr_class; i++)
/* 2296 */         paramArrayOfInt[i] = paramsvm_model.label[i];
/*      */     }
/*      */   }
/*      */   
/*      */   public static void svm_get_sv_indices(svm_model paramsvm_model, int[] paramArrayOfInt) {
/* 2301 */     if (paramsvm_model.sv_indices != null) {
/* 2302 */       for (int i = 0; i < paramsvm_model.l; i++)
/* 2303 */         paramArrayOfInt[i] = paramsvm_model.sv_indices[i];
/*      */     }
/*      */   }
/*      */   
/*      */   public static int svm_get_nr_sv(svm_model paramsvm_model) {
/* 2308 */     return paramsvm_model.l;
/*      */   }
/*      */   
/*      */   public static double svm_get_svr_probability(svm_model paramsvm_model)
/*      */   {
/* 2313 */     if (((paramsvm_model.param.svm_type == 3) || (paramsvm_model.param.svm_type == 4)) && (paramsvm_model.probA != null))
/*      */     {
/* 2315 */       return paramsvm_model.probA[0];
/*      */     }
/*      */     
/* 2318 */     System.err.print("Model doesn't contain information for SVR probability inference\n");
/* 2319 */     return 0.0D;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static double svm_predict_values(svm_model paramsvm_model, svm_node[] paramArrayOfsvm_node, double[] paramArrayOfDouble)
/*      */   {
/* 2326 */     if ((paramsvm_model.param.svm_type == 2) || (paramsvm_model.param.svm_type == 3) || (paramsvm_model.param.svm_type == 4))
/*      */     {
/*      */ 
/*      */ 
/* 2330 */       double[] arrayOfDouble1 = paramsvm_model.sv_coef[0];
/* 2331 */       double d1 = 0.0D;
/* 2332 */       for (i = 0; i < paramsvm_model.l; i++)
/* 2333 */         d1 += arrayOfDouble1[i] * Kernel.k_function(paramArrayOfsvm_node, paramsvm_model.SV[i], paramsvm_model.param);
/* 2334 */       d1 -= paramsvm_model.rho[0];
/* 2335 */       paramArrayOfDouble[0] = d1;
/*      */       
/* 2337 */       if (paramsvm_model.param.svm_type == 2) {
/* 2338 */         return d1 > 0.0D ? 1.0D : -1.0D;
/*      */       }
/* 2340 */       return d1;
/*      */     }
/*      */     
/*      */ 
/* 2344 */     int j = paramsvm_model.nr_class;
/* 2345 */     int k = paramsvm_model.l;
/*      */     
/* 2347 */     double[] arrayOfDouble2 = new double[k];
/* 2348 */     for (int i = 0; i < k; i++) {
/* 2349 */       arrayOfDouble2[i] = Kernel.k_function(paramArrayOfsvm_node, paramsvm_model.SV[i], paramsvm_model.param);
/*      */     }
/* 2351 */     int[] arrayOfInt1 = new int[j];
/* 2352 */     arrayOfInt1[0] = 0;
/* 2353 */     for (i = 1; i < j; i++) {
/* 2354 */       arrayOfInt1[i] = (arrayOfInt1[(i - 1)] + paramsvm_model.nSV[(i - 1)]);
/*      */     }
/* 2356 */     int[] arrayOfInt2 = new int[j];
/* 2357 */     for (i = 0; i < j; i++) {
/* 2358 */       arrayOfInt2[i] = 0;
/*      */     }
/* 2360 */     int m = 0;
/* 2361 */     for (i = 0; i < j; i++) {
/* 2362 */       for (n = i + 1; n < j; n++)
/*      */       {
/* 2364 */         double d2 = 0.0D;
/* 2365 */         int i1 = arrayOfInt1[i];
/* 2366 */         int i2 = arrayOfInt1[n];
/* 2367 */         int i3 = paramsvm_model.nSV[i];
/* 2368 */         int i4 = paramsvm_model.nSV[n];
/*      */         
/*      */ 
/* 2371 */         double[] arrayOfDouble3 = paramsvm_model.sv_coef[(n - 1)];
/* 2372 */         double[] arrayOfDouble4 = paramsvm_model.sv_coef[i];
/* 2373 */         for (int i5 = 0; i5 < i3; i5++)
/* 2374 */           d2 += arrayOfDouble3[(i1 + i5)] * arrayOfDouble2[(i1 + i5)];
/* 2375 */         for (i5 = 0; i5 < i4; i5++)
/* 2376 */           d2 += arrayOfDouble4[(i2 + i5)] * arrayOfDouble2[(i2 + i5)];
/* 2377 */         d2 -= paramsvm_model.rho[m];
/* 2378 */         paramArrayOfDouble[m] = d2;
/*      */         
/* 2380 */         if (paramArrayOfDouble[m] > 0.0D) {
/* 2381 */           arrayOfInt2[i] += 1;
/*      */         } else
/* 2383 */           arrayOfInt2[n] += 1;
/* 2384 */         m++;
/*      */       }
/*      */     }
/* 2387 */     int n = 0;
/* 2388 */     for (i = 1; i < j; i++) {
/* 2389 */       if (arrayOfInt2[i] > arrayOfInt2[n])
/* 2390 */         n = i;
/*      */     }
/* 2392 */     return paramsvm_model.label[n];
/*      */   }
/*      */   
/*      */ 
/*      */   public static double svm_predict(svm_model paramsvm_model, svm_node[] paramArrayOfsvm_node)
/*      */   {
/* 2398 */     int i = paramsvm_model.nr_class;
/*      */     double[] arrayOfDouble;
/* 2400 */     if ((paramsvm_model.param.svm_type == 2) || (paramsvm_model.param.svm_type == 3) || (paramsvm_model.param.svm_type == 4))
/*      */     {
/*      */ 
/* 2403 */       arrayOfDouble = new double[1];
/*      */     } else
/* 2405 */       arrayOfDouble = new double[i * (i - 1) / 2];
/* 2406 */     double d = svm_predict_values(paramsvm_model, paramArrayOfsvm_node, arrayOfDouble);
/* 2407 */     return d;
/*      */   }
/*      */   
/*      */   public static double svm_predict_probability(svm_model paramsvm_model, svm_node[] paramArrayOfsvm_node, double[] paramArrayOfDouble)
/*      */   {
/* 2412 */     if (((paramsvm_model.param.svm_type == 0) || (paramsvm_model.param.svm_type == 1)) && (paramsvm_model.probA != null) && (paramsvm_model.probB != null))
/*      */     {
/*      */ 
/*      */ 
/* 2416 */       int j = paramsvm_model.nr_class;
/* 2417 */       double[] arrayOfDouble = new double[j * (j - 1) / 2];
/* 2418 */       svm_predict_values(paramsvm_model, paramArrayOfsvm_node, arrayOfDouble);
/*      */       
/* 2420 */       double d = 1.0E-7D;
/* 2421 */       double[][] arrayOfDouble1 = new double[j][j];
/*      */       
/* 2423 */       int k = 0;
/* 2424 */       for (int i = 0; i < j; i++)
/* 2425 */         for (m = i + 1; m < j; m++)
/*      */         {
/* 2427 */           arrayOfDouble1[i][m] = Math.min(Math.max(sigmoid_predict(arrayOfDouble[k], paramsvm_model.probA[k], paramsvm_model.probB[k]), d), 1.0D - d);
/* 2428 */           arrayOfDouble1[m][i] = (1.0D - arrayOfDouble1[i][m]);
/* 2429 */           k++;
/*      */         }
/* 2431 */       multiclass_probability(j, arrayOfDouble1, paramArrayOfDouble);
/*      */       
/* 2433 */       int m = 0;
/* 2434 */       for (i = 1; i < j; i++)
/* 2435 */         if (paramArrayOfDouble[i] > paramArrayOfDouble[m])
/* 2436 */           m = i;
/* 2437 */       return paramsvm_model.label[m];
/*      */     }
/*      */     
/* 2440 */     return svm_predict(paramsvm_model, paramArrayOfsvm_node);
/*      */   }
/*      */   
/* 2443 */   static final String[] svm_type_table = { "c_svc", "nu_svc", "one_class", "epsilon_svr", "nu_svr" };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 2448 */   static final String[] kernel_type_table = { "linear", "polynomial", "rbf", "sigmoid", "precomputed" };
/*      */   
/*      */ 
/*      */ 
/*      */   public static void svm_save_model(String paramString, svm_model paramsvm_model)
/*      */     throws IOException
/*      */   {
/* 2455 */     DataOutputStream localDataOutputStream = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(paramString)));
/*      */     
/* 2457 */     svm_parameter localsvm_parameter = paramsvm_model.param;
/*      */     
/* 2459 */     localDataOutputStream.writeBytes("svm_type " + svm_type_table[localsvm_parameter.svm_type] + "\n");
/* 2460 */     localDataOutputStream.writeBytes("kernel_type " + kernel_type_table[localsvm_parameter.kernel_type] + "\n");
/*      */     
/* 2462 */     if (localsvm_parameter.kernel_type == 1) {
/* 2463 */       localDataOutputStream.writeBytes("degree " + localsvm_parameter.degree + "\n");
/*      */     }
/* 2465 */     if ((localsvm_parameter.kernel_type == 1) || (localsvm_parameter.kernel_type == 2) || (localsvm_parameter.kernel_type == 3))
/*      */     {
/*      */ 
/* 2468 */       localDataOutputStream.writeBytes("gamma " + localsvm_parameter.gamma + "\n");
/*      */     }
/* 2470 */     if ((localsvm_parameter.kernel_type == 1) || (localsvm_parameter.kernel_type == 3))
/*      */     {
/* 2472 */       localDataOutputStream.writeBytes("coef0 " + localsvm_parameter.coef0 + "\n");
/*      */     }
/* 2474 */     int i = paramsvm_model.nr_class;
/* 2475 */     int j = paramsvm_model.l;
/* 2476 */     localDataOutputStream.writeBytes("nr_class " + i + "\n");
/* 2477 */     localDataOutputStream.writeBytes("total_sv " + j + "\n");
/*      */     
/*      */ 
/* 2480 */     localDataOutputStream.writeBytes("rho");
/* 2481 */     for (int k = 0; k < i * (i - 1) / 2; k++)
/* 2482 */       localDataOutputStream.writeBytes(" " + paramsvm_model.rho[k]);
/* 2483 */     localDataOutputStream.writeBytes("\n");
/*      */     
/*      */ 
/* 2486 */     if (paramsvm_model.label != null)
/*      */     {
/* 2488 */       localDataOutputStream.writeBytes("label");
/* 2489 */       for (k = 0; k < i; k++)
/* 2490 */         localDataOutputStream.writeBytes(" " + paramsvm_model.label[k]);
/* 2491 */       localDataOutputStream.writeBytes("\n");
/*      */     }
/*      */     
/* 2494 */     if (paramsvm_model.probA != null)
/*      */     {
/* 2496 */       localDataOutputStream.writeBytes("probA");
/* 2497 */       for (k = 0; k < i * (i - 1) / 2; k++)
/* 2498 */         localDataOutputStream.writeBytes(" " + paramsvm_model.probA[k]);
/* 2499 */       localDataOutputStream.writeBytes("\n");
/*      */     }
/* 2501 */     if (paramsvm_model.probB != null)
/*      */     {
/* 2503 */       localDataOutputStream.writeBytes("probB");
/* 2504 */       for (k = 0; k < i * (i - 1) / 2; k++)
/* 2505 */         localDataOutputStream.writeBytes(" " + paramsvm_model.probB[k]);
/* 2506 */       localDataOutputStream.writeBytes("\n");
/*      */     }
/*      */     
/* 2509 */     if (paramsvm_model.nSV != null)
/*      */     {
/* 2511 */       localDataOutputStream.writeBytes("nr_sv");
/* 2512 */       for (k = 0; k < i; k++)
/* 2513 */         localDataOutputStream.writeBytes(" " + paramsvm_model.nSV[k]);
/* 2514 */       localDataOutputStream.writeBytes("\n");
/*      */     }
/*      */     
/* 2517 */     localDataOutputStream.writeBytes("SV\n");
/* 2518 */     double[][] arrayOfDouble = paramsvm_model.sv_coef;
/* 2519 */     svm_node[][] arrayOfsvm_node = paramsvm_model.SV;
/*      */     
/* 2521 */     for (int m = 0; m < j; m++)
/*      */     {
/* 2523 */       for (int n = 0; n < i - 1; n++) {
/* 2524 */         localDataOutputStream.writeBytes(arrayOfDouble[n][m] + " ");
/*      */       }
/* 2526 */       svm_node[] arrayOfsvm_node1 = arrayOfsvm_node[m];
/* 2527 */       if (localsvm_parameter.kernel_type == 4) {
/* 2528 */         localDataOutputStream.writeBytes("0:" + (int)arrayOfsvm_node1[0].value);
/*      */       } else
/* 2530 */         for (int i1 = 0; i1 < arrayOfsvm_node1.length; i1++)
/* 2531 */           localDataOutputStream.writeBytes(arrayOfsvm_node1[i1].index + ":" + arrayOfsvm_node1[i1].value + " ");
/* 2532 */       localDataOutputStream.writeBytes("\n");
/*      */     }
/*      */     
/* 2535 */     localDataOutputStream.close();
/*      */   }
/*      */   
/*      */   private static double atof(String paramString)
/*      */   {
/* 2540 */     return Double.valueOf(paramString).doubleValue();
/*      */   }
/*      */   
/*      */   private static int atoi(String paramString)
/*      */   {
/* 2545 */     return Integer.parseInt(paramString);
/*      */   }
/*      */   
/*      */   public static svm_model svm_load_model(String paramString) throws IOException
/*      */   {
/* 2550 */     return svm_load_model(new BufferedReader(new FileReader(paramString)));
/*      */   }
/*      */   
/*      */ 
/*      */   public static svm_model svm_load_model(BufferedReader paramBufferedReader)
/*      */     throws IOException
/*      */   {
/* 2557 */     svm_model localsvm_model = new svm_model();
/* 2558 */     svm_parameter localsvm_parameter = new svm_parameter();
/* 2559 */     localsvm_model.param = localsvm_parameter;
/* 2560 */     localsvm_model.rho = null;
/* 2561 */     localsvm_model.probA = null;
/* 2562 */     localsvm_model.probB = null;
/* 2563 */     localsvm_model.label = null;
/* 2564 */     localsvm_model.nSV = null;
/*      */     Object localObject;
/*      */     for (;;)
/*      */     {
/* 2568 */       String str1 = paramBufferedReader.readLine();
/* 2569 */       String str2 = str1.substring(str1.indexOf(' ') + 1);
/*      */       
/* 2571 */       if (str1.startsWith("svm_type"))
/*      */       {
/*      */ 
/* 2574 */         for (k = 0; k < svm_type_table.length; k++)
/*      */         {
/* 2576 */           if (str2.indexOf(svm_type_table[k]) != -1)
/*      */           {
/* 2578 */             localsvm_parameter.svm_type = k;
/* 2579 */             break;
/*      */           }
/*      */         }
/* 2582 */         if (k == svm_type_table.length)
/*      */         {
/* 2584 */           System.err.print("unknown svm type.\n");
/* 2585 */           return null;
/*      */         }
/*      */       }
/* 2588 */       else if (str1.startsWith("kernel_type"))
/*      */       {
/*      */ 
/* 2591 */         for (k = 0; k < kernel_type_table.length; k++)
/*      */         {
/* 2593 */           if (str2.indexOf(kernel_type_table[k]) != -1)
/*      */           {
/* 2595 */             localsvm_parameter.kernel_type = k;
/* 2596 */             break;
/*      */           }
/*      */         }
/* 2599 */         if (k == kernel_type_table.length)
/*      */         {
/* 2601 */           System.err.print("unknown kernel function.\n");
/* 2602 */           return null;
/*      */         }
/*      */       }
/* 2605 */       else if (str1.startsWith("degree")) {
/* 2606 */         localsvm_parameter.degree = atoi(str2);
/* 2607 */       } else if (str1.startsWith("gamma")) {
/* 2608 */         localsvm_parameter.gamma = atof(str2);
/* 2609 */       } else if (str1.startsWith("coef0")) {
/* 2610 */         localsvm_parameter.coef0 = atof(str2);
/* 2611 */       } else if (str1.startsWith("nr_class")) {
/* 2612 */         localsvm_model.nr_class = atoi(str2);
/* 2613 */       } else if (str1.startsWith("total_sv")) {
/* 2614 */         localsvm_model.l = atoi(str2); } else { int m;
/* 2615 */         if (str1.startsWith("rho"))
/*      */         {
/* 2617 */           k = localsvm_model.nr_class * (localsvm_model.nr_class - 1) / 2;
/* 2618 */           localsvm_model.rho = new double[k];
/* 2619 */           localObject = new StringTokenizer(str2);
/* 2620 */           for (m = 0; m < k; m++) {
/* 2621 */             localsvm_model.rho[m] = atof(((StringTokenizer)localObject).nextToken());
/*      */           }
/* 2623 */         } else if (str1.startsWith("label"))
/*      */         {
/* 2625 */           k = localsvm_model.nr_class;
/* 2626 */           localsvm_model.label = new int[k];
/* 2627 */           localObject = new StringTokenizer(str2);
/* 2628 */           for (m = 0; m < k; m++) {
/* 2629 */             localsvm_model.label[m] = atoi(((StringTokenizer)localObject).nextToken());
/*      */           }
/* 2631 */         } else if (str1.startsWith("probA"))
/*      */         {
/* 2633 */           k = localsvm_model.nr_class * (localsvm_model.nr_class - 1) / 2;
/* 2634 */           localsvm_model.probA = new double[k];
/* 2635 */           localObject = new StringTokenizer(str2);
/* 2636 */           for (m = 0; m < k; m++) {
/* 2637 */             localsvm_model.probA[m] = atof(((StringTokenizer)localObject).nextToken());
/*      */           }
/* 2639 */         } else if (str1.startsWith("probB"))
/*      */         {
/* 2641 */           k = localsvm_model.nr_class * (localsvm_model.nr_class - 1) / 2;
/* 2642 */           localsvm_model.probB = new double[k];
/* 2643 */           localObject = new StringTokenizer(str2);
/* 2644 */           for (m = 0; m < k; m++) {
/* 2645 */             localsvm_model.probB[m] = atof(((StringTokenizer)localObject).nextToken());
/*      */           }
/* 2647 */         } else if (str1.startsWith("nr_sv"))
/*      */         {
/* 2649 */           k = localsvm_model.nr_class;
/* 2650 */           localsvm_model.nSV = new int[k];
/* 2651 */           localObject = new StringTokenizer(str2);
/* 2652 */           for (m = 0; m < k; m++)
/* 2653 */             localsvm_model.nSV[m] = atoi(((StringTokenizer)localObject).nextToken());
/*      */         } else {
/* 2655 */           if (str1.startsWith("SV")) {
/*      */             break;
/*      */           }
/*      */           
/*      */ 
/*      */ 
/* 2661 */           System.err.print("unknown text in model file: [" + str1 + "]\n");
/* 2662 */           return null;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 2668 */     int i = localsvm_model.nr_class - 1;
/* 2669 */     int j = localsvm_model.l;
/* 2670 */     localsvm_model.sv_coef = new double[i][j];
/* 2671 */     localsvm_model.SV = new svm_node[j][];
/*      */     
/* 2673 */     for (int k = 0; k < j; k++)
/*      */     {
/* 2675 */       localObject = paramBufferedReader.readLine();
/* 2676 */       StringTokenizer localStringTokenizer = new StringTokenizer((String)localObject, " \t\n\r\f:");
/*      */       
/* 2678 */       for (int n = 0; n < i; n++)
/* 2679 */         localsvm_model.sv_coef[n][k] = atof(localStringTokenizer.nextToken());
/* 2680 */       n = localStringTokenizer.countTokens() / 2;
/* 2681 */       localsvm_model.SV[k] = new svm_node[n];
/* 2682 */       for (int i1 = 0; i1 < n; i1++)
/*      */       {
/* 2684 */         localsvm_model.SV[k][i1] = new svm_node();
/* 2685 */         localsvm_model.SV[k][i1].index = atoi(localStringTokenizer.nextToken());
/* 2686 */         localsvm_model.SV[k][i1].value = atof(localStringTokenizer.nextToken());
/*      */       }
/*      */     }
/*      */     
/* 2690 */     paramBufferedReader.close();
/* 2691 */     return localsvm_model;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static String svm_check_parameter(svm_problem paramsvm_problem, svm_parameter paramsvm_parameter)
/*      */   {
/* 2698 */     int i = paramsvm_parameter.svm_type;
/* 2699 */     if ((i != 0) && (i != 1) && (i != 2) && (i != 3) && (i != 4))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 2704 */       return "unknown svm type";
/*      */     }
/*      */     
/*      */ 
/* 2708 */     int j = paramsvm_parameter.kernel_type;
/* 2709 */     if ((j != 0) && (j != 1) && (j != 2) && (j != 3) && (j != 4))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 2714 */       return "unknown kernel type";
/*      */     }
/* 2716 */     if (paramsvm_parameter.gamma < 0.0D) {
/* 2717 */       return "gamma < 0";
/*      */     }
/* 2719 */     if (paramsvm_parameter.degree < 0) {
/* 2720 */       return "degree of polynomial kernel < 0";
/*      */     }
/*      */     
/*      */ 
/* 2724 */     if (paramsvm_parameter.cache_size <= 0.0D) {
/* 2725 */       return "cache_size <= 0";
/*      */     }
/* 2727 */     if (paramsvm_parameter.eps <= 0.0D) {
/* 2728 */       return "eps <= 0";
/*      */     }
/* 2730 */     if ((i == 0) || (i == 3) || (i == 4))
/*      */     {
/*      */ 
/* 2733 */       if (paramsvm_parameter.C <= 0.0D)
/* 2734 */         return "C <= 0";
/*      */     }
/* 2736 */     if ((i == 1) || (i == 2) || (i == 4))
/*      */     {
/*      */ 
/* 2739 */       if ((paramsvm_parameter.nu <= 0.0D) || (paramsvm_parameter.nu > 1.0D))
/* 2740 */         return "nu <= 0 or nu > 1";
/*      */     }
/* 2742 */     if ((i == 3) && 
/* 2743 */       (paramsvm_parameter.p < 0.0D)) {
/* 2744 */       return "p < 0";
/*      */     }
/* 2746 */     if ((paramsvm_parameter.shrinking != 0) && (paramsvm_parameter.shrinking != 1))
/*      */     {
/* 2748 */       return "shrinking != 0 and shrinking != 1";
/*      */     }
/* 2750 */     if ((paramsvm_parameter.probability != 0) && (paramsvm_parameter.probability != 1))
/*      */     {
/* 2752 */       return "probability != 0 and probability != 1";
/*      */     }
/* 2754 */     if ((paramsvm_parameter.probability == 1) && (i == 2))
/*      */     {
/* 2756 */       return "one-class SVM probability output not supported yet";
/*      */     }
/*      */     
/*      */ 
/* 2760 */     if (i == 1)
/*      */     {
/* 2762 */       int k = paramsvm_problem.l;
/* 2763 */       int m = 16;
/* 2764 */       int n = 0;
/* 2765 */       Object localObject1 = new int[m];
/* 2766 */       Object localObject2 = new int[m];
/*      */       int i2;
/*      */       int i3;
/* 2769 */       for (int i1 = 0; i1 < k; i1++)
/*      */       {
/* 2771 */         i2 = (int)paramsvm_problem.y[i1];
/*      */         
/* 2773 */         for (i3 = 0; i3 < n; i3++) {
/* 2774 */           if (i2 == localObject1[i3])
/*      */           {
/* 2776 */             localObject2[i3] += 1;
/* 2777 */             break;
/*      */           }
/*      */         }
/* 2780 */         if (i3 == n)
/*      */         {
/* 2782 */           if (n == m)
/*      */           {
/* 2784 */             m *= 2;
/* 2785 */             int[] arrayOfInt = new int[m];
/* 2786 */             System.arraycopy(localObject1, 0, arrayOfInt, 0, localObject1.length);
/* 2787 */             localObject1 = arrayOfInt;
/*      */             
/* 2789 */             arrayOfInt = new int[m];
/* 2790 */             System.arraycopy(localObject2, 0, arrayOfInt, 0, localObject2.length);
/* 2791 */             localObject2 = arrayOfInt;
/*      */           }
/* 2793 */           localObject1[n] = i2;
/* 2794 */           localObject2[n] = 1;
/* 2795 */           n++;
/*      */         }
/*      */       }
/*      */       
/* 2799 */       for (i1 = 0; i1 < n; i1++)
/*      */       {
/* 2801 */         i2 = localObject2[i1];
/* 2802 */         for (i3 = i1 + 1; i3 < n; i3++)
/*      */         {
/* 2804 */           int i4 = localObject2[i3];
/* 2805 */           if (paramsvm_parameter.nu * (i2 + i4) / 2.0D > Math.min(i2, i4)) {
/* 2806 */             return "specified nu is infeasible";
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 2811 */     return null;
/*      */   }
/*      */   
/*      */   public static int svm_check_probability_model(svm_model paramsvm_model)
/*      */   {
/* 2816 */     if (((paramsvm_model.param.svm_type != 0) && (paramsvm_model.param.svm_type != 1)) || (((paramsvm_model.probA != null) && (paramsvm_model.probB != null)) || (((paramsvm_model.param.svm_type == 3) || (paramsvm_model.param.svm_type == 4)) && (paramsvm_model.probA != null))))
/*      */     {
/*      */ 
/*      */ 
/* 2820 */       return 1;
/*      */     }
/* 2822 */     return 0;
/*      */   }
/*      */   
/*      */   public static void svm_set_print_string_function(svm_print_interface paramsvm_print_interface)
/*      */   {
/* 2827 */     if (paramsvm_print_interface == null) {
/* 2828 */       svm_print_string = svm_print_stdout;
/*      */     } else {
/* 2830 */       svm_print_string = paramsvm_print_interface;
/*      */     }
/*      */   }
/*      */   
/*      */   static class decision_function
/*      */   {
/*      */     double[] alpha;
/*      */     double rho;
/*      */   }
/*      */ }


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp10\Exp10.zip!\Exp10\lib\libsvm.jar!\libsvm\svm.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */