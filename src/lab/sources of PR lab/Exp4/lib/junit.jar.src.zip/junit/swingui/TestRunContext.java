package junit.swingui;

import javax.swing.ListModel;
import junit.framework.Test;

public abstract interface TestRunContext
{
  public abstract void handleTestSelected(Test paramTest);
  
  public abstract ListModel getFailures();
}


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp10\Exp10.zip!\Exp10\lib\junit.jar!\junit\swingui\TestRunContext.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */