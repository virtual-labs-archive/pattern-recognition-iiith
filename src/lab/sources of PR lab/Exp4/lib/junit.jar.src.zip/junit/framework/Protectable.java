package junit.framework;

public abstract interface Protectable
{
  public abstract void protect()
    throws Throwable;
}


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp10\Exp10.zip!\Exp10\lib\junit.jar!\junit\framework\Protectable.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */