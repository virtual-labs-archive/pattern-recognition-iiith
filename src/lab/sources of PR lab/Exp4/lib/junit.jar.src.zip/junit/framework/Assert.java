/*     */ package junit.framework;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Assert
/*     */ {
/*     */   public static void assertTrue(String message, boolean condition)
/*     */   {
/*  19 */     if (!condition) {
/*  20 */       fail(message);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public static void assertTrue(boolean condition)
/*     */   {
/*  27 */     assertTrue(null, condition);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void assertFalse(String message, boolean condition)
/*     */   {
/*  34 */     assertTrue(message, !condition);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void assertFalse(boolean condition)
/*     */   {
/*  41 */     assertFalse(null, condition);
/*     */   }
/*     */   
/*     */ 
/*     */   public static void fail(String message)
/*     */   {
/*  47 */     throw new AssertionFailedError(message);
/*     */   }
/*     */   
/*     */ 
/*     */   public static void fail()
/*     */   {
/*  53 */     fail(null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void assertEquals(String message, Object expected, Object actual)
/*     */   {
/*  60 */     if ((expected == null) && (actual == null))
/*  61 */       return;
/*  62 */     if ((expected != null) && (expected.equals(actual)))
/*  63 */       return;
/*  64 */     failNotEquals(message, expected, actual);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void assertEquals(Object expected, Object actual)
/*     */   {
/*  71 */     assertEquals(null, expected, actual);
/*     */   }
/*     */   
/*     */ 
/*     */   public static void assertEquals(String message, String expected, String actual)
/*     */   {
/*  77 */     if ((expected == null) && (actual == null))
/*  78 */       return;
/*  79 */     if ((expected != null) && (expected.equals(actual)))
/*  80 */       return;
/*  81 */     throw new ComparisonFailure(message, expected, actual);
/*     */   }
/*     */   
/*     */ 
/*     */   public static void assertEquals(String expected, String actual)
/*     */   {
/*  87 */     assertEquals(null, expected, actual);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertEquals(String message, double expected, double actual, double delta)
/*     */   {
/*  97 */     if (Double.isInfinite(expected)) {
/*  98 */       if (expected != actual)
/*  99 */         failNotEquals(message, new Double(expected), new Double(actual));
/* 100 */     } else if (Math.abs(expected - actual) > delta) {
/* 101 */       failNotEquals(message, new Double(expected), new Double(actual));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public static void assertEquals(double expected, double actual, double delta)
/*     */   {
/* 108 */     assertEquals(null, expected, actual, delta);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertEquals(String message, float expected, float actual, float delta)
/*     */   {
/* 118 */     if (Float.isInfinite(expected)) {
/* 119 */       if (expected != actual)
/* 120 */         failNotEquals(message, new Float(expected), new Float(actual));
/* 121 */     } else if (Math.abs(expected - actual) > delta) {
/* 122 */       failNotEquals(message, new Float(expected), new Float(actual));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public static void assertEquals(float expected, float actual, float delta)
/*     */   {
/* 129 */     assertEquals(null, expected, actual, delta);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void assertEquals(String message, long expected, long actual)
/*     */   {
/* 136 */     assertEquals(message, new Long(expected), new Long(actual));
/*     */   }
/*     */   
/*     */ 
/*     */   public static void assertEquals(long expected, long actual)
/*     */   {
/* 142 */     assertEquals(null, expected, actual);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void assertEquals(String message, boolean expected, boolean actual)
/*     */   {
/* 149 */     assertEquals(message, new Boolean(expected), new Boolean(actual));
/*     */   }
/*     */   
/*     */ 
/*     */   public static void assertEquals(boolean expected, boolean actual)
/*     */   {
/* 155 */     assertEquals(null, expected, actual);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void assertEquals(String message, byte expected, byte actual)
/*     */   {
/* 162 */     assertEquals(message, new Byte(expected), new Byte(actual));
/*     */   }
/*     */   
/*     */ 
/*     */   public static void assertEquals(byte expected, byte actual)
/*     */   {
/* 168 */     assertEquals(null, expected, actual);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void assertEquals(String message, char expected, char actual)
/*     */   {
/* 175 */     assertEquals(message, new Character(expected), new Character(actual));
/*     */   }
/*     */   
/*     */ 
/*     */   public static void assertEquals(char expected, char actual)
/*     */   {
/* 181 */     assertEquals(null, expected, actual);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void assertEquals(String message, short expected, short actual)
/*     */   {
/* 188 */     assertEquals(message, new Short(expected), new Short(actual));
/*     */   }
/*     */   
/*     */ 
/*     */   public static void assertEquals(short expected, short actual)
/*     */   {
/* 194 */     assertEquals(null, expected, actual);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void assertEquals(String message, int expected, int actual)
/*     */   {
/* 201 */     assertEquals(message, new Integer(expected), new Integer(actual));
/*     */   }
/*     */   
/*     */ 
/*     */   public static void assertEquals(int expected, int actual)
/*     */   {
/* 207 */     assertEquals(null, expected, actual);
/*     */   }
/*     */   
/*     */ 
/*     */   public static void assertNotNull(Object object)
/*     */   {
/* 213 */     assertNotNull(null, object);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void assertNotNull(String message, Object object)
/*     */   {
/* 220 */     assertTrue(message, object != null);
/*     */   }
/*     */   
/*     */ 
/*     */   public static void assertNull(Object object)
/*     */   {
/* 226 */     assertNull(null, object);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void assertNull(String message, Object object)
/*     */   {
/* 233 */     assertTrue(message, object == null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void assertSame(String message, Object expected, Object actual)
/*     */   {
/* 240 */     if (expected == actual)
/* 241 */       return;
/* 242 */     failNotSame(message, expected, actual);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void assertSame(Object expected, Object actual)
/*     */   {
/* 249 */     assertSame(null, expected, actual);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void assertNotSame(String message, Object expected, Object actual)
/*     */   {
/* 256 */     if (expected == actual) {
/* 257 */       failSame(message);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public static void assertNotSame(Object expected, Object actual)
/*     */   {
/* 264 */     assertNotSame(null, expected, actual);
/*     */   }
/*     */   
/*     */   private static void failSame(String message) {
/* 268 */     String formatted = "";
/* 269 */     if (message != null)
/* 270 */       formatted = message + " ";
/* 271 */     fail(formatted + "expected not same");
/*     */   }
/*     */   
/*     */   private static void failNotSame(String message, Object expected, Object actual) {
/* 275 */     String formatted = "";
/* 276 */     if (message != null)
/* 277 */       formatted = message + " ";
/* 278 */     fail(formatted + "expected same:<" + expected + "> was not:<" + actual + ">");
/*     */   }
/*     */   
/*     */   private static void failNotEquals(String message, Object expected, Object actual) {
/* 282 */     fail(format(message, expected, actual));
/*     */   }
/*     */   
/*     */   static String format(String message, Object expected, Object actual) {
/* 286 */     String formatted = "";
/* 287 */     if (message != null)
/* 288 */       formatted = message + " ";
/* 289 */     return formatted + "expected:<" + expected + "> but was:<" + actual + ">";
/*     */   }
/*     */ }


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp10\Exp10.zip!\Exp10\lib\junit.jar!\junit\framework\Assert.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */