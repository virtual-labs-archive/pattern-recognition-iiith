/*     */ package junit.framework;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TestCase
/*     */   extends Assert
/*     */   implements Test
/*     */ {
/*     */   private String fName;
/*     */   
/*     */   public TestCase()
/*     */   {
/*  81 */     this.fName = null;
/*     */   }
/*     */   
/*     */ 
/*     */   public TestCase(String name)
/*     */   {
/*  87 */     this.fName = name;
/*     */   }
/*     */   
/*     */ 
/*     */   public int countTestCases()
/*     */   {
/*  93 */     return 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected TestResult createResult()
/*     */   {
/* 101 */     return new TestResult();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TestResult run()
/*     */   {
/* 110 */     TestResult result = createResult();
/* 111 */     run(result);
/* 112 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   public void run(TestResult result)
/*     */   {
/* 118 */     result.run(this);
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public void runBare()
/*     */     throws Throwable
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: invokevirtual 46	junit/framework/TestCase:setUp	()V
/*     */     //   4: aload_0
/*     */     //   5: invokevirtual 49	junit/framework/TestCase:runTest	()V
/*     */     //   8: goto +9 -> 17
/*     */     //   11: astore_2
/*     */     //   12: jsr +11 -> 23
/*     */     //   15: aload_2
/*     */     //   16: athrow
/*     */     //   17: jsr +6 -> 23
/*     */     //   20: goto +10 -> 30
/*     */     //   23: astore_1
/*     */     //   24: aload_0
/*     */     //   25: invokevirtual 52	junit/framework/TestCase:tearDown	()V
/*     */     //   28: ret 1
/*     */     //   30: return
/*     */     // Line number table:
/*     */     //   Java source line #125	-> byte code offset #0
/*     */     //   Java source line #127	-> byte code offset #4
/*     */     //   Java source line #129	-> byte code offset #11
/*     */     //   Java source line #130	-> byte code offset #24
/*     */     //   Java source line #126	-> byte code offset #28
/*     */     //   Java source line #132	-> byte code offset #30
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	31	0	this	TestCase
/*     */     //   23	1	1	localObject1	Object
/*     */     //   11	5	2	localObject2	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   4	11	11	finally
/*     */   }
/*     */   
/*     */   protected void runTest()
/*     */     throws Throwable
/*     */   {
/* 138 */     Assert.assertNotNull(this.fName);
/* 139 */     Method runMethod = null;
/*     */     
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 145 */       runMethod = getClass().getMethod(this.fName, null);
/*     */     } catch (NoSuchMethodException e) {
/* 147 */       Assert.fail("Method \"" + this.fName + "\" not found");
/*     */     }
/* 149 */     if (!Modifier.isPublic(runMethod.getModifiers())) {
/* 150 */       Assert.fail("Method \"" + this.fName + "\" should be public");
/*     */     }
/*     */     try
/*     */     {
/* 154 */       runMethod.invoke(this, new Class[0]);
/*     */     }
/*     */     catch (InvocationTargetException e) {
/* 157 */       e.fillInStackTrace();
/* 158 */       throw e.getTargetException();
/*     */     }
/*     */     catch (IllegalAccessException e) {
/* 161 */       e.fillInStackTrace();
/* 162 */       throw e;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void setUp()
/*     */     throws Exception
/*     */   {}
/*     */   
/*     */ 
/*     */ 
/*     */   protected void tearDown()
/*     */     throws Exception
/*     */   {}
/*     */   
/*     */ 
/*     */   public String toString()
/*     */   {
/* 181 */     return getName() + "(" + getClass().getName() + ")";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/* 188 */     return this.fName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setName(String name)
/*     */   {
/* 195 */     this.fName = name;
/*     */   }
/*     */ }


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp10\Exp10.zip!\Exp10\lib\junit.jar!\junit\framework\TestCase.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */