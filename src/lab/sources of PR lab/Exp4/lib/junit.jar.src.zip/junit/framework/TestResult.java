/*     */ package junit.framework;
/*     */ 
/*     */ import java.util.Enumeration;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TestResult
/*     */ {
/*     */   protected Vector fFailures;
/*     */   protected Vector fErrors;
/*     */   protected Vector fListeners;
/*     */   protected int fRunTests;
/*     */   private boolean fStop;
/*     */   
/*     */   public TestResult()
/*     */   {
/*  23 */     this.fFailures = new Vector();
/*  24 */     this.fErrors = new Vector();
/*  25 */     this.fListeners = new Vector();
/*  26 */     this.fRunTests = 0;
/*  27 */     this.fStop = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public synchronized void addError(Test test, Throwable t)
/*     */   {
/*  34 */     this.fErrors.addElement(new TestFailure(test, t));
/*  35 */     for (Enumeration e = cloneListeners().elements(); e.hasMoreElements();) {
/*  36 */       ((TestListener)e.nextElement()).addError(test, t);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public synchronized void addFailure(Test test, AssertionFailedError t)
/*     */   {
/*  44 */     this.fFailures.addElement(new TestFailure(test, t));
/*  45 */     for (Enumeration e = cloneListeners().elements(); e.hasMoreElements();) {
/*  46 */       ((TestListener)e.nextElement()).addFailure(test, t);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public synchronized void addListener(TestListener listener)
/*     */   {
/*  53 */     this.fListeners.addElement(listener);
/*     */   }
/*     */   
/*     */ 
/*     */   public synchronized void removeListener(TestListener listener)
/*     */   {
/*  59 */     this.fListeners.removeElement(listener);
/*     */   }
/*     */   
/*     */ 
/*     */   private synchronized Vector cloneListeners()
/*     */   {
/*  65 */     return (Vector)this.fListeners.clone();
/*     */   }
/*     */   
/*     */ 
/*     */   public void endTest(Test test)
/*     */   {
/*  71 */     for (Enumeration e = cloneListeners().elements(); e.hasMoreElements();) {
/*  72 */       ((TestListener)e.nextElement()).endTest(test);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public synchronized int errorCount()
/*     */   {
/*  79 */     return this.fErrors.size();
/*     */   }
/*     */   
/*     */ 
/*     */   public synchronized Enumeration errors()
/*     */   {
/*  85 */     return this.fErrors.elements();
/*     */   }
/*     */   
/*     */ 
/*     */   public synchronized int failureCount()
/*     */   {
/*  91 */     return this.fFailures.size();
/*     */   }
/*     */   
/*     */ 
/*     */   public synchronized Enumeration failures()
/*     */   {
/*  97 */     return this.fFailures.elements();
/*     */   }
/*     */   
/*     */ 
/*     */   protected void run(TestCase test)
/*     */   {
/* 103 */     startTest(test);
/* 104 */     Protectable p = new Protectable() {
/*     */       public void protect() throws Throwable {
/* 106 */         TestResult.this.runBare();
/*     */       }
/* 108 */     };
/* 109 */     runProtected(test, p);
/*     */     
/* 111 */     endTest(test);
/*     */   }
/*     */   
/*     */ 
/*     */   public synchronized int runCount()
/*     */   {
/* 117 */     return this.fRunTests;
/*     */   }
/*     */   
/*     */   public void runProtected(Test test, Protectable p)
/*     */   {
/*     */     try
/*     */     {
/* 124 */       p.protect();
/*     */     }
/*     */     catch (AssertionFailedError e) {
/* 127 */       addFailure(test, e);
/*     */     }
/*     */     catch (ThreadDeath e) {
/* 130 */       throw e;
/*     */     }
/*     */     catch (Throwable e) {
/* 133 */       addError(test, e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public synchronized boolean shouldStop()
/*     */   {
/* 140 */     return this.fStop;
/*     */   }
/*     */   
/*     */ 
/*     */   public void startTest(Test test)
/*     */   {
/* 146 */     int count = test.countTestCases();
/* 147 */     synchronized (this) {
/* 148 */       this.fRunTests += count;
/*     */     }
/* 150 */     for (Enumeration e = cloneListeners().elements(); e.hasMoreElements();) {
/* 151 */       ((TestListener)e.nextElement()).startTest(test);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public synchronized void stop()
/*     */   {
/* 158 */     this.fStop = true;
/*     */   }
/*     */   
/*     */ 
/*     */   public synchronized boolean wasSuccessful()
/*     */   {
/* 164 */     return (failureCount() == 0) && (errorCount() == 0);
/*     */   }
/*     */ }


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp10\Exp10.zip!\Exp10\lib\junit.jar!\junit\framework\TestResult.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */