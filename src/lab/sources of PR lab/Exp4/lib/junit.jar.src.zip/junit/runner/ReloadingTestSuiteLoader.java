/*    */ package junit.runner;
/*    */ 
/*    */ public class ReloadingTestSuiteLoader
/*    */   implements TestSuiteLoader
/*    */ {
/*    */   public Class load(String suiteClassName)
/*    */     throws ClassNotFoundException
/*    */   {
/*  9 */     return createLoader().loadClass(suiteClassName, true);
/*    */   }
/*    */   
/*    */   public Class reload(Class aClass) throws ClassNotFoundException {
/* 13 */     return createLoader().loadClass(aClass.getName(), true);
/*    */   }
/*    */   
/*    */   protected TestCaseClassLoader createLoader() {
/* 17 */     return new TestCaseClassLoader();
/*    */   }
/*    */ }


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp10\Exp10.zip!\Exp10\lib\junit.jar!\junit\runner\ReloadingTestSuiteLoader.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */