package junit.runner;

import java.awt.Component;
import junit.framework.TestFailure;

public abstract interface FailureDetailView
{
  public abstract Component getComponent();
  
  public abstract void showFailure(TestFailure paramTestFailure);
  
  public abstract void clear();
}


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp10\Exp10.zip!\Exp10\lib\junit.jar!\junit\runner\FailureDetailView.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */