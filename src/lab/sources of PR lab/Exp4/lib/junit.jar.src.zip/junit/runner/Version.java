/*    */ package junit.runner;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Version
/*    */ {
/*    */   public static String id()
/*    */   {
/* 12 */     return "3.8.1";
/*    */   }
/*    */ }


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp10\Exp10.zip!\Exp10\lib\junit.jar!\junit\runner\Version.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */