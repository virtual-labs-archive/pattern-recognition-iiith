package junit.runner;

public abstract interface TestRunListener
{
  public static final int STATUS_ERROR = 1;
  public static final int STATUS_FAILURE = 2;
  
  public abstract void testRunStarted(String paramString, int paramInt);
  
  public abstract void testRunEnded(long paramLong);
  
  public abstract void testRunStopped(long paramLong);
  
  public abstract void testStarted(String paramString);
  
  public abstract void testEnded(String paramString);
  
  public abstract void testFailed(int paramInt, String paramString1, String paramString2);
}


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp10\Exp10.zip!\Exp10\lib\junit.jar!\junit\runner\TestRunListener.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */