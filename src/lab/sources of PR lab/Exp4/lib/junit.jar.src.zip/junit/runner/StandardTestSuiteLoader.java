/*    */ package junit.runner;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StandardTestSuiteLoader
/*    */   implements TestSuiteLoader
/*    */ {
/*    */   public Class load(String suiteClassName)
/*    */     throws ClassNotFoundException
/*    */   {
/* 11 */     return Class.forName(suiteClassName);
/*    */   }
/*    */   
/*    */   public Class reload(Class aClass)
/*    */     throws ClassNotFoundException
/*    */   {
/* 17 */     return aClass;
/*    */   }
/*    */ }


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp10\Exp10.zip!\Exp10\lib\junit.jar!\junit\runner\StandardTestSuiteLoader.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */