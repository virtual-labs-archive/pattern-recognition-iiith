/*     */ package junit.runner;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Properties;
/*     */ import junit.framework.AssertionFailedError;
/*     */ import junit.framework.Test;
/*     */ 
/*     */ public abstract class BaseTestRunner implements junit.framework.TestListener
/*     */ {
/*  18 */   static boolean fgFilterStack = true;
/*  19 */   boolean fLoading = true;
/*     */   
/*     */ 
/*     */ 
/*     */   public synchronized void startTest(Test test)
/*     */   {
/*  25 */     testStarted(test.toString());
/*     */   }
/*     */   
/*     */   protected static void setPreferences(Properties preferences) {
/*  29 */     fPreferences = preferences;
/*     */   }
/*     */   
/*     */   protected static Properties getPreferences() {
/*  33 */     if (fPreferences == null) {
/*  34 */       fPreferences = new Properties();
/*  35 */       fPreferences.put("loading", "true");
/*  36 */       fPreferences.put("filterstack", "true");
/*  37 */       readPreferences();
/*     */     }
/*  39 */     return fPreferences;
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public static void savePreferences()
/*     */     throws IOException
/*     */   {
/*     */     // Byte code:
/*     */     //   0: new 83	java/io/FileOutputStream
/*     */     //   3: dup
/*     */     //   4: invokestatic 87	junit/runner/BaseTestRunner:getPreferencesFile	()Ljava/io/File;
/*     */     //   7: invokespecial 90	java/io/FileOutputStream:<init>	(Ljava/io/File;)V
/*     */     //   10: astore_0
/*     */     //   11: invokestatic 92	junit/runner/BaseTestRunner:getPreferences	()Ljava/util/Properties;
/*     */     //   14: aload_0
/*     */     //   15: ldc 94
/*     */     //   17: invokevirtual 98	java/util/Properties:store	(Ljava/io/OutputStream;Ljava/lang/String;)V
/*     */     //   20: goto +9 -> 29
/*     */     //   23: astore_2
/*     */     //   24: jsr +11 -> 35
/*     */     //   27: aload_2
/*     */     //   28: athrow
/*     */     //   29: jsr +6 -> 35
/*     */     //   32: goto +10 -> 42
/*     */     //   35: astore_1
/*     */     //   36: aload_0
/*     */     //   37: invokevirtual 101	java/io/FileOutputStream:close	()V
/*     */     //   40: ret 1
/*     */     //   42: return
/*     */     // Line number table:
/*     */     //   Java source line #43	-> byte code offset #0
/*     */     //   Java source line #45	-> byte code offset #11
/*     */     //   Java source line #46	-> byte code offset #23
/*     */     //   Java source line #47	-> byte code offset #36
/*     */     //   Java source line #44	-> byte code offset #40
/*     */     //   Java source line #49	-> byte code offset #42
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   10	27	0	fos	java.io.FileOutputStream
/*     */     //   35	1	1	localObject1	Object
/*     */     //   23	5	2	localObject2	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   11	23	23	finally
/*     */   }
/*     */   
/*     */   public void setPreference(String key, String value)
/*     */   {
/*  52 */     getPreferences().setProperty(key, value);
/*     */   }
/*     */   
/*     */   public synchronized void endTest(Test test) {
/*  56 */     testEnded(test.toString());
/*     */   }
/*     */   
/*     */   public synchronized void addError(Test test, Throwable t) {
/*  60 */     testFailed(1, test, t);
/*     */   }
/*     */   
/*     */   public synchronized void addFailure(Test test, AssertionFailedError t) {
/*  64 */     testFailed(2, test, t);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public abstract void testStarted(String paramString);
/*     */   
/*     */ 
/*     */   public abstract void testEnded(String paramString);
/*     */   
/*     */ 
/*     */   public abstract void testFailed(int paramInt, Test paramTest, Throwable paramThrowable);
/*     */   
/*     */ 
/*     */   public Test getTest(String suiteClassName)
/*     */   {
/*  80 */     if (suiteClassName.length() <= 0) {
/*  81 */       clearStatus();
/*  82 */       return null;
/*     */     }
/*  84 */     Class testClass = null;
/*     */     try {
/*  86 */       testClass = loadSuiteClass(suiteClassName);
/*     */     } catch (ClassNotFoundException e) {
/*  88 */       String clazz = e.getMessage();
/*  89 */       if (clazz == null)
/*  90 */         clazz = suiteClassName;
/*  91 */       runFailed("Class not found \"" + clazz + "\"");
/*  92 */       return null;
/*     */     } catch (Exception e) {
/*  94 */       runFailed("Error: " + e.toString());
/*  95 */       return null;
/*     */     }
/*  97 */     Method suiteMethod = null;
/*     */     try {
/*  99 */       suiteMethod = testClass.getMethod("suite", new Class[0]);
/*     */     }
/*     */     catch (Exception e) {
/* 102 */       clearStatus();
/* 103 */       return new junit.framework.TestSuite(testClass);
/*     */     }
/* 105 */     if (!java.lang.reflect.Modifier.isStatic(suiteMethod.getModifiers())) {
/* 106 */       runFailed("Suite() method must be static");
/* 107 */       return null;
/*     */     }
/* 109 */     Test test = null;
/*     */     try {
/* 111 */       test = (Test)suiteMethod.invoke(null, new Class[0]);
/* 112 */       if (test == null) {
/* 113 */         return test;
/*     */       }
/*     */     } catch (InvocationTargetException e) {
/* 116 */       runFailed("Failed to invoke suite():" + e.getTargetException().toString());
/* 117 */       return null;
/*     */     }
/*     */     catch (IllegalAccessException e) {
/* 120 */       runFailed("Failed to invoke suite():" + e.toString());
/* 121 */       return null;
/*     */     }
/*     */     
/* 124 */     clearStatus();
/* 125 */     return test;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String elapsedTimeAsString(long runTime)
/*     */   {
/* 132 */     return java.text.NumberFormat.getInstance().format(runTime / 1000.0D);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String processArguments(String[] args)
/*     */   {
/* 140 */     String suiteName = null;
/* 141 */     for (int i = 0; i < args.length; i++) {
/* 142 */       if (args[i].equals("-noloading")) {
/* 143 */         setLoading(false);
/* 144 */       } else if (args[i].equals("-nofilterstack")) {
/* 145 */         fgFilterStack = false;
/* 146 */       } else if (args[i].equals("-c")) {
/* 147 */         if (args.length > i + 1) {
/* 148 */           suiteName = extractClassName(args[(i + 1)]);
/*     */         } else
/* 150 */           System.out.println("Missing Test class name");
/* 151 */         i++;
/*     */       } else {
/* 153 */         suiteName = args[i];
/*     */       }
/*     */     }
/* 156 */     return suiteName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setLoading(boolean enable)
/*     */   {
/* 163 */     this.fLoading = enable;
/*     */   }
/*     */   
/*     */ 
/*     */   public String extractClassName(String className)
/*     */   {
/* 169 */     if (className.startsWith("Default package for"))
/* 170 */       return className.substring(className.lastIndexOf(".") + 1);
/* 171 */     return className;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static String truncate(String s)
/*     */   {
/* 178 */     if ((fgMaxMessageLength != -1) && (s.length() > fgMaxMessageLength))
/* 179 */       s = s.substring(0, fgMaxMessageLength) + "...";
/* 180 */     return s;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract void runFailed(String paramString);
/*     */   
/*     */ 
/*     */ 
/*     */   protected Class loadSuiteClass(String suiteClassName)
/*     */     throws ClassNotFoundException
/*     */   {
/* 193 */     return getLoader().load(suiteClassName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void clearStatus() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public TestSuiteLoader getLoader()
/*     */   {
/* 206 */     if (useReloadingTestSuiteLoader())
/* 207 */       return new ReloadingTestSuiteLoader();
/* 208 */     return new StandardTestSuiteLoader();
/*     */   }
/*     */   
/*     */   protected boolean useReloadingTestSuiteLoader() {
/* 212 */     return (getPreference("loading").equals("true")) && (!inVAJava()) && (this.fLoading);
/*     */   }
/*     */   
/*     */   private static File getPreferencesFile() {
/* 216 */     String home = System.getProperty("user.home");
/* 217 */     return new File(home, "junit.properties");
/*     */   }
/*     */   
/*     */   private static void readPreferences() {
/* 221 */     InputStream is = null;
/*     */     try {
/* 223 */       is = new java.io.FileInputStream(getPreferencesFile());
/* 224 */       setPreferences(new Properties(getPreferences()));
/* 225 */       getPreferences().load(is);
/*     */     } catch (IOException e) {
/*     */       try {
/* 228 */         if (is != null) {
/* 229 */           is.close();
/*     */         }
/*     */       } catch (IOException localIOException1) {}
/*     */     }
/*     */   }
/*     */   
/*     */   public static String getPreference(String key) {
/* 236 */     return getPreferences().getProperty(key);
/*     */   }
/*     */   
/*     */   public static int getPreference(String key, int dflt) {
/* 240 */     String value = getPreference(key);
/* 241 */     int intValue = dflt;
/* 242 */     if (value == null)
/* 243 */       return intValue;
/*     */     try {
/* 245 */       intValue = Integer.parseInt(value);
/*     */     }
/*     */     catch (NumberFormatException localNumberFormatException) {}
/* 248 */     return intValue;
/*     */   }
/*     */   
/*     */   public static boolean inVAJava() {
/*     */     try {
/* 253 */       Class.forName("com.ibm.uvm.tools.DebugSupport");
/*     */     }
/*     */     catch (Exception e) {
/* 256 */       return false;
/*     */     }
/* 258 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static String getFilteredTrace(Throwable t)
/*     */   {
/* 265 */     StringWriter stringWriter = new StringWriter();
/* 266 */     PrintWriter writer = new PrintWriter(stringWriter);
/* 267 */     t.printStackTrace(writer);
/* 268 */     StringBuffer buffer = stringWriter.getBuffer();
/* 269 */     String trace = buffer.toString();
/* 270 */     return getFilteredTrace(trace);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static String getFilteredTrace(String stack)
/*     */   {
/* 277 */     if (showStackRaw()) {
/* 278 */       return stack;
/*     */     }
/* 280 */     StringWriter sw = new StringWriter();
/* 281 */     PrintWriter pw = new PrintWriter(sw);
/* 282 */     java.io.StringReader sr = new java.io.StringReader(stack);
/* 283 */     BufferedReader br = new BufferedReader(sr);
/*     */     try
/*     */     {
/*     */       String line;
/* 287 */       while ((line = br.readLine()) != null) { String line;
/* 288 */         if (!filterLine(line))
/* 289 */           pw.println(line);
/*     */       }
/*     */     } catch (Exception IOException) {
/* 292 */       return stack; }
/*     */     String line;
/* 294 */     return sw.toString();
/*     */   }
/*     */   
/*     */   protected static boolean showStackRaw() {
/* 298 */     return (!getPreference("filterstack").equals("true")) || (!fgFilterStack);
/*     */   }
/*     */   
/*     */   static boolean filterLine(String line) {
/* 302 */     String[] patterns = {
/* 303 */       "junit.framework.TestCase", 
/* 304 */       "junit.framework.TestResult", 
/* 305 */       "junit.framework.TestSuite", 
/* 306 */       "junit.framework.Assert.", 
/* 307 */       "junit.swingui.TestRunner", 
/* 308 */       "junit.awtui.TestRunner", 
/* 309 */       "junit.textui.TestRunner", 
/* 310 */       "java.lang.reflect.Method.invoke(" };
/*     */     
/* 312 */     for (int i = 0; i < patterns.length; i++) {
/* 313 */       if (line.indexOf(patterns[i]) > 0)
/* 314 */         return true;
/*     */     }
/* 316 */     return false;
/*     */   }
/*     */   
/*     */ 
/* 320 */   static int fgMaxMessageLength = getPreference("maxmessage", fgMaxMessageLength);
/*     */   public static final String SUITE_METHODNAME = "suite";
/*     */   private static Properties fPreferences;
/*     */ }


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp10\Exp10.zip!\Exp10\lib\junit.jar!\junit\runner\BaseTestRunner.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */