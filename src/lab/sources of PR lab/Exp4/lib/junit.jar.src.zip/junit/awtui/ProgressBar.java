/*    */ package junit.awtui;
/*    */ 
/*    */ import java.awt.Rectangle;
/*    */ 
/*    */ public class ProgressBar extends java.awt.Canvas {
/*  6 */   public boolean fError = false;
/*  7 */   public int fTotal = 0;
/*  8 */   public int fProgress = 0;
/*  9 */   public int fProgressX = 0;
/*    */   
/*    */   public ProgressBar()
/*    */   {
/* 13 */     setSize(20, 30);
/*    */   }
/*    */   
/*    */   private java.awt.Color getStatusColor() {
/* 17 */     if (this.fError)
/* 18 */       return java.awt.Color.red;
/* 19 */     return java.awt.Color.green;
/*    */   }
/*    */   
/*    */   public void paint(java.awt.Graphics g) {
/* 23 */     paintBackground(g);
/* 24 */     paintStatus(g);
/*    */   }
/*    */   
/*    */   public void paintBackground(java.awt.Graphics g) {
/* 28 */     g.setColor(java.awt.SystemColor.control);
/* 29 */     Rectangle r = getBounds();
/* 30 */     g.fillRect(0, 0, r.width, r.height);
/* 31 */     g.setColor(java.awt.Color.darkGray);
/* 32 */     g.drawLine(0, 0, r.width - 1, 0);
/* 33 */     g.drawLine(0, 0, 0, r.height - 1);
/* 34 */     g.setColor(java.awt.Color.white);
/* 35 */     g.drawLine(r.width - 1, 0, r.width - 1, r.height - 1);
/* 36 */     g.drawLine(0, r.height - 1, r.width - 1, r.height - 1);
/*    */   }
/*    */   
/*    */   public void paintStatus(java.awt.Graphics g) {
/* 40 */     g.setColor(getStatusColor());
/* 41 */     Rectangle r = new Rectangle(0, 0, this.fProgressX, getBounds().height);
/* 42 */     g.fillRect(1, 1, r.width - 1, r.height - 2);
/*    */   }
/*    */   
/*    */   private void paintStep(int startX, int endX) {
/* 46 */     repaint(startX, 1, endX - startX, getBounds().height - 2);
/*    */   }
/*    */   
/*    */   public void reset() {
/* 50 */     this.fProgressX = 1;
/* 51 */     this.fProgress = 0;
/* 52 */     this.fError = false;
/* 53 */     paint(getGraphics());
/*    */   }
/*    */   
/*    */   public int scale(int value) {
/* 57 */     if (this.fTotal > 0)
/* 58 */       return Math.max(1, value * (getBounds().width - 1) / this.fTotal);
/* 59 */     return value;
/*    */   }
/*    */   
/*    */   public void setBounds(int x, int y, int w, int h) {
/* 63 */     super.setBounds(x, y, w, h);
/* 64 */     this.fProgressX = scale(this.fProgress);
/*    */   }
/*    */   
/*    */   public void start(int total) {
/* 68 */     this.fTotal = total;
/* 69 */     reset();
/*    */   }
/*    */   
/*    */   public void step(boolean successful) {
/* 73 */     this.fProgress += 1;
/* 74 */     int x = this.fProgressX;
/*    */     
/* 76 */     this.fProgressX = scale(this.fProgress);
/*    */     
/* 78 */     if ((!this.fError) && (!successful)) {
/* 79 */       this.fError = true;
/* 80 */       x = 1;
/*    */     }
/* 82 */     paintStep(x, this.fProgressX);
/*    */   }
/*    */ }


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp10\Exp10.zip!\Exp10\lib\junit.jar!\junit\awtui\ProgressBar.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */