/*    */ package junit.runner;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SimpleTestCollector
/*    */   extends ClassPathTestCollector
/*    */ {
/*    */   protected boolean isTestClass(String classFileName)
/*    */   {
/* 16 */     return (classFileName.endsWith(".class")) && 
/* 17 */       (classFileName.indexOf('$') < 0) && 
/* 18 */       (classFileName.indexOf("Test") > 0);
/*    */   }
/*    */ }


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp1\Exp1 (1).zip!\Exp1\lib\junit.jar!\junit\runner\SimpleTestCollector.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */