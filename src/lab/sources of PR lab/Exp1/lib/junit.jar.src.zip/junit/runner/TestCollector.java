package junit.runner;

import java.util.Enumeration;

public abstract interface TestCollector
{
  public abstract Enumeration collectTests();
}


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp1\Exp1 (1).zip!\Exp1\lib\junit.jar!\junit\runner\TestCollector.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */