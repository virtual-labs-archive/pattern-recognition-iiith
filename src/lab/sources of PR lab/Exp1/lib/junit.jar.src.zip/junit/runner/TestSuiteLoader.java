package junit.runner;

public abstract interface TestSuiteLoader
{
  public abstract Class load(String paramString)
    throws ClassNotFoundException;
  
  public abstract Class reload(Class paramClass)
    throws ClassNotFoundException;
}


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp1\Exp1 (1).zip!\Exp1\lib\junit.jar!\junit\runner\TestSuiteLoader.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */