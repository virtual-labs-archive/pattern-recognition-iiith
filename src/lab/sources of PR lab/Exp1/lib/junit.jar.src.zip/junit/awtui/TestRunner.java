/*     */ package junit.awtui;
/*     */ 
/*     */ import java.awt.Button;
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.Frame;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Label;
/*     */ import java.awt.List;
/*     */ import java.awt.Menu;
/*     */ import java.awt.Panel;
/*     */ import java.awt.TextComponent;
/*     */ import java.awt.TextField;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.util.Vector;
/*     */ import junit.framework.Test;
/*     */ import junit.framework.TestResult;
/*     */ import junit.runner.BaseTestRunner;
/*     */ 
/*     */ public class TestRunner extends BaseTestRunner
/*     */ {
/*     */   protected Frame fFrame;
/*     */   protected Vector fExceptions;
/*     */   protected Vector fFailedTests;
/*     */   protected Thread fRunner;
/*     */   protected TestResult fTestResult;
/*     */   protected java.awt.TextArea fTraceArea;
/*     */   protected TextField fSuiteField;
/*     */   protected Button fRun;
/*     */   protected ProgressBar fProgressIndicator;
/*     */   protected List fFailureList;
/*     */   protected Logo fLogo;
/*     */   protected Label fNumberOfErrors;
/*     */   protected Label fNumberOfFailures;
/*     */   protected Label fNumberOfRuns;
/*     */   protected Button fQuitButton;
/*     */   protected Button fRerunButton;
/*     */   protected TextField fStatusLine;
/*     */   protected java.awt.Checkbox fUseLoadingRunner;
/*  41 */   protected static final java.awt.Font PLAIN_FONT = new java.awt.Font("dialog", 0, 12);
/*     */   
/*     */   private static final int GAP = 4;
/*     */   
/*     */ 
/*     */   private void about()
/*     */   {
/*  48 */     AboutDialog about = new AboutDialog(this.fFrame);
/*  49 */     about.setModal(true);
/*  50 */     about.setLocation(300, 300);
/*  51 */     about.setVisible(true);
/*     */   }
/*     */   
/*     */   public void testStarted(String testName) {
/*  55 */     showInfo("Running: " + testName);
/*     */   }
/*     */   
/*     */   public void testEnded(String testName) {
/*  59 */     setLabelValue(this.fNumberOfRuns, this.fTestResult.runCount());
/*  60 */     synchronized (this) {
/*  61 */       this.fProgressIndicator.step(this.fTestResult.wasSuccessful());
/*     */     }
/*     */   }
/*     */   
/*     */   public void testFailed(int status, Test test, Throwable t) {
/*  66 */     switch (status) {
/*     */     case 1: 
/*  68 */       this.fNumberOfErrors.setText(Integer.toString(this.fTestResult.errorCount()));
/*  69 */       appendFailure("Error", test, t);
/*  70 */       break;
/*     */     case 2: 
/*  72 */       this.fNumberOfFailures.setText(Integer.toString(this.fTestResult.failureCount()));
/*  73 */       appendFailure("Failure", test, t);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addGrid(Panel p, Component co, int x, int y, int w, int fill, double wx, int anchor)
/*     */   {
/*  79 */     java.awt.GridBagConstraints c = new java.awt.GridBagConstraints();
/*  80 */     c.gridx = x;c.gridy = y;
/*  81 */     c.gridwidth = w;
/*  82 */     c.anchor = anchor;
/*  83 */     c.weightx = wx;
/*  84 */     c.fill = fill;
/*  85 */     if ((fill == 1) || (fill == 3))
/*  86 */       c.weighty = 1.0D;
/*  87 */     c.insets = new Insets(y == 0 ? 4 : 0, x == 0 ? 4 : 0, 4, 4);
/*  88 */     p.add(co, c);
/*     */   }
/*     */   
/*     */   private void appendFailure(String kind, Test test, Throwable t) {
/*  92 */     kind = kind + ": " + test;
/*  93 */     String msg = t.getMessage();
/*  94 */     if (msg != null) {
/*  95 */       kind = kind + ":" + BaseTestRunner.truncate(msg);
/*     */     }
/*  97 */     this.fFailureList.add(kind);
/*  98 */     this.fExceptions.addElement(t);
/*  99 */     this.fFailedTests.addElement(test);
/* 100 */     if (this.fFailureList.getItemCount() == 1) {
/* 101 */       this.fFailureList.select(0);
/* 102 */       failureSelected();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected Menu createJUnitMenu()
/*     */   {
/* 110 */     Menu menu = new Menu("JUnit");
/* 111 */     java.awt.MenuItem mi = new java.awt.MenuItem("About...");
/* 112 */     mi.addActionListener(
/* 113 */       new ActionListener() {
/*     */         public void actionPerformed(ActionEvent event) {
/* 115 */           TestRunner.this.about();
/*     */         }
/*     */         
/* 118 */       });
/* 119 */     menu.add(mi);
/*     */     
/* 121 */     menu.addSeparator();
/* 122 */     mi = new java.awt.MenuItem("Exit");
/* 123 */     mi.addActionListener(
/* 124 */       new ActionListener() {
/*     */         public void actionPerformed(ActionEvent event) {
/* 126 */           System.exit(0);
/*     */         }
/*     */         
/* 129 */       });
/* 130 */     menu.add(mi);
/* 131 */     return menu;
/*     */   }
/*     */   
/*     */   protected void createMenus(java.awt.MenuBar mb) {
/* 135 */     mb.add(createJUnitMenu());
/*     */   }
/*     */   
/* 138 */   protected TestResult createTestResult() { return new TestResult(); }
/*     */   
/*     */   protected Frame createUI(String suiteName)
/*     */   {
/* 142 */     Frame frame = new Frame("JUnit");
/* 143 */     java.awt.Image icon = loadFrameIcon();
/* 144 */     if (icon != null) {
/* 145 */       frame.setIconImage(icon);
/*     */     }
/* 147 */     frame.setLayout(new java.awt.BorderLayout(0, 0));
/* 148 */     frame.setBackground(java.awt.SystemColor.control);
/* 149 */     Frame finalFrame = frame;
/*     */     
/* 151 */     frame.addWindowListener(
/* 152 */       new java.awt.event.WindowAdapter() {
/*     */         public void windowClosing(java.awt.event.WindowEvent e) {
/* 154 */           TestRunner.this.dispose();
/* 155 */           System.exit(0);
/*     */         }
/*     */         
/*     */ 
/* 159 */       });
/* 160 */     java.awt.MenuBar mb = new java.awt.MenuBar();
/* 161 */     createMenus(mb);
/* 162 */     frame.setMenuBar(mb);
/*     */     
/*     */ 
/* 165 */     Label suiteLabel = new Label("Test class name:");
/*     */     
/* 167 */     this.fSuiteField = new TextField(suiteName != null ? suiteName : "");
/* 168 */     this.fSuiteField.selectAll();
/* 169 */     this.fSuiteField.requestFocus();
/* 170 */     this.fSuiteField.setFont(PLAIN_FONT);
/* 171 */     this.fSuiteField.setColumns(40);
/* 172 */     this.fSuiteField.addActionListener(
/* 173 */       new ActionListener() {
/*     */         public void actionPerformed(ActionEvent e) {
/* 175 */           TestRunner.this.runSuite();
/*     */         }
/*     */         
/* 178 */       });
/* 179 */     this.fSuiteField.addTextListener(
/* 180 */       new java.awt.event.TextListener() {
/*     */         public void textValueChanged(java.awt.event.TextEvent e) {
/* 182 */           TestRunner.this.fRun.setEnabled(TestRunner.this.fSuiteField.getText().length() > 0);
/* 183 */           TestRunner.this.fStatusLine.setText("");
/*     */         }
/*     */         
/* 186 */       });
/* 187 */     this.fRun = new Button("Run");
/* 188 */     this.fRun.setEnabled(false);
/* 189 */     this.fRun.addActionListener(
/* 190 */       new ActionListener() {
/*     */         public void actionPerformed(ActionEvent e) {
/* 192 */           TestRunner.this.runSuite();
/*     */         }
/*     */         
/* 195 */       });
/* 196 */     boolean useLoader = useReloadingTestSuiteLoader();
/* 197 */     this.fUseLoadingRunner = new java.awt.Checkbox("Reload classes every run", useLoader);
/* 198 */     if (BaseTestRunner.inVAJava()) {
/* 199 */       this.fUseLoadingRunner.setVisible(false);
/*     */     }
/*     */     
/* 202 */     this.fProgressIndicator = new ProgressBar();
/*     */     
/*     */ 
/* 205 */     this.fNumberOfErrors = new Label("0000", 2);
/* 206 */     this.fNumberOfErrors.setText("0");
/* 207 */     this.fNumberOfErrors.setFont(PLAIN_FONT);
/*     */     
/* 209 */     this.fNumberOfFailures = new Label("0000", 2);
/* 210 */     this.fNumberOfFailures.setText("0");
/* 211 */     this.fNumberOfFailures.setFont(PLAIN_FONT);
/*     */     
/* 213 */     this.fNumberOfRuns = new Label("0000", 2);
/* 214 */     this.fNumberOfRuns.setText("0");
/* 215 */     this.fNumberOfRuns.setFont(PLAIN_FONT);
/*     */     
/* 217 */     Panel numbersPanel = createCounterPanel();
/*     */     
/*     */ 
/* 220 */     Label failureLabel = new Label("Errors and Failures:");
/*     */     
/* 222 */     this.fFailureList = new List(5);
/* 223 */     this.fFailureList.addItemListener(
/* 224 */       new java.awt.event.ItemListener() {
/*     */         public void itemStateChanged(java.awt.event.ItemEvent e) {
/* 226 */           TestRunner.this.failureSelected();
/*     */         }
/*     */         
/* 229 */       });
/* 230 */     this.fRerunButton = new Button("Run");
/* 231 */     this.fRerunButton.setEnabled(false);
/* 232 */     this.fRerunButton.addActionListener(
/* 233 */       new ActionListener() {
/*     */         public void actionPerformed(ActionEvent e) {
/* 235 */           TestRunner.this.rerun();
/*     */         }
/*     */         
/*     */ 
/* 239 */       });
/* 240 */     Panel failedPanel = new Panel(new java.awt.GridLayout(0, 1, 0, 2));
/* 241 */     failedPanel.add(this.fRerunButton);
/*     */     
/* 243 */     this.fTraceArea = new java.awt.TextArea();
/* 244 */     this.fTraceArea.setRows(5);
/* 245 */     this.fTraceArea.setColumns(60);
/*     */     
/*     */ 
/* 248 */     this.fStatusLine = new TextField();
/* 249 */     this.fStatusLine.setFont(PLAIN_FONT);
/* 250 */     this.fStatusLine.setEditable(false);
/* 251 */     this.fStatusLine.setForeground(java.awt.Color.red);
/*     */     
/* 253 */     this.fQuitButton = new Button("Exit");
/* 254 */     this.fQuitButton.addActionListener(
/* 255 */       new ActionListener() {
/*     */         public void actionPerformed(ActionEvent e) {
/* 257 */           System.exit(0);
/*     */ 
/*     */         }
/*     */         
/*     */ 
/* 262 */       });
/* 263 */     this.fLogo = new Logo();
/*     */     
/*     */ 
/* 266 */     Panel panel = new Panel(new java.awt.GridBagLayout());
/*     */     
/* 268 */     addGrid(panel, suiteLabel, 0, 0, 2, 2, 1.0D, 17);
/*     */     
/* 270 */     addGrid(panel, this.fSuiteField, 0, 1, 2, 2, 1.0D, 17);
/* 271 */     addGrid(panel, this.fRun, 2, 1, 1, 2, 0.0D, 10);
/* 272 */     addGrid(panel, this.fUseLoadingRunner, 0, 2, 2, 0, 1.0D, 17);
/* 273 */     addGrid(panel, this.fProgressIndicator, 0, 3, 2, 2, 1.0D, 17);
/* 274 */     addGrid(panel, this.fLogo, 2, 3, 1, 0, 0.0D, 11);
/*     */     
/* 276 */     addGrid(panel, numbersPanel, 0, 4, 2, 0, 0.0D, 17);
/*     */     
/* 278 */     addGrid(panel, failureLabel, 0, 5, 2, 2, 1.0D, 17);
/* 279 */     addGrid(panel, this.fFailureList, 0, 6, 2, 1, 1.0D, 17);
/* 280 */     addGrid(panel, failedPanel, 2, 6, 1, 2, 0.0D, 10);
/* 281 */     addGrid(panel, this.fTraceArea, 0, 7, 2, 1, 1.0D, 17);
/*     */     
/* 283 */     addGrid(panel, this.fStatusLine, 0, 8, 2, 2, 1.0D, 10);
/* 284 */     addGrid(panel, this.fQuitButton, 2, 8, 1, 2, 0.0D, 10);
/*     */     
/* 286 */     frame.add(panel, "Center");
/* 287 */     frame.pack();
/* 288 */     return frame;
/*     */   }
/*     */   
/*     */   protected Panel createCounterPanel() {
/* 292 */     Panel numbersPanel = new Panel(new java.awt.GridBagLayout());
/* 293 */     addToCounterPanel(
/* 294 */       numbersPanel, 
/* 295 */       new Label("Runs:"), 
/* 296 */       0, 0, 1, 1, 0.0D, 0.0D, 
/* 297 */       10, 0, 
/* 298 */       new Insets(0, 0, 0, 0));
/*     */     
/* 300 */     addToCounterPanel(
/* 301 */       numbersPanel, 
/* 302 */       this.fNumberOfRuns, 
/* 303 */       1, 0, 1, 1, 0.33D, 0.0D, 
/* 304 */       10, 2, 
/* 305 */       new Insets(0, 8, 0, 40));
/*     */     
/* 307 */     addToCounterPanel(
/* 308 */       numbersPanel, 
/* 309 */       new Label("Errors:"), 
/* 310 */       2, 0, 1, 1, 0.0D, 0.0D, 
/* 311 */       10, 0, 
/* 312 */       new Insets(0, 8, 0, 0));
/*     */     
/* 314 */     addToCounterPanel(
/* 315 */       numbersPanel, 
/* 316 */       this.fNumberOfErrors, 
/* 317 */       3, 0, 1, 1, 0.33D, 0.0D, 
/* 318 */       10, 2, 
/* 319 */       new Insets(0, 8, 0, 40));
/*     */     
/* 321 */     addToCounterPanel(
/* 322 */       numbersPanel, 
/* 323 */       new Label("Failures:"), 
/* 324 */       4, 0, 1, 1, 0.0D, 0.0D, 
/* 325 */       10, 0, 
/* 326 */       new Insets(0, 8, 0, 0));
/*     */     
/* 328 */     addToCounterPanel(
/* 329 */       numbersPanel, 
/* 330 */       this.fNumberOfFailures, 
/* 331 */       5, 0, 1, 1, 0.33D, 0.0D, 
/* 332 */       10, 2, 
/* 333 */       new Insets(0, 8, 0, 0));
/*     */     
/* 335 */     return numbersPanel;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void addToCounterPanel(Panel counter, Component comp, int gridx, int gridy, int gridwidth, int gridheight, double weightx, double weighty, int anchor, int fill, Insets insets)
/*     */   {
/* 344 */     java.awt.GridBagConstraints constraints = new java.awt.GridBagConstraints();
/* 345 */     constraints.gridx = gridx;
/* 346 */     constraints.gridy = gridy;
/* 347 */     constraints.gridwidth = gridwidth;
/* 348 */     constraints.gridheight = gridheight;
/* 349 */     constraints.weightx = weightx;
/* 350 */     constraints.weighty = weighty;
/* 351 */     constraints.anchor = anchor;
/* 352 */     constraints.fill = fill;
/* 353 */     constraints.insets = insets;
/* 354 */     counter.add(comp, constraints);
/*     */   }
/*     */   
/*     */   public void failureSelected()
/*     */   {
/* 359 */     this.fRerunButton.setEnabled(isErrorSelected());
/* 360 */     showErrorTrace();
/*     */   }
/*     */   
/*     */   private boolean isErrorSelected() {
/* 364 */     return this.fFailureList.getSelectedIndex() != -1;
/*     */   }
/*     */   
/*     */   private java.awt.Image loadFrameIcon() {
/* 368 */     java.awt.Toolkit toolkit = java.awt.Toolkit.getDefaultToolkit();
/*     */     try {
/* 370 */       java.net.URL url = BaseTestRunner.class.getResource("smalllogo.gif");
/* 371 */       return toolkit.createImage((java.awt.image.ImageProducer)url.getContent());
/*     */     }
/*     */     catch (Exception localException) {}
/* 374 */     return null;
/*     */   }
/*     */   
/*     */   public Thread getRunner() {
/* 378 */     return this.fRunner;
/*     */   }
/*     */   
/*     */   public static void main(String[] args) {
/* 382 */     new TestRunner().start(args);
/*     */   }
/*     */   
/*     */   public static void run(Class test) {
/* 386 */     String[] args = { test.getName() };
/* 387 */     main(args);
/*     */   }
/*     */   
/*     */   public void rerun() {
/* 391 */     int index = this.fFailureList.getSelectedIndex();
/* 392 */     if (index == -1) {
/* 393 */       return;
/*     */     }
/* 395 */     Test test = (Test)this.fFailedTests.elementAt(index);
/* 396 */     rerunTest(test);
/*     */   }
/*     */   
/*     */   private void rerunTest(Test test) {
/* 400 */     if (!(test instanceof junit.framework.TestCase)) {
/* 401 */       showInfo("Could not reload " + test.toString());
/* 402 */       return;
/*     */     }
/* 404 */     Test reloadedTest = null;
/* 405 */     junit.framework.TestCase rerunTest = (junit.framework.TestCase)test;
/*     */     try {
/* 407 */       Class reloadedTestClass = getLoader().reload(test.getClass());
/* 408 */       reloadedTest = junit.framework.TestSuite.createTest(reloadedTestClass, rerunTest.getName());
/*     */     } catch (Exception e) {
/* 410 */       showInfo("Could not reload " + test.toString());
/* 411 */       return;
/*     */     }
/* 413 */     TestResult result = new TestResult();
/* 414 */     reloadedTest.run(result);
/*     */     
/* 416 */     String message = reloadedTest.toString();
/* 417 */     if (result.wasSuccessful()) {
/* 418 */       showInfo(message + " was successful");
/* 419 */     } else if (result.errorCount() == 1) {
/* 420 */       showStatus(message + " had an error");
/*     */     } else
/* 422 */       showStatus(message + " had a failure");
/*     */   }
/*     */   
/*     */   protected void reset() {
/* 426 */     setLabelValue(this.fNumberOfErrors, 0);
/* 427 */     setLabelValue(this.fNumberOfFailures, 0);
/* 428 */     setLabelValue(this.fNumberOfRuns, 0);
/* 429 */     this.fProgressIndicator.reset();
/* 430 */     this.fRerunButton.setEnabled(false);
/* 431 */     this.fFailureList.removeAll();
/* 432 */     this.fExceptions = new Vector(10);
/* 433 */     this.fFailedTests = new Vector(10);
/* 434 */     this.fTraceArea.setText("");
/*     */   }
/*     */   
/*     */   protected void runFailed(String message)
/*     */   {
/* 439 */     showStatus(message);
/* 440 */     this.fRun.setLabel("Run");
/* 441 */     this.fRunner = null;
/*     */   }
/*     */   
/*     */   public synchronized void runSuite() {
/* 445 */     if ((this.fRunner != null) && (this.fTestResult != null)) {
/* 446 */       this.fTestResult.stop();
/*     */     } else {
/* 448 */       setLoading(shouldReload());
/* 449 */       this.fRun.setLabel("Stop");
/* 450 */       showInfo("Initializing...");
/* 451 */       reset();
/*     */       
/* 453 */       showInfo("Load Test Case...");
/*     */       
/* 455 */       Test testSuite = getTest(this.fSuiteField.getText());
/* 456 */       if (testSuite != null) {
/* 457 */         this.fRunner = new Thread() { private final Test val$testSuite;
/*     */           
/* 459 */           public void run() { TestRunner.this.fTestResult = TestRunner.this.createTestResult();
/* 460 */             TestRunner.this.fTestResult.addListener(TestRunner.this);
/* 461 */             TestRunner.this.fProgressIndicator.start(this.val$testSuite.countTestCases());
/* 462 */             TestRunner.this.showInfo("Running...");
/*     */             
/* 464 */             long startTime = System.currentTimeMillis();
/* 465 */             this.val$testSuite.run(TestRunner.this.fTestResult);
/*     */             
/* 467 */             if (TestRunner.this.fTestResult.shouldStop()) {
/* 468 */               TestRunner.this.showStatus("Stopped");
/*     */             } else {
/* 470 */               long endTime = System.currentTimeMillis();
/* 471 */               long runTime = endTime - startTime;
/* 472 */               TestRunner.this.showInfo("Finished: " + TestRunner.this.elapsedTimeAsString(runTime) + " seconds");
/*     */             }
/* 474 */             TestRunner.this.fTestResult = null;
/* 475 */             TestRunner.this.fRun.setLabel("Run");
/* 476 */             TestRunner.this.fRunner = null;
/* 477 */             System.gc();
/*     */           }
/* 479 */         };
/* 480 */         this.fRunner.start();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean shouldReload() {
/* 486 */     return (!BaseTestRunner.inVAJava()) && (this.fUseLoadingRunner.getState());
/*     */   }
/*     */   
/*     */   private void setLabelValue(Label label, int value) {
/* 490 */     label.setText(Integer.toString(value));
/* 491 */     label.invalidate();
/* 492 */     label.getParent().validate();
/*     */   }
/*     */   
/*     */   public void setSuiteName(String suite)
/*     */   {
/* 497 */     this.fSuiteField.setText(suite);
/*     */   }
/*     */   
/*     */   private void showErrorTrace() {
/* 501 */     int index = this.fFailureList.getSelectedIndex();
/* 502 */     if (index == -1) {
/* 503 */       return;
/*     */     }
/* 505 */     Throwable t = (Throwable)this.fExceptions.elementAt(index);
/* 506 */     this.fTraceArea.setText(BaseTestRunner.getFilteredTrace(t));
/*     */   }
/*     */   
/*     */   private void showInfo(String message)
/*     */   {
/* 511 */     this.fStatusLine.setFont(PLAIN_FONT);
/* 512 */     this.fStatusLine.setForeground(java.awt.Color.black);
/* 513 */     this.fStatusLine.setText(message);
/*     */   }
/*     */   
/*     */   protected void clearStatus() {
/* 517 */     showStatus("");
/*     */   }
/*     */   
/*     */   private void showStatus(String status) {
/* 521 */     this.fStatusLine.setFont(PLAIN_FONT);
/* 522 */     this.fStatusLine.setForeground(java.awt.Color.red);
/* 523 */     this.fStatusLine.setText(status);
/*     */   }
/*     */   
/*     */ 
/*     */   public void start(String[] args)
/*     */   {
/* 529 */     String suiteName = processArguments(args);
/* 530 */     this.fFrame = createUI(suiteName);
/* 531 */     this.fFrame.setLocation(200, 200);
/* 532 */     this.fFrame.setVisible(true);
/*     */     
/* 534 */     if (suiteName != null) {
/* 535 */       setSuiteName(suiteName);
/* 536 */       runSuite();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp1\Exp1 (1).zip!\Exp1\lib\junit.jar!\junit\awtui\TestRunner.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */