/*    */ package junit.extensions;
/*    */ 
/*    */ import junit.framework.Assert;
/*    */ import junit.framework.Test;
/*    */ import junit.framework.TestResult;
/*    */ 
/*    */ 
/*    */ public class TestDecorator
/*    */   extends Assert
/*    */   implements Test
/*    */ {
/*    */   protected Test fTest;
/*    */   
/*    */   public TestDecorator(Test test)
/*    */   {
/* 16 */     this.fTest = test;
/*    */   }
/*    */   
/*    */ 
/*    */   public void basicRun(TestResult result)
/*    */   {
/* 22 */     this.fTest.run(result);
/*    */   }
/*    */   
/* 25 */   public int countTestCases() { return this.fTest.countTestCases(); }
/*    */   
/*    */   public void run(TestResult result) {
/* 28 */     basicRun(result);
/*    */   }
/*    */   
/*    */   public String toString() {
/* 32 */     return this.fTest.toString();
/*    */   }
/*    */   
/*    */   public Test getTest() {
/* 36 */     return this.fTest;
/*    */   }
/*    */ }


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp1\Exp1 (1).zip!\Exp1\lib\junit.jar!\junit\extensions\TestDecorator.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */