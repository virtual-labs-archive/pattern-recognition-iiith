/*    */ package junit.framework;
/*    */ 
/*    */ 
/*    */ public class AssertionFailedError
/*    */   extends Error
/*    */ {
/*    */   public AssertionFailedError() {}
/*    */   
/*    */   public AssertionFailedError(String message)
/*    */   {
/* 11 */     super(message);
/*    */   }
/*    */ }


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp1\Exp1 (1).zip!\Exp1\lib\junit.jar!\junit\framework\AssertionFailedError.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */