package junit.swingui;

import javax.swing.JTabbedPane;
import junit.framework.Test;
import junit.framework.TestResult;

abstract interface TestRunView
{
  public abstract Test getSelectedTest();
  
  public abstract void activate();
  
  public abstract void revealFailure(Test paramTest);
  
  public abstract void addTab(JTabbedPane paramJTabbedPane);
  
  public abstract void aboutToStart(Test paramTest, TestResult paramTestResult);
  
  public abstract void runFinished(Test paramTest, TestResult paramTestResult);
}


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp1\Exp1 (1).zip!\Exp1\lib\junit.jar!\junit\swingui\TestRunView.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */