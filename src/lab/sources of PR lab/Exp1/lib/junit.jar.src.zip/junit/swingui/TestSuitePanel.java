/*     */ package junit.swingui;
/*     */ 
/*     */ import java.util.Vector;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JTree;
/*     */ import javax.swing.tree.TreePath;
/*     */ import junit.framework.Test;
/*     */ 
/*     */ class TestSuitePanel extends javax.swing.JPanel implements junit.framework.TestListener
/*     */ {
/*     */   private JTree fTree;
/*     */   private javax.swing.JScrollPane fScrollTree;
/*     */   private TestTreeModel fModel;
/*     */   
/*     */   static class TestTreeCellRenderer extends javax.swing.tree.DefaultTreeCellRenderer
/*     */   {
/*     */     private Icon fErrorIcon;
/*     */     private Icon fOkIcon;
/*     */     private Icon fFailureIcon;
/*     */     
/*     */     TestTreeCellRenderer()
/*     */     {
/*  25 */       loadIcons();
/*     */     }
/*     */     
/*     */     void loadIcons() {
/*  29 */       this.fErrorIcon = TestRunner.getIconResource(getClass(), "icons/error.gif");
/*  30 */       this.fOkIcon = TestRunner.getIconResource(getClass(), "icons/ok.gif");
/*  31 */       this.fFailureIcon = TestRunner.getIconResource(getClass(), "icons/failure.gif");
/*     */     }
/*     */     
/*     */     String stripParenthesis(Object o) {
/*  35 */       String text = o.toString();
/*  36 */       int pos = text.indexOf('(');
/*  37 */       if (pos < 1)
/*  38 */         return text;
/*  39 */       return text.substring(0, pos);
/*     */     }
/*     */     
/*     */ 
/*     */     public java.awt.Component getTreeCellRendererComponent(JTree tree, Object value, boolean sel, boolean expanded, boolean leaf, int row, boolean hasFocus)
/*     */     {
/*  45 */       java.awt.Component c = super.getTreeCellRendererComponent(tree, value, sel, expanded, leaf, row, hasFocus);
/*  46 */       javax.swing.tree.TreeModel model = tree.getModel();
/*  47 */       if ((model instanceof TestTreeModel)) {
/*  48 */         TestTreeModel testModel = (TestTreeModel)model;
/*  49 */         Test t = (Test)value;
/*  50 */         String s = "";
/*  51 */         if (testModel.isFailure(t)) {
/*  52 */           if (this.fFailureIcon != null)
/*  53 */             setIcon(this.fFailureIcon);
/*  54 */           s = " - Failed";
/*     */         }
/*  56 */         else if (testModel.isError(t)) {
/*  57 */           if (this.fErrorIcon != null)
/*  58 */             setIcon(this.fErrorIcon);
/*  59 */           s = " - Error";
/*     */         }
/*  61 */         else if (testModel.wasRun(t)) {
/*  62 */           if (this.fOkIcon != null)
/*  63 */             setIcon(this.fOkIcon);
/*  64 */           s = " - Passed";
/*     */         }
/*  66 */         if ((c instanceof JComponent))
/*  67 */           ((JComponent)c).setToolTipText(getText() + s);
/*     */       }
/*  69 */       setText(stripParenthesis(value));
/*  70 */       return c;
/*     */     }
/*     */   }
/*     */   
/*     */   public TestSuitePanel() {
/*  75 */     super(new java.awt.BorderLayout());
/*  76 */     setPreferredSize(new java.awt.Dimension(300, 100));
/*  77 */     this.fTree = new JTree();
/*  78 */     this.fTree.setModel(null);
/*  79 */     this.fTree.setRowHeight(20);
/*  80 */     javax.swing.ToolTipManager.sharedInstance().registerComponent(this.fTree);
/*  81 */     this.fTree.putClientProperty("JTree.lineStyle", "Angled");
/*  82 */     this.fScrollTree = new javax.swing.JScrollPane(this.fTree);
/*  83 */     add(this.fScrollTree, "Center");
/*     */   }
/*     */   
/*     */   public void addError(Test test, Throwable t) {
/*  87 */     this.fModel.addError(test);
/*  88 */     fireTestChanged(test, true);
/*     */   }
/*     */   
/*     */   public void addFailure(Test test, junit.framework.AssertionFailedError t) {
/*  92 */     this.fModel.addFailure(test);
/*  93 */     fireTestChanged(test, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void endTest(Test test)
/*     */   {
/* 100 */     this.fModel.addRunTest(test);
/* 101 */     fireTestChanged(test, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void startTest(Test test) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Test getSelectedTest()
/*     */   {
/* 114 */     TreePath[] paths = this.fTree.getSelectionPaths();
/* 115 */     if ((paths != null) && (paths.length == 1))
/* 116 */       return (Test)paths[0].getLastPathComponent();
/* 117 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public JTree getTree()
/*     */   {
/* 124 */     return this.fTree;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void showTestTree(Test root)
/*     */   {
/* 131 */     this.fModel = new TestTreeModel(root);
/* 132 */     this.fTree.setModel(this.fModel);
/* 133 */     this.fTree.setCellRenderer(new TestTreeCellRenderer());
/*     */   }
/*     */   
/*     */   private void fireTestChanged(Test test, boolean expand) {
/* 137 */     javax.swing.SwingUtilities.invokeLater(
/* 138 */       new Runnable() { private final Test val$test;
/*     */         
/* 140 */         public void run() { Vector vpath = new Vector();
/* 141 */           int index = TestSuitePanel.this.fModel.findTest(this.val$test, (Test)TestSuitePanel.this.fModel.getRoot(), vpath);
/* 142 */           if (index >= 0) {
/* 143 */             Object[] path = new Object[vpath.size()];
/* 144 */             vpath.copyInto(path);
/* 145 */             TreePath treePath = new TreePath(path);
/* 146 */             TestSuitePanel.this.fModel.fireNodeChanged(treePath, index);
/* 147 */             if (this.val$expand) {
/* 148 */               Object[] fullPath = new Object[vpath.size() + 1];
/* 149 */               vpath.copyInto(fullPath);
/* 150 */               fullPath[vpath.size()] = TestSuitePanel.this.fModel.getChild(treePath.getLastPathComponent(), index);
/* 151 */               TreePath fullTreePath = new TreePath(fullPath);
/* 152 */               TestSuitePanel.this.fTree.scrollPathToVisible(fullTreePath);
/*     */             }
/*     */           }
/*     */         }
/*     */       });
/*     */   }
/*     */   
/*     */   private final boolean val$expand;
/*     */ }


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp1\Exp1 (1).zip!\Exp1\lib\junit.jar!\junit\swingui\TestSuitePanel.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */