/*     */ package junit.textui;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintStream;
/*     */ import junit.framework.Test;
/*     */ import junit.framework.TestResult;
/*     */ import junit.framework.TestSuite;
/*     */ import junit.runner.BaseTestRunner;
/*     */ import junit.runner.StandardTestSuiteLoader;
/*     */ import junit.runner.TestSuiteLoader;
/*     */ import junit.runner.Version;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TestRunner
/*     */   extends BaseTestRunner
/*     */ {
/*     */   private ResultPrinter fPrinter;
/*     */   public static final int SUCCESS_EXIT = 0;
/*     */   public static final int FAILURE_EXIT = 1;
/*     */   public static final int EXCEPTION_EXIT = 2;
/*     */   
/*     */   public TestRunner()
/*     */   {
/*  36 */     this(System.out);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public TestRunner(PrintStream writer)
/*     */   {
/*  43 */     this(new ResultPrinter(writer));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public TestRunner(ResultPrinter printer)
/*     */   {
/*  50 */     this.fPrinter = printer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void run(Class testClass)
/*     */   {
/*  57 */     run(new TestSuite(testClass));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static TestResult run(Test test)
/*     */   {
/*  71 */     TestRunner runner = new TestRunner();
/*  72 */     return runner.doRun(test);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void runAndWait(Test suite)
/*     */   {
/*  80 */     TestRunner aTestRunner = new TestRunner();
/*  81 */     aTestRunner.doRun(suite, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public TestSuiteLoader getLoader()
/*     */   {
/*  89 */     return new StandardTestSuiteLoader();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void testFailed(int status, Test test, Throwable t) {}
/*     */   
/*     */ 
/*     */   public void testStarted(String testName) {}
/*     */   
/*     */ 
/*     */   public void testEnded(String testName) {}
/*     */   
/*     */ 
/*     */   protected TestResult createTestResult()
/*     */   {
/* 105 */     return new TestResult();
/*     */   }
/*     */   
/*     */   public TestResult doRun(Test test) {
/* 109 */     return doRun(test, false);
/*     */   }
/*     */   
/*     */   public TestResult doRun(Test suite, boolean wait) {
/* 113 */     TestResult result = createTestResult();
/* 114 */     result.addListener(this.fPrinter);
/* 115 */     long startTime = System.currentTimeMillis();
/* 116 */     suite.run(result);
/* 117 */     long endTime = System.currentTimeMillis();
/* 118 */     long runTime = endTime - startTime;
/* 119 */     this.fPrinter.print(result, runTime);
/*     */     
/* 121 */     pause(wait);
/* 122 */     return result;
/*     */   }
/*     */   
/*     */   protected void pause(boolean wait) {
/* 126 */     if (!wait) return;
/* 127 */     this.fPrinter.printWaitPrompt();
/*     */     try {
/* 129 */       System.in.read();
/*     */     }
/*     */     catch (Exception localException) {}
/*     */   }
/*     */   
/*     */   public static void main(String[] args)
/*     */   {
/* 136 */     TestRunner aTestRunner = new TestRunner();
/*     */     try {
/* 138 */       TestResult r = aTestRunner.start(args);
/* 139 */       if (!r.wasSuccessful())
/* 140 */         System.exit(1);
/* 141 */       System.exit(0);
/*     */     } catch (Exception e) {
/* 143 */       System.err.println(e.getMessage());
/* 144 */       System.exit(2);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected TestResult start(String[] args)
/*     */     throws Exception
/*     */   {
/* 153 */     String testCase = "";
/* 154 */     boolean wait = false;
/*     */     
/* 156 */     for (int i = 0; i < args.length; i++) {
/* 157 */       if (args[i].equals("-wait")) {
/* 158 */         wait = true;
/* 159 */       } else if (args[i].equals("-c")) {
/* 160 */         testCase = extractClassName(args[(++i)]);
/* 161 */       } else if (args[i].equals("-v")) {
/* 162 */         System.err.println("JUnit " + Version.id() + " by Kent Beck and Erich Gamma");
/*     */       } else {
/* 164 */         testCase = args[i];
/*     */       }
/*     */     }
/* 167 */     if (testCase.equals("")) {
/* 168 */       throw new Exception("Usage: TestRunner [-wait] testCaseName, where name is the name of the TestCase class");
/*     */     }
/*     */     try {
/* 171 */       Test suite = getTest(testCase);
/* 172 */       return doRun(suite, wait);
/*     */     }
/*     */     catch (Exception e) {
/* 175 */       throw new Exception("Could not create and run test suite: " + e);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void runFailed(String message) {
/* 180 */     System.err.println(message);
/* 181 */     System.exit(1);
/*     */   }
/*     */   
/*     */   public void setPrinter(ResultPrinter printer) {
/* 185 */     this.fPrinter = printer;
/*     */   }
/*     */ }


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp1\Exp1 (1).zip!\Exp1\lib\junit.jar!\junit\textui\TestRunner.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */