/*     */ package libsvm;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Cache
/*     */ {
/*     */   private final int l;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private long size;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final head_t[] head;
/*     */   
/*     */ 
/*     */ 
/*     */   private head_t lru_head;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   Cache(int paramInt, long paramLong)
/*     */   {
/*  30 */     this.l = paramInt;
/*  31 */     this.size = paramLong;
/*  32 */     this.head = new head_t[this.l];
/*  33 */     for (int i = 0; i < this.l; i++) this.head[i] = new head_t(null);
/*  34 */     this.size /= 4L;
/*  35 */     this.size -= this.l * 4;
/*  36 */     this.size = Math.max(this.size, 2L * this.l);
/*  37 */     this.lru_head = new head_t(null);
/*  38 */     this.lru_head.next = (this.lru_head.prev = this.lru_head);
/*     */   }
/*     */   
/*     */ 
/*     */   private void lru_delete(head_t paramhead_t)
/*     */   {
/*  44 */     paramhead_t.prev.next = paramhead_t.next;
/*  45 */     paramhead_t.next.prev = paramhead_t.prev;
/*     */   }
/*     */   
/*     */ 
/*     */   private void lru_insert(head_t paramhead_t)
/*     */   {
/*  51 */     paramhead_t.next = this.lru_head;
/*  52 */     paramhead_t.prev = this.lru_head.prev;
/*  53 */     paramhead_t.prev.next = paramhead_t;
/*  54 */     paramhead_t.next.prev = paramhead_t;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int get_data(int paramInt1, float[][] paramArrayOfFloat, int paramInt2)
/*     */   {
/*  63 */     head_t localhead_t = this.head[paramInt1];
/*  64 */     if (localhead_t.len > 0) lru_delete(localhead_t);
/*  65 */     int i = paramInt2 - localhead_t.len;
/*     */     
/*  67 */     if (i > 0)
/*     */     {
/*     */ 
/*  70 */       while (this.size < i)
/*     */       {
/*  72 */         localObject = this.lru_head.next;
/*  73 */         lru_delete((head_t)localObject);
/*  74 */         this.size += ((head_t)localObject).len;
/*  75 */         ((head_t)localObject).data = null;
/*  76 */         ((head_t)localObject).len = 0;
/*     */       }
/*     */       
/*     */ 
/*  80 */       Object localObject = new float[paramInt2];
/*  81 */       if (localhead_t.data != null) System.arraycopy(localhead_t.data, 0, localObject, 0, localhead_t.len);
/*  82 */       localhead_t.data = ((float[])localObject);
/*  83 */       this.size -= i;
/*  84 */       int j = localhead_t.len;localhead_t.len = paramInt2;paramInt2 = j;
/*     */     }
/*     */     
/*  87 */     lru_insert(localhead_t);
/*  88 */     paramArrayOfFloat[0] = localhead_t.data;
/*  89 */     return paramInt2;
/*     */   }
/*     */   
/*     */   void swap_index(int paramInt1, int paramInt2)
/*     */   {
/*  94 */     if (paramInt1 == paramInt2) { return;
/*     */     }
/*  96 */     if (this.head[paramInt1].len > 0) lru_delete(this.head[paramInt1]);
/*  97 */     if (this.head[paramInt2].len > 0) lru_delete(this.head[paramInt2]);
/*  98 */     float[] arrayOfFloat = this.head[paramInt1].data;this.head[paramInt1].data = this.head[paramInt2].data;this.head[paramInt2].data = arrayOfFloat;
/*  99 */     int i = this.head[paramInt1].len;this.head[paramInt1].len = this.head[paramInt2].len;this.head[paramInt2].len = i;
/* 100 */     if (this.head[paramInt1].len > 0) lru_insert(this.head[paramInt1]);
/* 101 */     if (this.head[paramInt2].len > 0) { lru_insert(this.head[paramInt2]);
/*     */     }
/* 103 */     if (paramInt1 > paramInt2) { i = paramInt1;paramInt1 = paramInt2;paramInt2 = i; }
/* 104 */     for (head_t localhead_t = this.lru_head.next; localhead_t != this.lru_head; localhead_t = localhead_t.next)
/*     */     {
/* 106 */       if (localhead_t.len > paramInt1)
/*     */       {
/* 108 */         if (localhead_t.len > paramInt2) {
/* 109 */           float f = localhead_t.data[paramInt1];localhead_t.data[paramInt1] = localhead_t.data[paramInt2];localhead_t.data[paramInt2] = f;
/*     */         }
/*     */         else
/*     */         {
/* 113 */           lru_delete(localhead_t);
/* 114 */           this.size += localhead_t.len;
/* 115 */           localhead_t.data = null;
/* 116 */           localhead_t.len = 0;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private final class head_t
/*     */   {
/*     */     head_t prev;
/*     */     head_t next;
/*     */     float[] data;
/*     */     int len;
/*     */     
/*     */     private head_t() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp1\Exp1 (1).zip!\Exp1\lib\libsvm.jar!\libsvm\Cache.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */