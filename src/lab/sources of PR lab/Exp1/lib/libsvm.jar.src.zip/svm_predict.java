/*     */ import java.io.DataOutputStream;
/*     */ import libsvm.svm;
/*     */ 
/*     */ class svm_predict
/*     */ {
/*   6 */   private static libsvm.svm_print_interface svm_print_null = new libsvm.svm_print_interface()
/*     */   {
/*     */     public void print(String paramAnonymousString) {}
/*     */   };
/*     */   
/*  11 */   private static libsvm.svm_print_interface svm_print_stdout = new libsvm.svm_print_interface()
/*     */   {
/*     */     public void print(String paramAnonymousString)
/*     */     {
/*  15 */       System.out.print(paramAnonymousString);
/*     */     }
/*     */   };
/*     */   
/*  19 */   private static libsvm.svm_print_interface svm_print_string = svm_print_stdout;
/*     */   
/*     */   static void info(String paramString)
/*     */   {
/*  23 */     svm_print_string.print(paramString);
/*     */   }
/*     */   
/*     */   private static double atof(String paramString)
/*     */   {
/*  28 */     return Double.valueOf(paramString).doubleValue();
/*     */   }
/*     */   
/*     */   private static int atoi(String paramString)
/*     */   {
/*  33 */     return Integer.parseInt(paramString);
/*     */   }
/*     */   
/*     */   private static void predict(java.io.BufferedReader paramBufferedReader, DataOutputStream paramDataOutputStream, libsvm.svm_model paramsvm_model, int paramInt) throws java.io.IOException
/*     */   {
/*  38 */     int i = 0;
/*  39 */     int j = 0;
/*  40 */     double d1 = 0.0D;
/*  41 */     double d2 = 0.0D;double d3 = 0.0D;double d4 = 0.0D;double d5 = 0.0D;double d6 = 0.0D;
/*     */     
/*  43 */     int k = svm.svm_get_svm_type(paramsvm_model);
/*  44 */     int m = svm.svm_get_nr_class(paramsvm_model);
/*  45 */     double[] arrayOfDouble = null;
/*     */     Object localObject;
/*  47 */     if (paramInt == 1)
/*     */     {
/*  49 */       if ((k == 3) || (k == 4))
/*     */       {
/*     */ 
/*  52 */         info("Prob. model for test data: target value = predicted value + z,\nz: Laplace distribution e^(-|z|/sigma)/(2sigma),sigma=" + svm.svm_get_svr_probability(paramsvm_model) + "\n");
/*     */       }
/*     */       else
/*     */       {
/*  56 */         localObject = new int[m];
/*  57 */         svm.svm_get_labels(paramsvm_model, (int[])localObject);
/*  58 */         arrayOfDouble = new double[m];
/*  59 */         paramDataOutputStream.writeBytes("labels");
/*  60 */         for (int n = 0; n < m; n++)
/*  61 */           paramDataOutputStream.writeBytes(" " + localObject[n]);
/*  62 */         paramDataOutputStream.writeBytes("\n");
/*     */       }
/*     */     }
/*     */     for (;;)
/*     */     {
/*  67 */       localObject = paramBufferedReader.readLine();
/*  68 */       if (localObject == null)
/*     */         break;
/*  70 */       java.util.StringTokenizer localStringTokenizer = new java.util.StringTokenizer((String)localObject, " \t\n\r\f:");
/*     */       
/*  72 */       double d7 = atof(localStringTokenizer.nextToken());
/*  73 */       int i1 = localStringTokenizer.countTokens() / 2;
/*  74 */       libsvm.svm_node[] arrayOfsvm_node = new libsvm.svm_node[i1];
/*  75 */       for (int i2 = 0; i2 < i1; i2++)
/*     */       {
/*  77 */         arrayOfsvm_node[i2] = new libsvm.svm_node();
/*  78 */         arrayOfsvm_node[i2].index = atoi(localStringTokenizer.nextToken());
/*  79 */         arrayOfsvm_node[i2].value = atof(localStringTokenizer.nextToken());
/*     */       }
/*     */       
/*     */       double d8;
/*  83 */       if ((paramInt == 1) && ((k == 0) || (k == 1)))
/*     */       {
/*  85 */         d8 = svm.svm_predict_probability(paramsvm_model, arrayOfsvm_node, arrayOfDouble);
/*  86 */         paramDataOutputStream.writeBytes(d8 + " ");
/*  87 */         for (int i3 = 0; i3 < m; i3++)
/*  88 */           paramDataOutputStream.writeBytes(arrayOfDouble[i3] + " ");
/*  89 */         paramDataOutputStream.writeBytes("\n");
/*     */       }
/*     */       else
/*     */       {
/*  93 */         d8 = svm.svm_predict(paramsvm_model, arrayOfsvm_node);
/*  94 */         paramDataOutputStream.writeBytes(d8 + "\n");
/*     */       }
/*     */       
/*  97 */       if (d8 == d7)
/*  98 */         i++;
/*  99 */       d1 += (d8 - d7) * (d8 - d7);
/* 100 */       d2 += d8;
/* 101 */       d3 += d7;
/* 102 */       d4 += d8 * d8;
/* 103 */       d5 += d7 * d7;
/* 104 */       d6 += d8 * d7;
/* 105 */       j++;
/*     */     }
/* 107 */     if ((k == 3) || (k == 4))
/*     */     {
/*     */ 
/* 110 */       info("Mean squared error = " + d1 / j + " (regression)\n");
/* 111 */       info("Squared correlation coefficient = " + (j * d6 - d2 * d3) * (j * d6 - d2 * d3) / ((j * d4 - d2 * d2) * (j * d5 - d3 * d3)) + " (regression)\n");
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/* 117 */       info("Accuracy = " + i / j * 100.0D + "% (" + i + "/" + j + ") (classification)\n");
/*     */     }
/*     */   }
/*     */   
/*     */   private static void exit_with_help()
/*     */   {
/* 123 */     System.err.print("usage: svm_predict [options] test_file model_file output_file\noptions:\n-b probability_estimates: whether to predict probability estimates, 0 or 1 (default 0); one-class SVM not supported yet\n-q : quiet mode (no outputs)\n");
/*     */     
/*     */ 
/*     */ 
/* 127 */     System.exit(1);
/*     */   }
/*     */   
/*     */   public static void main(String[] paramArrayOfString) throws java.io.IOException
/*     */   {
/* 132 */     int j = 0;
/* 133 */     svm_print_string = svm_print_stdout;
/*     */     
/*     */ 
/* 136 */     for (int i = 0; i < paramArrayOfString.length; i++)
/*     */     {
/* 138 */       if (paramArrayOfString[i].charAt(0) != '-') break;
/* 139 */       i++;
/* 140 */       switch (paramArrayOfString[(i - 1)].charAt(1))
/*     */       {
/*     */       case 'b': 
/* 143 */         j = atoi(paramArrayOfString[i]);
/* 144 */         break;
/*     */       case 'q': 
/* 146 */         svm_print_string = svm_print_null;
/* 147 */         i--;
/* 148 */         break;
/*     */       default: 
/* 150 */         System.err.print("Unknown option: " + paramArrayOfString[(i - 1)] + "\n");
/* 151 */         exit_with_help();
/*     */       }
/*     */     }
/* 154 */     if (i >= paramArrayOfString.length - 2) {
/* 155 */       exit_with_help();
/*     */     }
/*     */     try {
/* 158 */       java.io.BufferedReader localBufferedReader = new java.io.BufferedReader(new java.io.FileReader(paramArrayOfString[i]));
/* 159 */       DataOutputStream localDataOutputStream = new DataOutputStream(new java.io.BufferedOutputStream(new java.io.FileOutputStream(paramArrayOfString[(i + 2)])));
/* 160 */       libsvm.svm_model localsvm_model = svm.svm_load_model(paramArrayOfString[(i + 1)]);
/* 161 */       if (j == 1)
/*     */       {
/* 163 */         if (svm.svm_check_probability_model(localsvm_model) == 0)
/*     */         {
/* 165 */           System.err.print("Model does not support probabiliy estimates\n");
/* 166 */           System.exit(1);
/*     */         }
/*     */         
/*     */ 
/*     */       }
/* 171 */       else if (svm.svm_check_probability_model(localsvm_model) != 0)
/*     */       {
/* 173 */         info("Model supports probability estimates, but disabled in prediction.\n");
/*     */       }
/*     */       
/* 176 */       predict(localBufferedReader, localDataOutputStream, localsvm_model, j);
/* 177 */       localBufferedReader.close();
/* 178 */       localDataOutputStream.close();
/*     */     }
/*     */     catch (java.io.FileNotFoundException localFileNotFoundException)
/*     */     {
/* 182 */       exit_with_help();
/*     */     }
/*     */     catch (ArrayIndexOutOfBoundsException localArrayIndexOutOfBoundsException)
/*     */     {
/* 186 */       exit_with_help();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp1\Exp1 (1).zip!\Exp1\lib\libsvm.jar!\svm_predict.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */