package org.jfree.ui;

import java.awt.GradientPaint;
import java.awt.Shape;

public abstract interface GradientPaintTransformer
{
  public abstract GradientPaint transform(GradientPaint paramGradientPaint, Shape paramShape);
}


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp1\Exp1 (1).zip!\Exp1\lib\jcommon-1.0.16.jar!\org\jfree\ui\GradientPaintTransformer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */