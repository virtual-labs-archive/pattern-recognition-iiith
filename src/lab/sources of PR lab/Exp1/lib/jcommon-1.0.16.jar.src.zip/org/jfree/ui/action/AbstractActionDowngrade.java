package org.jfree.ui.action;

import javax.swing.AbstractAction;

public abstract class AbstractActionDowngrade
  extends AbstractAction
  implements ActionDowngrade
{
  public static final String ACCELERATOR_KEY = "AcceleratorKey";
  public static final String MNEMONIC_KEY = "MnemonicKey";
}


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp1\Exp1 (1).zip!\Exp1\lib\jcommon-1.0.16.jar!\org\jfree\ui\action\AbstractActionDowngrade.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */