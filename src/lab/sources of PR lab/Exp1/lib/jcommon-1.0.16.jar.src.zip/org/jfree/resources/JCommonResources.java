/*    */ package org.jfree.resources;
/*    */ 
/*    */ import java.util.ListResourceBundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JCommonResources
/*    */   extends ListResourceBundle
/*    */ {
/*    */   public Object[][] getContents()
/*    */   {
/* 60 */     return CONTENTS;
/*    */   }
/*    */   
/*    */ 
/* 64 */   private static final Object[][] CONTENTS = { { "project.name", "JCommon" }, { "project.version", "1.0.15" }, { "project.info", "http://www.jfree.org/jcommon/" }, { "project.copyright", "(C)opyright 2000-2008, by Object Refinery Limited and Contributors" } };
/*    */ }


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp1\Exp1 (1).zip!\Exp1\lib\jcommon-1.0.16.jar!\org\jfree\resources\JCommonResources.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */