/*     */ package Jama.test;
/*     */ 
/*     */ import Jama.CholeskyDecomposition;
/*     */ import Jama.EigenvalueDecomposition;
/*     */ import Jama.LUDecomposition;
/*     */ import Jama.Matrix;
/*     */ import Jama.QRDecomposition;
/*     */ import Jama.SingularValueDecomposition;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.FileReader;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.text.DecimalFormat;
/*     */ import java.text.DecimalFormatSymbols;
/*     */ import java.text.NumberFormat;
/*     */ import java.util.Locale;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TestMatrix
/*     */ {
/*     */   public static void main(String[] paramArrayOfString)
/*     */   {
/*  35 */     int i = 0;
/*  36 */     int j = 0;
/*     */     
/*  38 */     double[] arrayOfDouble1 = { 1.0D, 2.0D, 3.0D, 4.0D, 5.0D, 6.0D, 7.0D, 8.0D, 9.0D, 10.0D, 11.0D, 12.0D };
/*  39 */     double[] arrayOfDouble2 = { 1.0D, 4.0D, 7.0D, 10.0D, 2.0D, 5.0D, 8.0D, 11.0D, 3.0D, 6.0D, 9.0D, 12.0D };
/*  40 */     double[][] arrayOfDouble3 = { { 1.0D, 4.0D, 7.0D, 10.0D }, { 2.0D, 5.0D, 8.0D, 11.0D }, { 3.0D, 6.0D, 9.0D, 12.0D } };
/*  41 */     double[][] arrayOfDouble4 = arrayOfDouble3;
/*  42 */     double[][] arrayOfDouble5 = { { 1.0D, 2.0D, 3.0D }, { 4.0D, 5.0D, 6.0D }, { 7.0D, 8.0D, 9.0D }, { 10.0D, 11.0D, 12.0D } };
/*  43 */     double[][] arrayOfDouble6 = { { 5.0D, 8.0D, 11.0D }, { 6.0D, 9.0D, 12.0D } };
/*  44 */     double[][] arrayOfDouble7 = { { 1.0D, 4.0D, 7.0D }, { 2.0D, 5.0D, 8.0D, 11.0D }, { 3.0D, 6.0D, 9.0D, 12.0D } };
/*  45 */     double[][] arrayOfDouble8 = { { 4.0D, 1.0D, 1.0D }, { 1.0D, 2.0D, 3.0D }, { 1.0D, 3.0D, 6.0D } };
/*  46 */     double[][] arrayOfDouble9 = { { 1.0D, 0.0D, 0.0D, 0.0D }, { 0.0D, 1.0D, 0.0D, 0.0D }, { 0.0D, 0.0D, 1.0D, 0.0D } };
/*  47 */     double[][] arrayOfDouble10 = { { 0.0D, 1.0D, 0.0D, 0.0D }, { 1.0D, 0.0D, 2.0E-7D, 0.0D }, { 0.0D, -2.0E-7D, 0.0D, 1.0D }, { 0.0D, 0.0D, 1.0D, 0.0D } };
/*     */     
/*  49 */     double[][] arrayOfDouble11 = { { 166.0D, 188.0D, 210.0D }, { 188.0D, 214.0D, 240.0D }, { 210.0D, 240.0D, 270.0D } };
/*  50 */     double[][] arrayOfDouble12 = { { 13.0D }, { 15.0D } };
/*  51 */     double[][] arrayOfDouble13 = { { 1.0D, 3.0D }, { 7.0D, 9.0D } };
/*  52 */     int k = 3;int m = 4;
/*  53 */     int n = 5;
/*  54 */     int i1 = 0;
/*  55 */     int i2 = 4;
/*  56 */     int i3 = 3;
/*  57 */     int i4 = 4;
/*  58 */     int i5 = 1;int i6 = 2;int i7 = 1;int i8 = 3;
/*  59 */     int[] arrayOfInt1 = { 1, 2 };
/*  60 */     int[] arrayOfInt2 = { 1, 3 };
/*  61 */     int[] arrayOfInt3 = { 1, 2, 3 };
/*  62 */     int[] arrayOfInt4 = { 1, 2, 4 };
/*  63 */     double d2 = 33.0D;
/*  64 */     double d3 = 30.0D;
/*  65 */     double d4 = 15.0D;
/*  66 */     double d5 = 650.0D;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  80 */     print("\nTesting constructors and constructor-like methods...\n");
/*     */     try
/*     */     {
/*  83 */       localObject1 = new Matrix(arrayOfDouble1, n);
/*  84 */       i = try_failure(i, "Catch invalid length in packed constructor... ", "exception not thrown for invalid input");
/*     */     }
/*     */     catch (IllegalArgumentException localIllegalArgumentException1) {
/*  87 */       try_success("Catch invalid length in packed constructor... ", localIllegalArgumentException1.getMessage());
/*     */     }
/*     */     
/*     */ 
/*     */     try
/*     */     {
/*  93 */       localObject1 = new Matrix(arrayOfDouble7);
/*  94 */       d1 = ((Matrix)localObject1).get(i1, i2);
/*     */     } catch (IllegalArgumentException localIllegalArgumentException2) {
/*  96 */       try_success("Catch ragged input to default constructor... ", localIllegalArgumentException2.getMessage());
/*     */     }
/*     */     catch (ArrayIndexOutOfBoundsException localArrayIndexOutOfBoundsException1) {
/*  99 */       i = try_failure(i, "Catch ragged input to constructor... ", "exception not thrown in construction...ArrayIndexOutOfBoundsException thrown later");
/*     */     }
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 105 */       localObject1 = Matrix.constructWithCopy(arrayOfDouble7);
/* 106 */       d1 = ((Matrix)localObject1).get(i1, i2);
/*     */     } catch (IllegalArgumentException localIllegalArgumentException3) {
/* 108 */       try_success("Catch ragged input to constructWithCopy... ", localIllegalArgumentException3.getMessage());
/*     */     } catch (ArrayIndexOutOfBoundsException localArrayIndexOutOfBoundsException2) {
/* 110 */       i = try_failure(i, "Catch ragged input to constructWithCopy... ", "exception not thrown in construction...ArrayIndexOutOfBoundsException thrown later");
/*     */     }
/*     */     
/* 113 */     Object localObject1 = new Matrix(arrayOfDouble1, i3);
/* 114 */     Matrix localMatrix1 = new Matrix(arrayOfDouble3);
/* 115 */     double d1 = localMatrix1.get(0, 0);
/* 116 */     arrayOfDouble3[0][0] = 0.0D;
/* 117 */     Matrix localMatrix2 = localMatrix1.minus((Matrix)localObject1);
/* 118 */     arrayOfDouble3[0][0] = d1;
/* 119 */     localMatrix1 = Matrix.constructWithCopy(arrayOfDouble3);
/* 120 */     d1 = localMatrix1.get(0, 0);
/* 121 */     arrayOfDouble3[0][0] = 0.0D;
/* 122 */     if (d1 - localMatrix1.get(0, 0) != 0.0D)
/*     */     {
/* 124 */       i = try_failure(i, "constructWithCopy... ", "copy not effected... data visible outside");
/*     */     } else {
/* 126 */       try_success("constructWithCopy... ", "");
/*     */     }
/* 128 */     arrayOfDouble3[0][0] = arrayOfDouble1[0];
/* 129 */     Matrix localMatrix5 = new Matrix(arrayOfDouble9);
/*     */     try {
/* 131 */       check(localMatrix5, Matrix.identity(3, 4));
/* 132 */       try_success("identity... ", "");
/*     */     } catch (RuntimeException localRuntimeException1) {
/* 134 */       i = try_failure(i, "identity... ", "identity Matrix not successfully created");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 157 */     print("\nTesting access methods...\n");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 163 */     localMatrix1 = new Matrix(arrayOfDouble3);
/* 164 */     if (localMatrix1.getRowDimension() != k) {
/* 165 */       i = try_failure(i, "getRowDimension... ", "");
/*     */     } else {
/* 167 */       try_success("getRowDimension... ", "");
/*     */     }
/* 169 */     if (localMatrix1.getColumnDimension() != m) {
/* 170 */       i = try_failure(i, "getColumnDimension... ", "");
/*     */     } else {
/* 172 */       try_success("getColumnDimension... ", "");
/*     */     }
/* 174 */     localMatrix1 = new Matrix(arrayOfDouble3);
/* 175 */     double[][] arrayOfDouble14 = localMatrix1.getArray();
/* 176 */     if (arrayOfDouble14 != arrayOfDouble3) {
/* 177 */       i = try_failure(i, "getArray... ", "");
/*     */     } else {
/* 179 */       try_success("getArray... ", "");
/*     */     }
/* 181 */     arrayOfDouble14 = localMatrix1.getArrayCopy();
/* 182 */     if (arrayOfDouble14 == arrayOfDouble3) {
/* 183 */       i = try_failure(i, "getArrayCopy... ", "data not (deep) copied");
/*     */     }
/*     */     try {
/* 186 */       check(arrayOfDouble14, arrayOfDouble3);
/* 187 */       try_success("getArrayCopy... ", "");
/*     */     } catch (RuntimeException localRuntimeException2) {
/* 189 */       i = try_failure(i, "getArrayCopy... ", "data not successfully (deep) copied");
/*     */     }
/* 191 */     double[] arrayOfDouble15 = localMatrix1.getColumnPackedCopy();
/*     */     try {
/* 193 */       check(arrayOfDouble15, arrayOfDouble1);
/* 194 */       try_success("getColumnPackedCopy... ", "");
/*     */     } catch (RuntimeException localRuntimeException3) {
/* 196 */       i = try_failure(i, "getColumnPackedCopy... ", "data not successfully (deep) copied by columns");
/*     */     }
/* 198 */     arrayOfDouble15 = localMatrix1.getRowPackedCopy();
/*     */     try {
/* 200 */       check(arrayOfDouble15, arrayOfDouble2);
/* 201 */       try_success("getRowPackedCopy... ", "");
/*     */     } catch (RuntimeException localRuntimeException4) {
/* 203 */       i = try_failure(i, "getRowPackedCopy... ", "data not successfully (deep) copied by rows");
/*     */     }
/*     */     try {
/* 206 */       d1 = localMatrix1.get(localMatrix1.getRowDimension(), localMatrix1.getColumnDimension() - 1);
/* 207 */       i = try_failure(i, "get(int,int)... ", "OutOfBoundsException expected but not thrown");
/*     */     } catch (ArrayIndexOutOfBoundsException localArrayIndexOutOfBoundsException3) {
/*     */       try {
/* 210 */         d1 = localMatrix1.get(localMatrix1.getRowDimension() - 1, localMatrix1.getColumnDimension());
/* 211 */         i = try_failure(i, "get(int,int)... ", "OutOfBoundsException expected but not thrown");
/*     */       } catch (ArrayIndexOutOfBoundsException localArrayIndexOutOfBoundsException23) {
/* 213 */         try_success("get(int,int)... OutofBoundsException... ", "");
/*     */       }
/*     */     } catch (IllegalArgumentException localIllegalArgumentException4) {
/* 216 */       i = try_failure(i, "get(int,int)... ", "OutOfBoundsException expected but not thrown");
/*     */     }
/*     */     try {
/* 219 */       if (localMatrix1.get(localMatrix1.getRowDimension() - 1, localMatrix1.getColumnDimension() - 1) != arrayOfDouble3[(localMatrix1.getRowDimension() - 1)][(localMatrix1.getColumnDimension() - 1)])
/*     */       {
/* 221 */         i = try_failure(i, "get(int,int)... ", "Matrix entry (i,j) not successfully retreived");
/*     */       } else {
/* 223 */         try_success("get(int,int)... ", "");
/*     */       }
/*     */     } catch (ArrayIndexOutOfBoundsException localArrayIndexOutOfBoundsException4) {
/* 226 */       i = try_failure(i, "get(int,int)... ", "Unexpected ArrayIndexOutOfBoundsException");
/*     */     }
/* 228 */     Matrix localMatrix9 = new Matrix(arrayOfDouble6);
/*     */     try {
/* 230 */       localMatrix10 = localMatrix1.getMatrix(i5, i6 + localMatrix1.getRowDimension() + 1, i7, i8);
/* 231 */       i = try_failure(i, "getMatrix(int,int,int,int)... ", "ArrayIndexOutOfBoundsException expected but not thrown");
/*     */     } catch (ArrayIndexOutOfBoundsException localArrayIndexOutOfBoundsException5) {
/*     */       try {
/* 234 */         localMatrix10 = localMatrix1.getMatrix(i5, i6, i7, i8 + localMatrix1.getColumnDimension() + 1);
/* 235 */         i = try_failure(i, "getMatrix(int,int,int,int)... ", "ArrayIndexOutOfBoundsException expected but not thrown");
/*     */       } catch (ArrayIndexOutOfBoundsException localArrayIndexOutOfBoundsException24) {
/* 237 */         try_success("getMatrix(int,int,int,int)... ArrayIndexOutOfBoundsException... ", "");
/*     */       }
/*     */     } catch (IllegalArgumentException localIllegalArgumentException5) {
/* 240 */       i = try_failure(i, "getMatrix(int,int,int,int)... ", "ArrayIndexOutOfBoundsException expected but not thrown");
/*     */     }
/*     */     try {
/* 243 */       localMatrix10 = localMatrix1.getMatrix(i5, i6, i7, i8);
/*     */       try {
/* 245 */         check(localMatrix9, localMatrix10);
/* 246 */         try_success("getMatrix(int,int,int,int)... ", "");
/*     */       } catch (RuntimeException localRuntimeException5) {
/* 248 */         i = try_failure(i, "getMatrix(int,int,int,int)... ", "submatrix not successfully retreived");
/*     */       }
/*     */     } catch (ArrayIndexOutOfBoundsException localArrayIndexOutOfBoundsException6) {
/* 251 */       i = try_failure(i, "getMatrix(int,int,int,int)... ", "Unexpected ArrayIndexOutOfBoundsException");
/*     */     }
/*     */     try
/*     */     {
/* 255 */       localMatrix10 = localMatrix1.getMatrix(i5, i6, arrayOfInt4);
/* 256 */       i = try_failure(i, "getMatrix(int,int,int[])... ", "ArrayIndexOutOfBoundsException expected but not thrown");
/*     */     } catch (ArrayIndexOutOfBoundsException localArrayIndexOutOfBoundsException7) {
/*     */       try {
/* 259 */         localMatrix10 = localMatrix1.getMatrix(i5, i6 + localMatrix1.getRowDimension() + 1, arrayOfInt3);
/* 260 */         i = try_failure(i, "getMatrix(int,int,int[])... ", "ArrayIndexOutOfBoundsException expected but not thrown");
/*     */       } catch (ArrayIndexOutOfBoundsException localArrayIndexOutOfBoundsException25) {
/* 262 */         try_success("getMatrix(int,int,int[])... ArrayIndexOutOfBoundsException... ", "");
/*     */       }
/*     */     } catch (IllegalArgumentException localIllegalArgumentException6) {
/* 265 */       i = try_failure(i, "getMatrix(int,int,int[])... ", "ArrayIndexOutOfBoundsException expected but not thrown");
/*     */     }
/*     */     try {
/* 268 */       localMatrix10 = localMatrix1.getMatrix(i5, i6, arrayOfInt3);
/*     */       try {
/* 270 */         check(localMatrix9, localMatrix10);
/* 271 */         try_success("getMatrix(int,int,int[])... ", "");
/*     */       } catch (RuntimeException localRuntimeException6) {
/* 273 */         i = try_failure(i, "getMatrix(int,int,int[])... ", "submatrix not successfully retreived");
/*     */       }
/*     */     } catch (ArrayIndexOutOfBoundsException localArrayIndexOutOfBoundsException8) {
/* 276 */       i = try_failure(i, "getMatrix(int,int,int[])... ", "Unexpected ArrayIndexOutOfBoundsException");
/*     */     }
/*     */     try {
/* 279 */       localMatrix10 = localMatrix1.getMatrix(arrayOfInt2, i7, i8);
/* 280 */       i = try_failure(i, "getMatrix(int[],int,int)... ", "ArrayIndexOutOfBoundsException expected but not thrown");
/*     */     } catch (ArrayIndexOutOfBoundsException localArrayIndexOutOfBoundsException9) {
/*     */       try {
/* 283 */         localMatrix10 = localMatrix1.getMatrix(arrayOfInt1, i7, i8 + localMatrix1.getColumnDimension() + 1);
/* 284 */         i = try_failure(i, "getMatrix(int[],int,int)... ", "ArrayIndexOutOfBoundsException expected but not thrown");
/*     */       } catch (ArrayIndexOutOfBoundsException localArrayIndexOutOfBoundsException26) {
/* 286 */         try_success("getMatrix(int[],int,int)... ArrayIndexOutOfBoundsException... ", "");
/*     */       }
/*     */     } catch (IllegalArgumentException localIllegalArgumentException7) {
/* 289 */       i = try_failure(i, "getMatrix(int[],int,int)... ", "ArrayIndexOutOfBoundsException expected but not thrown");
/*     */     }
/*     */     try {
/* 292 */       localMatrix10 = localMatrix1.getMatrix(arrayOfInt1, i7, i8);
/*     */       try {
/* 294 */         check(localMatrix9, localMatrix10);
/* 295 */         try_success("getMatrix(int[],int,int)... ", "");
/*     */       } catch (RuntimeException localRuntimeException7) {
/* 297 */         i = try_failure(i, "getMatrix(int[],int,int)... ", "submatrix not successfully retreived");
/*     */       }
/*     */     } catch (ArrayIndexOutOfBoundsException localArrayIndexOutOfBoundsException10) {
/* 300 */       i = try_failure(i, "getMatrix(int[],int,int)... ", "Unexpected ArrayIndexOutOfBoundsException");
/*     */     }
/*     */     try {
/* 303 */       localMatrix10 = localMatrix1.getMatrix(arrayOfInt2, arrayOfInt3);
/* 304 */       i = try_failure(i, "getMatrix(int[],int[])... ", "ArrayIndexOutOfBoundsException expected but not thrown");
/*     */     } catch (ArrayIndexOutOfBoundsException localArrayIndexOutOfBoundsException11) {
/*     */       try {
/* 307 */         localMatrix10 = localMatrix1.getMatrix(arrayOfInt1, arrayOfInt4);
/* 308 */         i = try_failure(i, "getMatrix(int[],int[])... ", "ArrayIndexOutOfBoundsException expected but not thrown");
/*     */       } catch (ArrayIndexOutOfBoundsException localArrayIndexOutOfBoundsException27) {
/* 310 */         try_success("getMatrix(int[],int[])... ArrayIndexOutOfBoundsException... ", "");
/*     */       }
/*     */     } catch (IllegalArgumentException localIllegalArgumentException8) {
/* 313 */       i = try_failure(i, "getMatrix(int[],int[])... ", "ArrayIndexOutOfBoundsException expected but not thrown");
/*     */     }
/*     */     try {
/* 316 */       localMatrix10 = localMatrix1.getMatrix(arrayOfInt1, arrayOfInt3);
/*     */       try {
/* 318 */         check(localMatrix9, localMatrix10);
/* 319 */         try_success("getMatrix(int[],int[])... ", "");
/*     */       } catch (RuntimeException localRuntimeException8) {
/* 321 */         i = try_failure(i, "getMatrix(int[],int[])... ", "submatrix not successfully retreived");
/*     */       }
/*     */     } catch (ArrayIndexOutOfBoundsException localArrayIndexOutOfBoundsException12) {
/* 324 */       i = try_failure(i, "getMatrix(int[],int[])... ", "Unexpected ArrayIndexOutOfBoundsException");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 332 */       localMatrix1.set(localMatrix1.getRowDimension(), localMatrix1.getColumnDimension() - 1, 0.0D);
/* 333 */       i = try_failure(i, "set(int,int,double)... ", "OutOfBoundsException expected but not thrown");
/*     */     } catch (ArrayIndexOutOfBoundsException localArrayIndexOutOfBoundsException13) {
/*     */       try {
/* 336 */         localMatrix1.set(localMatrix1.getRowDimension() - 1, localMatrix1.getColumnDimension(), 0.0D);
/* 337 */         i = try_failure(i, "set(int,int,double)... ", "OutOfBoundsException expected but not thrown");
/*     */       } catch (ArrayIndexOutOfBoundsException localArrayIndexOutOfBoundsException28) {
/* 339 */         try_success("set(int,int,double)... OutofBoundsException... ", "");
/*     */       }
/*     */     } catch (IllegalArgumentException localIllegalArgumentException9) {
/* 342 */       i = try_failure(i, "set(int,int,double)... ", "OutOfBoundsException expected but not thrown");
/*     */     }
/*     */     try {
/* 345 */       localMatrix1.set(i5, i7, 0.0D);
/* 346 */       d1 = localMatrix1.get(i5, i7);
/*     */       try {
/* 348 */         check(d1, 0.0D);
/* 349 */         try_success("set(int,int,double)... ", "");
/*     */       } catch (RuntimeException localRuntimeException9) {
/* 351 */         i = try_failure(i, "set(int,int,double)... ", "Matrix element not successfully set");
/*     */       }
/*     */     } catch (ArrayIndexOutOfBoundsException localArrayIndexOutOfBoundsException14) {
/* 354 */       i = try_failure(i, "set(int,int,double)... ", "Unexpected ArrayIndexOutOfBoundsException");
/*     */     }
/* 356 */     Matrix localMatrix10 = new Matrix(2, 3, 0.0D);
/*     */     try {
/* 358 */       localMatrix1.setMatrix(i5, i6 + localMatrix1.getRowDimension() + 1, i7, i8, localMatrix10);
/* 359 */       i = try_failure(i, "setMatrix(int,int,int,int,Matrix)... ", "ArrayIndexOutOfBoundsException expected but not thrown");
/*     */     } catch (ArrayIndexOutOfBoundsException localArrayIndexOutOfBoundsException15) {
/*     */       try {
/* 362 */         localMatrix1.setMatrix(i5, i6, i7, i8 + localMatrix1.getColumnDimension() + 1, localMatrix10);
/* 363 */         i = try_failure(i, "setMatrix(int,int,int,int,Matrix)... ", "ArrayIndexOutOfBoundsException expected but not thrown");
/*     */       } catch (ArrayIndexOutOfBoundsException localArrayIndexOutOfBoundsException29) {
/* 365 */         try_success("setMatrix(int,int,int,int,Matrix)... ArrayIndexOutOfBoundsException... ", "");
/*     */       }
/*     */     } catch (IllegalArgumentException localIllegalArgumentException10) {
/* 368 */       i = try_failure(i, "setMatrix(int,int,int,int,Matrix)... ", "ArrayIndexOutOfBoundsException expected but not thrown");
/*     */     }
/*     */     try {
/* 371 */       localMatrix1.setMatrix(i5, i6, i7, i8, localMatrix10);
/*     */       try {
/* 373 */         check(localMatrix10.minus(localMatrix1.getMatrix(i5, i6, i7, i8)), localMatrix10);
/* 374 */         try_success("setMatrix(int,int,int,int,Matrix)... ", "");
/*     */       } catch (RuntimeException localRuntimeException10) {
/* 376 */         i = try_failure(i, "setMatrix(int,int,int,int,Matrix)... ", "submatrix not successfully set");
/*     */       }
/* 378 */       localMatrix1.setMatrix(i5, i6, i7, i8, localMatrix9);
/*     */     } catch (ArrayIndexOutOfBoundsException localArrayIndexOutOfBoundsException16) {
/* 380 */       i = try_failure(i, "setMatrix(int,int,int,int,Matrix)... ", "Unexpected ArrayIndexOutOfBoundsException");
/*     */     }
/*     */     try {
/* 383 */       localMatrix1.setMatrix(i5, i6 + localMatrix1.getRowDimension() + 1, arrayOfInt3, localMatrix10);
/* 384 */       i = try_failure(i, "setMatrix(int,int,int[],Matrix)... ", "ArrayIndexOutOfBoundsException expected but not thrown");
/*     */     } catch (ArrayIndexOutOfBoundsException localArrayIndexOutOfBoundsException17) {
/*     */       try {
/* 387 */         localMatrix1.setMatrix(i5, i6, arrayOfInt4, localMatrix10);
/* 388 */         i = try_failure(i, "setMatrix(int,int,int[],Matrix)... ", "ArrayIndexOutOfBoundsException expected but not thrown");
/*     */       } catch (ArrayIndexOutOfBoundsException localArrayIndexOutOfBoundsException30) {
/* 390 */         try_success("setMatrix(int,int,int[],Matrix)... ArrayIndexOutOfBoundsException... ", "");
/*     */       }
/*     */     } catch (IllegalArgumentException localIllegalArgumentException11) {
/* 393 */       i = try_failure(i, "setMatrix(int,int,int[],Matrix)... ", "ArrayIndexOutOfBoundsException expected but not thrown");
/*     */     }
/*     */     try {
/* 396 */       localMatrix1.setMatrix(i5, i6, arrayOfInt3, localMatrix10);
/*     */       try {
/* 398 */         check(localMatrix10.minus(localMatrix1.getMatrix(i5, i6, arrayOfInt3)), localMatrix10);
/* 399 */         try_success("setMatrix(int,int,int[],Matrix)... ", "");
/*     */       } catch (RuntimeException localRuntimeException11) {
/* 401 */         i = try_failure(i, "setMatrix(int,int,int[],Matrix)... ", "submatrix not successfully set");
/*     */       }
/* 403 */       localMatrix1.setMatrix(i5, i6, i7, i8, localMatrix9);
/*     */     } catch (ArrayIndexOutOfBoundsException localArrayIndexOutOfBoundsException18) {
/* 405 */       i = try_failure(i, "setMatrix(int,int,int[],Matrix)... ", "Unexpected ArrayIndexOutOfBoundsException");
/*     */     }
/*     */     try {
/* 408 */       localMatrix1.setMatrix(arrayOfInt1, i7, i8 + localMatrix1.getColumnDimension() + 1, localMatrix10);
/* 409 */       i = try_failure(i, "setMatrix(int[],int,int,Matrix)... ", "ArrayIndexOutOfBoundsException expected but not thrown");
/*     */     } catch (ArrayIndexOutOfBoundsException localArrayIndexOutOfBoundsException19) {
/*     */       try {
/* 412 */         localMatrix1.setMatrix(arrayOfInt2, i7, i8, localMatrix10);
/* 413 */         i = try_failure(i, "setMatrix(int[],int,int,Matrix)... ", "ArrayIndexOutOfBoundsException expected but not thrown");
/*     */       } catch (ArrayIndexOutOfBoundsException localArrayIndexOutOfBoundsException31) {
/* 415 */         try_success("setMatrix(int[],int,int,Matrix)... ArrayIndexOutOfBoundsException... ", "");
/*     */       }
/*     */     } catch (IllegalArgumentException localIllegalArgumentException12) {
/* 418 */       i = try_failure(i, "setMatrix(int[],int,int,Matrix)... ", "ArrayIndexOutOfBoundsException expected but not thrown");
/*     */     }
/*     */     try {
/* 421 */       localMatrix1.setMatrix(arrayOfInt1, i7, i8, localMatrix10);
/*     */       try {
/* 423 */         check(localMatrix10.minus(localMatrix1.getMatrix(arrayOfInt1, i7, i8)), localMatrix10);
/* 424 */         try_success("setMatrix(int[],int,int,Matrix)... ", "");
/*     */       } catch (RuntimeException localRuntimeException12) {
/* 426 */         i = try_failure(i, "setMatrix(int[],int,int,Matrix)... ", "submatrix not successfully set");
/*     */       }
/* 428 */       localMatrix1.setMatrix(i5, i6, i7, i8, localMatrix9);
/*     */     } catch (ArrayIndexOutOfBoundsException localArrayIndexOutOfBoundsException20) {
/* 430 */       i = try_failure(i, "setMatrix(int[],int,int,Matrix)... ", "Unexpected ArrayIndexOutOfBoundsException");
/*     */     }
/*     */     try {
/* 433 */       localMatrix1.setMatrix(arrayOfInt1, arrayOfInt4, localMatrix10);
/* 434 */       i = try_failure(i, "setMatrix(int[],int[],Matrix)... ", "ArrayIndexOutOfBoundsException expected but not thrown");
/*     */     } catch (ArrayIndexOutOfBoundsException localArrayIndexOutOfBoundsException21) {
/*     */       try {
/* 437 */         localMatrix1.setMatrix(arrayOfInt2, arrayOfInt3, localMatrix10);
/* 438 */         i = try_failure(i, "setMatrix(int[],int[],Matrix)... ", "ArrayIndexOutOfBoundsException expected but not thrown");
/*     */       } catch (ArrayIndexOutOfBoundsException localArrayIndexOutOfBoundsException32) {
/* 440 */         try_success("setMatrix(int[],int[],Matrix)... ArrayIndexOutOfBoundsException... ", "");
/*     */       }
/*     */     } catch (IllegalArgumentException localIllegalArgumentException13) {
/* 443 */       i = try_failure(i, "setMatrix(int[],int[],Matrix)... ", "ArrayIndexOutOfBoundsException expected but not thrown");
/*     */     }
/*     */     try {
/* 446 */       localMatrix1.setMatrix(arrayOfInt1, arrayOfInt3, localMatrix10);
/*     */       try {
/* 448 */         check(localMatrix10.minus(localMatrix1.getMatrix(arrayOfInt1, arrayOfInt3)), localMatrix10);
/* 449 */         try_success("setMatrix(int[],int[],Matrix)... ", "");
/*     */       } catch (RuntimeException localRuntimeException13) {
/* 451 */         i = try_failure(i, "setMatrix(int[],int[],Matrix)... ", "submatrix not successfully set");
/*     */       }
/*     */     } catch (ArrayIndexOutOfBoundsException localArrayIndexOutOfBoundsException22) {
/* 454 */       i = try_failure(i, "setMatrix(int[],int[],Matrix)... ", "Unexpected ArrayIndexOutOfBoundsException");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 472 */     print("\nTesting array-like methods...\n");
/* 473 */     Matrix localMatrix7 = new Matrix(arrayOfDouble1, i4);
/* 474 */     Matrix localMatrix6 = Matrix.random(((Matrix)localObject1).getRowDimension(), ((Matrix)localObject1).getColumnDimension());
/* 475 */     localObject1 = localMatrix6;
/*     */     try {
/* 477 */       localMatrix7 = ((Matrix)localObject1).minus(localMatrix7);
/* 478 */       i = try_failure(i, "minus conformance check... ", "nonconformance not raised");
/*     */     } catch (IllegalArgumentException localIllegalArgumentException14) {
/* 480 */       try_success("minus conformance check... ", "");
/*     */     }
/* 482 */     if (((Matrix)localObject1).minus(localMatrix6).norm1() != 0.0D) {
/* 483 */       i = try_failure(i, "minus... ", "(difference of identical Matrices is nonzero,\nSubsequent use of minus should be suspect)");
/*     */     } else {
/* 485 */       try_success("minus... ", "");
/*     */     }
/* 487 */     localObject1 = localMatrix6.copy();
/* 488 */     ((Matrix)localObject1).minusEquals(localMatrix6);
/* 489 */     Matrix localMatrix3 = new Matrix(((Matrix)localObject1).getRowDimension(), ((Matrix)localObject1).getColumnDimension());
/*     */     try {
/* 491 */       ((Matrix)localObject1).minusEquals(localMatrix7);
/* 492 */       i = try_failure(i, "minusEquals conformance check... ", "nonconformance not raised");
/*     */     } catch (IllegalArgumentException localIllegalArgumentException15) {
/* 494 */       try_success("minusEquals conformance check... ", "");
/*     */     }
/* 496 */     if (((Matrix)localObject1).minus(localMatrix3).norm1() != 0.0D) {
/* 497 */       i = try_failure(i, "minusEquals... ", "(difference of identical Matrices is nonzero,\nSubsequent use of minus should be suspect)");
/*     */     } else {
/* 499 */       try_success("minusEquals... ", "");
/*     */     }
/*     */     
/* 502 */     localObject1 = localMatrix6.copy();
/* 503 */     localMatrix1 = Matrix.random(((Matrix)localObject1).getRowDimension(), ((Matrix)localObject1).getColumnDimension());
/* 504 */     localMatrix2 = ((Matrix)localObject1).minus(localMatrix1);
/*     */     try {
/* 506 */       localMatrix7 = ((Matrix)localObject1).plus(localMatrix7);
/* 507 */       i = try_failure(i, "plus conformance check... ", "nonconformance not raised");
/*     */     } catch (IllegalArgumentException localIllegalArgumentException16) {
/* 509 */       try_success("plus conformance check... ", "");
/*     */     }
/*     */     try {
/* 512 */       check(localMatrix2.plus(localMatrix1), (Matrix)localObject1);
/* 513 */       try_success("plus... ", "");
/*     */     } catch (RuntimeException localRuntimeException14) {
/* 515 */       i = try_failure(i, "plus... ", "(C = A - B, but C + B != A)");
/*     */     }
/* 517 */     localMatrix2 = ((Matrix)localObject1).minus(localMatrix1);
/* 518 */     localMatrix2.plusEquals(localMatrix1);
/*     */     try {
/* 520 */       ((Matrix)localObject1).plusEquals(localMatrix7);
/* 521 */       i = try_failure(i, "plusEquals conformance check... ", "nonconformance not raised");
/*     */     } catch (IllegalArgumentException localIllegalArgumentException17) {
/* 523 */       try_success("plusEquals conformance check... ", "");
/*     */     }
/*     */     try {
/* 526 */       check(localMatrix2, (Matrix)localObject1);
/* 527 */       try_success("plusEquals... ", "");
/*     */     } catch (RuntimeException localRuntimeException15) {
/* 529 */       i = try_failure(i, "plusEquals... ", "(C = A - B, but C = C + B != A)");
/*     */     }
/* 531 */     localObject1 = localMatrix6.uminus();
/*     */     try {
/* 533 */       check(((Matrix)localObject1).plus(localMatrix6), localMatrix3);
/* 534 */       try_success("uminus... ", "");
/*     */     } catch (RuntimeException localRuntimeException16) {
/* 536 */       i = try_failure(i, "uminus... ", "(-A + A != zeros)");
/*     */     }
/* 538 */     localObject1 = localMatrix6.copy();
/* 539 */     Matrix localMatrix4 = new Matrix(((Matrix)localObject1).getRowDimension(), ((Matrix)localObject1).getColumnDimension(), 1.0D);
/* 540 */     localMatrix2 = ((Matrix)localObject1).arrayLeftDivide(localMatrix6);
/*     */     try {
/* 542 */       localMatrix7 = ((Matrix)localObject1).arrayLeftDivide(localMatrix7);
/* 543 */       i = try_failure(i, "arrayLeftDivide conformance check... ", "nonconformance not raised");
/*     */     } catch (IllegalArgumentException localIllegalArgumentException18) {
/* 545 */       try_success("arrayLeftDivide conformance check... ", "");
/*     */     }
/*     */     try {
/* 548 */       check(localMatrix2, localMatrix4);
/* 549 */       try_success("arrayLeftDivide... ", "");
/*     */     } catch (RuntimeException localRuntimeException17) {
/* 551 */       i = try_failure(i, "arrayLeftDivide... ", "(M.\\M != ones)");
/*     */     }
/*     */     try {
/* 554 */       ((Matrix)localObject1).arrayLeftDivideEquals(localMatrix7);
/* 555 */       i = try_failure(i, "arrayLeftDivideEquals conformance check... ", "nonconformance not raised");
/*     */     } catch (IllegalArgumentException localIllegalArgumentException19) {
/* 557 */       try_success("arrayLeftDivideEquals conformance check... ", "");
/*     */     }
/* 559 */     ((Matrix)localObject1).arrayLeftDivideEquals(localMatrix6);
/*     */     try {
/* 561 */       check((Matrix)localObject1, localMatrix4);
/* 562 */       try_success("arrayLeftDivideEquals... ", "");
/*     */     } catch (RuntimeException localRuntimeException18) {
/* 564 */       i = try_failure(i, "arrayLeftDivideEquals... ", "(M.\\M != ones)");
/*     */     }
/* 566 */     localObject1 = localMatrix6.copy();
/*     */     try {
/* 568 */       ((Matrix)localObject1).arrayRightDivide(localMatrix7);
/* 569 */       i = try_failure(i, "arrayRightDivide conformance check... ", "nonconformance not raised");
/*     */     } catch (IllegalArgumentException localIllegalArgumentException20) {
/* 571 */       try_success("arrayRightDivide conformance check... ", "");
/*     */     }
/* 573 */     localMatrix2 = ((Matrix)localObject1).arrayRightDivide(localMatrix6);
/*     */     try {
/* 575 */       check(localMatrix2, localMatrix4);
/* 576 */       try_success("arrayRightDivide... ", "");
/*     */     } catch (RuntimeException localRuntimeException19) {
/* 578 */       i = try_failure(i, "arrayRightDivide... ", "(M./M != ones)");
/*     */     }
/*     */     try {
/* 581 */       ((Matrix)localObject1).arrayRightDivideEquals(localMatrix7);
/* 582 */       i = try_failure(i, "arrayRightDivideEquals conformance check... ", "nonconformance not raised");
/*     */     } catch (IllegalArgumentException localIllegalArgumentException21) {
/* 584 */       try_success("arrayRightDivideEquals conformance check... ", "");
/*     */     }
/* 586 */     ((Matrix)localObject1).arrayRightDivideEquals(localMatrix6);
/*     */     try {
/* 588 */       check((Matrix)localObject1, localMatrix4);
/* 589 */       try_success("arrayRightDivideEquals... ", "");
/*     */     } catch (RuntimeException localRuntimeException20) {
/* 591 */       i = try_failure(i, "arrayRightDivideEquals... ", "(M./M != ones)");
/*     */     }
/* 593 */     localObject1 = localMatrix6.copy();
/* 594 */     localMatrix1 = Matrix.random(((Matrix)localObject1).getRowDimension(), ((Matrix)localObject1).getColumnDimension());
/*     */     try {
/* 596 */       localMatrix7 = ((Matrix)localObject1).arrayTimes(localMatrix7);
/* 597 */       i = try_failure(i, "arrayTimes conformance check... ", "nonconformance not raised");
/*     */     } catch (IllegalArgumentException localIllegalArgumentException22) {
/* 599 */       try_success("arrayTimes conformance check... ", "");
/*     */     }
/* 601 */     localMatrix2 = ((Matrix)localObject1).arrayTimes(localMatrix1);
/*     */     try {
/* 603 */       check(localMatrix2.arrayRightDivideEquals(localMatrix1), (Matrix)localObject1);
/* 604 */       try_success("arrayTimes... ", "");
/*     */     } catch (RuntimeException localRuntimeException21) {
/* 606 */       i = try_failure(i, "arrayTimes... ", "(A = R, C = A.*B, but C./B != A)");
/*     */     }
/*     */     try {
/* 609 */       ((Matrix)localObject1).arrayTimesEquals(localMatrix7);
/* 610 */       i = try_failure(i, "arrayTimesEquals conformance check... ", "nonconformance not raised");
/*     */     } catch (IllegalArgumentException localIllegalArgumentException23) {
/* 612 */       try_success("arrayTimesEquals conformance check... ", "");
/*     */     }
/* 614 */     ((Matrix)localObject1).arrayTimesEquals(localMatrix1);
/*     */     try {
/* 616 */       check(((Matrix)localObject1).arrayRightDivideEquals(localMatrix1), localMatrix6);
/* 617 */       try_success("arrayTimesEquals... ", "");
/*     */     } catch (RuntimeException localRuntimeException22) {
/* 619 */       i = try_failure(i, "arrayTimesEquals... ", "(A = R, A = A.*B, but A./B != R)");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 630 */     print("\nTesting I/O methods...\n");
/*     */     Object localObject3;
/* 632 */     try { DecimalFormat localDecimalFormat = new DecimalFormat("0.0000E00");
/* 633 */       localDecimalFormat.setDecimalFormatSymbols(new DecimalFormatSymbols(Locale.US));
/*     */       
/* 635 */       localObject2 = new PrintWriter(new FileOutputStream("JamaTestMatrix.out"));
/* 636 */       ((Matrix)localObject1).print((PrintWriter)localObject2, localDecimalFormat, 10);
/* 637 */       ((PrintWriter)localObject2).close();
/* 638 */       localMatrix6 = Matrix.read(new BufferedReader(new FileReader("JamaTestMatrix.out")));
/* 639 */       if (((Matrix)localObject1).minus(localMatrix6).norm1() < 0.001D) {
/* 640 */         try_success("print()/read()...", "");
/*     */       } else {
/* 642 */         i = try_failure(i, "print()/read()...", "Matrix read from file does not match Matrix printed to file");
/*     */       }
/*     */     } catch (IOException localIOException1) {
/* 645 */       j = try_warning(j, "print()/read()...", "unexpected I/O error, unable to run print/read test;  check write permission in current directory and retry");
/*     */     } catch (Exception localException1) {
/*     */       try {
/* 648 */         localException1.printStackTrace(System.out);
/* 649 */         j = try_warning(j, "print()/read()...", "Formatting error... will try JDK1.1 reformulation...");
/* 650 */         Object localObject2 = new DecimalFormat("0.0000");
/* 651 */         localObject3 = new PrintWriter(new FileOutputStream("JamaTestMatrix.out"));
/* 652 */         ((Matrix)localObject1).print((PrintWriter)localObject3, (NumberFormat)localObject2, 10);
/* 653 */         ((PrintWriter)localObject3).close();
/* 654 */         localMatrix6 = Matrix.read(new BufferedReader(new FileReader("JamaTestMatrix.out")));
/* 655 */         if (((Matrix)localObject1).minus(localMatrix6).norm1() < 0.001D) {
/* 656 */           try_success("print()/read()...", "");
/*     */         } else {
/* 658 */           i = try_failure(i, "print()/read() (2nd attempt) ...", "Matrix read from file does not match Matrix printed to file");
/*     */         }
/*     */       } catch (IOException localIOException2) {
/* 661 */         j = try_warning(j, "print()/read()...", "unexpected I/O error, unable to run print/read test;  check write permission in current directory and retry");
/*     */       }
/*     */     }
/*     */     
/* 665 */     localMatrix6 = Matrix.random(((Matrix)localObject1).getRowDimension(), ((Matrix)localObject1).getColumnDimension());
/* 666 */     String str = "TMPMATRIX.serial";
/*     */     try {
/* 668 */       ObjectOutputStream localObjectOutputStream = new ObjectOutputStream(new FileOutputStream(str));
/* 669 */       localObjectOutputStream.writeObject(localMatrix6);
/* 670 */       localObject3 = new ObjectInputStream(new FileInputStream(str));
/* 671 */       localObject1 = (Matrix)((ObjectInputStream)localObject3).readObject();
/*     */       try
/*     */       {
/* 674 */         check((Matrix)localObject1, localMatrix6);
/* 675 */         try_success("writeObject(Matrix)/readObject(Matrix)...", "");
/*     */       } catch (RuntimeException localRuntimeException32) {
/* 677 */         i = try_failure(i, "writeObject(Matrix)/readObject(Matrix)...", "Matrix not serialized correctly");
/*     */       }
/*     */     } catch (IOException localIOException3) {
/* 680 */       j = try_warning(j, "writeObject()/readObject()...", "unexpected I/O error, unable to run serialization test;  check write permission in current directory and retry");
/*     */     } catch (Exception localException2) {
/* 682 */       i = try_failure(i, "writeObject(Matrix)/readObject(Matrix)...", "unexpected error in serialization test");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 707 */     print("\nTesting linear algebra methods...\n");
/* 708 */     localObject1 = new Matrix(arrayOfDouble1, 3);
/* 709 */     Matrix localMatrix11 = new Matrix(arrayOfDouble5);
/* 710 */     localMatrix11 = ((Matrix)localObject1).transpose();
/*     */     try {
/* 712 */       check(((Matrix)localObject1).transpose(), localMatrix11);
/* 713 */       try_success("transpose...", "");
/*     */     } catch (RuntimeException localRuntimeException23) {
/* 715 */       i = try_failure(i, "transpose()...", "transpose unsuccessful");
/*     */     }
/* 717 */     ((Matrix)localObject1).transpose();
/*     */     try {
/* 719 */       check(((Matrix)localObject1).norm1(), d2);
/* 720 */       try_success("norm1...", "");
/*     */     } catch (RuntimeException localRuntimeException24) {
/* 722 */       i = try_failure(i, "norm1()...", "incorrect norm calculation");
/*     */     }
/*     */     try {
/* 725 */       check(((Matrix)localObject1).normInf(), d3);
/* 726 */       try_success("normInf()...", "");
/*     */     } catch (RuntimeException localRuntimeException25) {
/* 728 */       i = try_failure(i, "normInf()...", "incorrect norm calculation");
/*     */     }
/*     */     try {
/* 731 */       check(((Matrix)localObject1).normF(), Math.sqrt(d5));
/* 732 */       try_success("normF...", "");
/*     */     } catch (RuntimeException localRuntimeException26) {
/* 734 */       i = try_failure(i, "normF()...", "incorrect norm calculation");
/*     */     }
/*     */     try {
/* 737 */       check(((Matrix)localObject1).trace(), d4);
/* 738 */       try_success("trace()...", "");
/*     */     } catch (RuntimeException localRuntimeException27) {
/* 740 */       i = try_failure(i, "trace()...", "incorrect trace calculation");
/*     */     }
/*     */     try {
/* 743 */       check(((Matrix)localObject1).getMatrix(0, ((Matrix)localObject1).getRowDimension() - 1, 0, ((Matrix)localObject1).getRowDimension() - 1).det(), 0.0D);
/* 744 */       try_success("det()...", "");
/*     */     } catch (RuntimeException localRuntimeException28) {
/* 746 */       i = try_failure(i, "det()...", "incorrect determinant calculation");
/*     */     }
/* 748 */     Matrix localMatrix12 = new Matrix(arrayOfDouble11);
/*     */     try {
/* 750 */       check(((Matrix)localObject1).times(((Matrix)localObject1).transpose()), localMatrix12);
/* 751 */       try_success("times(Matrix)...", "");
/*     */     } catch (RuntimeException localRuntimeException29) {
/* 753 */       i = try_failure(i, "times(Matrix)...", "incorrect Matrix-Matrix product calculation");
/*     */     }
/*     */     try {
/* 756 */       check(((Matrix)localObject1).times(0.0D), localMatrix3);
/* 757 */       try_success("times(double)...", "");
/*     */     } catch (RuntimeException localRuntimeException30) {
/* 759 */       i = try_failure(i, "times(double)...", "incorrect Matrix-scalar product calculation");
/*     */     }
/*     */     
/* 762 */     localObject1 = new Matrix(arrayOfDouble1, 4);
/* 763 */     QRDecomposition localQRDecomposition = ((Matrix)localObject1).qr();
/* 764 */     localMatrix6 = localQRDecomposition.getR();
/*     */     try {
/* 766 */       check((Matrix)localObject1, localQRDecomposition.getQ().times(localMatrix6));
/* 767 */       try_success("QRDecomposition...", "");
/*     */     } catch (RuntimeException localRuntimeException31) {
/* 769 */       i = try_failure(i, "QRDecomposition...", "incorrect QR decomposition calculation");
/*     */     }
/* 771 */     SingularValueDecomposition localSingularValueDecomposition = ((Matrix)localObject1).svd();
/*     */     try {
/* 773 */       check((Matrix)localObject1, localSingularValueDecomposition.getU().times(localSingularValueDecomposition.getS().times(localSingularValueDecomposition.getV().transpose())));
/* 774 */       try_success("SingularValueDecomposition...", "");
/*     */     } catch (RuntimeException localRuntimeException33) {
/* 776 */       i = try_failure(i, "SingularValueDecomposition...", "incorrect singular value decomposition calculation");
/*     */     }
/* 778 */     Matrix localMatrix13 = new Matrix(arrayOfDouble4);
/*     */     try {
/* 780 */       check(localMatrix13.rank(), Math.min(localMatrix13.getRowDimension(), localMatrix13.getColumnDimension()) - 1);
/* 781 */       try_success("rank()...", "");
/*     */     } catch (RuntimeException localRuntimeException34) {
/* 783 */       i = try_failure(i, "rank()...", "incorrect rank calculation");
/*     */     }
/* 785 */     localMatrix1 = new Matrix(arrayOfDouble13);
/* 786 */     localSingularValueDecomposition = localMatrix1.svd();
/* 787 */     double[] arrayOfDouble16 = localSingularValueDecomposition.getSingularValues();
/*     */     try {
/* 789 */       check(localMatrix1.cond(), arrayOfDouble16[0] / arrayOfDouble16[(Math.min(localMatrix1.getRowDimension(), localMatrix1.getColumnDimension()) - 1)]);
/* 790 */       try_success("cond()...", "");
/*     */     } catch (RuntimeException localRuntimeException35) {
/* 792 */       i = try_failure(i, "cond()...", "incorrect condition number calculation");
/*     */     }
/* 794 */     int i9 = ((Matrix)localObject1).getColumnDimension();
/* 795 */     localObject1 = ((Matrix)localObject1).getMatrix(0, i9 - 1, 0, i9 - 1);
/* 796 */     ((Matrix)localObject1).set(0, 0, 0.0D);
/* 797 */     LUDecomposition localLUDecomposition = ((Matrix)localObject1).lu();
/*     */     try {
/* 799 */       check(((Matrix)localObject1).getMatrix(localLUDecomposition.getPivot(), 0, i9 - 1), localLUDecomposition.getL().times(localLUDecomposition.getU()));
/* 800 */       try_success("LUDecomposition...", "");
/*     */     } catch (RuntimeException localRuntimeException36) {
/* 802 */       i = try_failure(i, "LUDecomposition...", "incorrect LU decomposition calculation");
/*     */     }
/* 804 */     Matrix localMatrix8 = ((Matrix)localObject1).inverse();
/*     */     try {
/* 806 */       check(((Matrix)localObject1).times(localMatrix8), Matrix.identity(3, 3));
/* 807 */       try_success("inverse()...", "");
/*     */     } catch (RuntimeException localRuntimeException37) {
/* 809 */       i = try_failure(i, "inverse()...", "incorrect inverse calculation");
/*     */     }
/* 811 */     localMatrix4 = new Matrix(localMatrix9.getRowDimension(), 1, 1.0D);
/* 812 */     Matrix localMatrix14 = new Matrix(arrayOfDouble12);
/* 813 */     localMatrix12 = localMatrix9.getMatrix(0, localMatrix9.getRowDimension() - 1, 0, localMatrix9.getRowDimension() - 1);
/*     */     try {
/* 815 */       check(localMatrix12.solve(localMatrix14), localMatrix4);
/* 816 */       try_success("solve()...", "");
/*     */     } catch (IllegalArgumentException localIllegalArgumentException24) {
/* 818 */       i = try_failure(i, "solve()...", localIllegalArgumentException24.getMessage());
/*     */     } catch (RuntimeException localRuntimeException38) {
/* 820 */       i = try_failure(i, "solve()...", localRuntimeException38.getMessage());
/*     */     }
/* 822 */     localObject1 = new Matrix(arrayOfDouble8);
/* 823 */     CholeskyDecomposition localCholeskyDecomposition = ((Matrix)localObject1).chol();
/* 824 */     Matrix localMatrix15 = localCholeskyDecomposition.getL();
/*     */     try {
/* 826 */       check((Matrix)localObject1, localMatrix15.times(localMatrix15.transpose()));
/* 827 */       try_success("CholeskyDecomposition...", "");
/*     */     } catch (RuntimeException localRuntimeException39) {
/* 829 */       i = try_failure(i, "CholeskyDecomposition...", "incorrect Cholesky decomposition calculation");
/*     */     }
/* 831 */     localMatrix8 = localCholeskyDecomposition.solve(Matrix.identity(3, 3));
/*     */     try {
/* 833 */       check(((Matrix)localObject1).times(localMatrix8), Matrix.identity(3, 3));
/* 834 */       try_success("CholeskyDecomposition solve()...", "");
/*     */     } catch (RuntimeException localRuntimeException40) {
/* 836 */       i = try_failure(i, "CholeskyDecomposition solve()...", "incorrect Choleskydecomposition solve calculation");
/*     */     }
/* 838 */     EigenvalueDecomposition localEigenvalueDecomposition = ((Matrix)localObject1).eig();
/* 839 */     Matrix localMatrix16 = localEigenvalueDecomposition.getD();
/* 840 */     Matrix localMatrix17 = localEigenvalueDecomposition.getV();
/*     */     try {
/* 842 */       check(((Matrix)localObject1).times(localMatrix17), localMatrix17.times(localMatrix16));
/* 843 */       try_success("EigenvalueDecomposition (symmetric)...", "");
/*     */     } catch (RuntimeException localRuntimeException41) {
/* 845 */       i = try_failure(i, "EigenvalueDecomposition (symmetric)...", "incorrect symmetric Eigenvalue decomposition calculation");
/*     */     }
/* 847 */     localObject1 = new Matrix(arrayOfDouble10);
/* 848 */     localEigenvalueDecomposition = ((Matrix)localObject1).eig();
/* 849 */     localMatrix16 = localEigenvalueDecomposition.getD();
/* 850 */     localMatrix17 = localEigenvalueDecomposition.getV();
/*     */     try {
/* 852 */       check(((Matrix)localObject1).times(localMatrix17), localMatrix17.times(localMatrix16));
/* 853 */       try_success("EigenvalueDecomposition (nonsymmetric)...", "");
/*     */     } catch (RuntimeException localRuntimeException42) {
/* 855 */       i = try_failure(i, "EigenvalueDecomposition (nonsymmetric)...", "incorrect nonsymmetric Eigenvalue decomposition calculation");
/*     */     }
/*     */     
/* 858 */     print("\nTestMatrix completed.\n");
/* 859 */     print("Total errors reported: " + Integer.toString(i) + "\n");
/* 860 */     print("Total warnings reported: " + Integer.toString(j) + "\n");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void check(double paramDouble1, double paramDouble2)
/*     */   {
/* 868 */     double d = Math.pow(2.0D, -52.0D);
/* 869 */     if (((paramDouble1 == 0.0D ? 1 : 0) & (Math.abs(paramDouble2) < 10.0D * d ? 1 : 0)) != 0) return;
/* 870 */     if (((paramDouble2 == 0.0D ? 1 : 0) & (Math.abs(paramDouble1) < 10.0D * d ? 1 : 0)) != 0) return;
/* 871 */     if (Math.abs(paramDouble1 - paramDouble2) > 10.0D * d * Math.max(Math.abs(paramDouble1), Math.abs(paramDouble2))) {
/* 872 */       throw new RuntimeException("The difference x-y is too large: x = " + Double.toString(paramDouble1) + "  y = " + Double.toString(paramDouble2));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static void check(double[] paramArrayOfDouble1, double[] paramArrayOfDouble2)
/*     */   {
/* 879 */     if (paramArrayOfDouble1.length == paramArrayOfDouble2.length) {
/* 880 */       for (int i = 0; i < paramArrayOfDouble1.length; i++) {
/* 881 */         check(paramArrayOfDouble1[i], paramArrayOfDouble2[i]);
/*     */       }
/*     */     } else {
/* 884 */       throw new RuntimeException("Attempt to compare vectors of different lengths");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static void check(double[][] paramArrayOfDouble1, double[][] paramArrayOfDouble2)
/*     */   {
/* 891 */     Matrix localMatrix1 = new Matrix(paramArrayOfDouble1);
/* 892 */     Matrix localMatrix2 = new Matrix(paramArrayOfDouble2);
/* 893 */     check(localMatrix1, localMatrix2);
/*     */   }
/*     */   
/*     */ 
/*     */   private static void check(Matrix paramMatrix1, Matrix paramMatrix2)
/*     */   {
/* 899 */     double d = Math.pow(2.0D, -52.0D);
/* 900 */     if (((paramMatrix1.norm1() == 0.0D ? 1 : 0) & (paramMatrix2.norm1() < 10.0D * d ? 1 : 0)) != 0) return;
/* 901 */     if (((paramMatrix2.norm1() == 0.0D ? 1 : 0) & (paramMatrix1.norm1() < 10.0D * d ? 1 : 0)) != 0) return;
/* 902 */     if (paramMatrix1.minus(paramMatrix2).norm1() > 1000.0D * d * Math.max(paramMatrix1.norm1(), paramMatrix2.norm1())) {
/* 903 */       throw new RuntimeException("The norm of (X-Y) is too large: " + Double.toString(paramMatrix1.minus(paramMatrix2).norm1()));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static void print(String paramString)
/*     */   {
/* 910 */     System.out.print(paramString);
/*     */   }
/*     */   
/*     */ 
/*     */   private static void try_success(String paramString1, String paramString2)
/*     */   {
/* 916 */     print(">    " + paramString1 + "success\n");
/* 917 */     if (paramString2 != "") {
/* 918 */       print(">      Message: " + paramString2 + "\n");
/*     */     }
/*     */   }
/*     */   
/*     */   private static int try_failure(int paramInt, String paramString1, String paramString2)
/*     */   {
/* 924 */     print(">    " + paramString1 + "*** failure ***\n>      Message: " + paramString2 + "\n");
/* 925 */     paramInt++;return paramInt;
/*     */   }
/*     */   
/*     */ 
/*     */   private static int try_warning(int paramInt, String paramString1, String paramString2)
/*     */   {
/* 931 */     print(">    " + paramString1 + "*** warning ***\n>      Message: " + paramString2 + "\n");
/* 932 */     paramInt++;return paramInt;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static void print(double[] paramArrayOfDouble, int paramInt1, int paramInt2)
/*     */   {
/* 939 */     System.out.print("\n");
/* 940 */     new Matrix(paramArrayOfDouble, 1).print(paramInt1, paramInt2);
/* 941 */     print("\n");
/*     */   }
/*     */ }


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp1\Exp1 (1).zip!\Exp1\lib\Jama-1.0.2.jar!\Jama\test\TestMatrix.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */