package org.jfree.data.general;

public abstract interface HeatMapDataset
{
  public abstract int getXSampleCount();
  
  public abstract int getYSampleCount();
  
  public abstract double getMinimumXValue();
  
  public abstract double getMaximumXValue();
  
  public abstract double getMinimumYValue();
  
  public abstract double getMaximumYValue();
  
  public abstract double getXValue(int paramInt);
  
  public abstract double getYValue(int paramInt);
  
  public abstract double getZValue(int paramInt1, int paramInt2);
  
  public abstract Number getZ(int paramInt1, int paramInt2);
}


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp1\Exp1 (1).zip!\Exp1\lib\jfreechart-1.0.13.jar!\org\jfree\data\general\HeatMapDataset.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       0.7.1
 */