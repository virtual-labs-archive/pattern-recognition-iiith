package org.jfree.chart;

public abstract interface Effect3D
{
  public abstract double getXOffset();
  
  public abstract double getYOffset();
}


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp1\Exp1 (1).zip!\Exp1\lib\jfreechart-1.0.13.jar!\org\jfree\chart\Effect3D.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       0.7.1
 */