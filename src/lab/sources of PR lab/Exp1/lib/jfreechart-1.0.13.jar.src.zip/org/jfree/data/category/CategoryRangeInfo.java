package org.jfree.data.category;

import java.util.List;
import org.jfree.data.Range;

public abstract interface CategoryRangeInfo
{
  public abstract Range getRangeBounds(List paramList, boolean paramBoolean);
}


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp1\Exp1 (1).zip!\Exp1\lib\jfreechart-1.0.13.jar!\org\jfree\data\category\CategoryRangeInfo.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       0.7.1
 */