/*    */ package org.jfree.chart.resources;
/*    */ 
/*    */ import java.util.ListResourceBundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JFreeChartResources
/*    */   extends ListResourceBundle
/*    */ {
/*    */   public Object[][] getContents()
/*    */   {
/* 52 */     return CONTENTS;
/*    */   }
/*    */   
/*    */ 
/* 56 */   private static final Object[][] CONTENTS = { { "project.name", "JFreeChart" }, { "project.version", "1.0.13" }, { "project.info", "http://www.jfree.org/jfreechart/index.html" }, { "project.copyright", "(C)opyright 2000-2009, by Object Refinery Limited and Contributors" } };
/*    */ }


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp1\Exp1 (1).zip!\Exp1\lib\jfreechart-1.0.13.jar!\org\jfree\chart\resources\JFreeChartResources.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       0.7.1
 */