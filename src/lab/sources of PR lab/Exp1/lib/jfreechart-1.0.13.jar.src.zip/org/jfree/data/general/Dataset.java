package org.jfree.data.general;

public abstract interface Dataset
{
  public abstract void addChangeListener(DatasetChangeListener paramDatasetChangeListener);
  
  public abstract void removeChangeListener(DatasetChangeListener paramDatasetChangeListener);
  
  public abstract DatasetGroup getGroup();
  
  public abstract void setGroup(DatasetGroup paramDatasetGroup);
}


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp1\Exp1 (1).zip!\Exp1\lib\jfreechart-1.0.13.jar!\org\jfree\data\general\Dataset.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       0.7.1
 */