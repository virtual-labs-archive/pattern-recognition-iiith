package org.jfree.data.general;

import org.jfree.data.category.CategoryDataset;

public abstract interface KeyedValues2DDataset
  extends CategoryDataset
{}


/* Location:              C:\Users\soujanya\Desktop\pattern recognition 2\exp1\Exp1 (1).zip!\Exp1\lib\jfreechart-1.0.13.jar!\org\jfree\data\general\KeyedValues2DDataset.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       0.7.1
 */