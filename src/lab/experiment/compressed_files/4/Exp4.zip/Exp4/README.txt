For linux users:
1.	Extract the downloaded .tar.gz folder.
2.	Click on the .jar file of the experiment.

For windows users:
1.	Extract the downloaded .zip folder.
2.	Go to the Java console.
3.	Go to the Security tab.
4.	Check the "Enable Java content in the browser".
5.	Click on the button "Edit Site List".
6.	In the new dilogue box that appears, click on "Add".
7.	Type and add the following url to the exception list : "http://test.virtual-labs.ac.in".
8.	Click on the "OK" button of the dialogue box.
9. 	Click on the "OK" button of the Java console.
10.	Click on the .jar file of the experiment.